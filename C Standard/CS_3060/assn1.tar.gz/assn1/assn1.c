// Bryan
// CS3060-001
// Assn1

/* Promise of Originality
I promise that this source code file has, in it's entirety, been
written by myself and by no other person or persons. If at any time an
exact copy of this source code is found to be used by another person in
this term, I understand that both myself and the student that submitted
the copy will receive a zero on this assignment.
*/

#include<stdio.h>

int main(int argc, char *argv[]) {
	printf("Program prints out all command line parameters, followed by a count of how many there were.\n");
	int i = 0;
	while(i < argc) {
		printf("%s\n",argv[i++]);
	}
	printf("%i\n", argc);
	return 0;
}
