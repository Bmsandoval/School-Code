// Bryan
// CS3060-001
// Assn2

/* Promise of Originality
I promise that this source code file has, in it's entirety, been
written by myself and by no other person or persons. If at any time an
exact copy of this source code is found to be used by another person in
this term, I understand that both myself and the student that submitted
the copy will receive a zero on this assignment.
*/

#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>

int main(int argc, char *argv[]) {// removed parameters:  int argn, char *arge[]
	pid_t pid;
	int ret = 0;
	pid = fork(); // creates nearly exact copy of process. both processes now continue execution of the program, but from two different memory points

	if ( pid == -1) {
		_exit(-1);
	}
	if ( pid == 0 ) { // this is where we split up the parent and child processes.
		/* child process */
		printf("Child started. ");
		if( argc == 1) {
			printf("No arguments provided. Terminating child\n");
			_exit(0);
		} else if (argc == 2) {
			printf("One argument provided. Calling execlp(), never to return (sniff)\n");
			execlp(argv[1], argv[1], NULL);
		} else {
			printf("More than one argument provided. Calling execvp(), never to return (sniff)\n");
			execvp(argv[1], &argv[1]);
		}
		printf("We should never see this\n");
		return -1;
	} else {
		/* parent process */
		printf("PARENT started, now waiting for process ID#%d\n", getpid());
		wait(&ret);
		printf("PARENT resumed. Child exit code of %d. Now terminating parent\n", WEXITSTATUS(ret));
	}
	return 0;
}
