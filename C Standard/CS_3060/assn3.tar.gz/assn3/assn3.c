// Bryan
// CS3060-001
// Assn3

/* Promise of Originality
I promise that this source code file has, in it's entirety, been
written by myself and by no other person or persons. If at any time an
exact copy of this source code is found to be used by another person in
this term, I understand that both myself and the student that submitted
the copy will receive a zero on this assignment.
*/

#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>

void *thread_func(void *);

int main(int argc, char *argv[]){
	pthread_t thread_handle[argc-1];
	int i;
	if(argc == 1) {
		printf("No arguments provided\n");
		return 0;
	}
	for (i = 0; i < argc-1; i++){
		pthread_create(&thread_handle[i], NULL, thread_func, argv[i+1]);
	}
	void *temp = NULL;
        int *factors = malloc(sizeof(int) * 20);
	for (i = 0; i < argc - 1; i++){
		pthread_join(thread_handle[i], &temp);
		factors = temp;
		int idx = 0;
		printf("%d: ", atoi(argv[i+1]));
		while (factors[idx] > -1)
		{
			printf("%d ", factors[idx]);
			idx++;
		}
		printf("\n");
		free(factors);
	}
	return 0;
}

void *thread_func(void *v) {
        int num = atoi((char*)v);
        int* factors = malloc(sizeof(int) * 20);
        int idx = 0;
        while (num%2 == 0) {
                factors[idx++] = 2;
                num = num/2;
        }
        int i;
        for(i = 3; i*i <= num; i = i+2) {
                while (num%i == 0) {
                        factors[idx++] = i;
                        num = num/i;
                }
        }
        if(num > 2) {
                factors[idx++] = num;
        }
        factors[idx] = -1;
        return factors;
}
