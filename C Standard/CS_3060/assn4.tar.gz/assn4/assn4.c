// Bryan
// CS3060-001
// Assn#

/* Promise of Originality
I promise that this source code file has, in it's entirety, been
written by myself and by no other person or persons. If at any time an
exact copy of this source code is found to be used by another person in
this term, I understand that both myself and the student that submitted
the copy will receive a zero on this assignment.
*/


#include<stdio.h>
#include<stdlib.h>
#include<semaphore.h>
#include<pthread.h>

/*
	BUFFER_SIZE defines how many elements are available in the buffer
*/
#define BUFFER_SIZE (20)
#define MAIN_PROD = (0);
#define PROD_CONS = (1);
/* 	The global count variable is the victim of this program. Should be
	zero by the end of the program. Rarely is.
*/
struct bufdata {
	int buffer[BUFFER_SIZE];
	sem_t sem_full, sem_empty;
};

/*
	producer_thread_func - Add elements to the buffer
*/

int* Factors(int num) {
	int* factors = malloc(sizeof(int) * 20);
	int idx = 0;
	while (num%2 == 0) {
		factors[idx++] = 2;
		num = num/2;
	}
	int i;
	for(i = 3; i*i <= num; i = i+2) {
		while (num%i == 0) {
			factors[idx++] = i;
			num = num/i;
		}
	}
	if(num > 2) {
		factors[idx++] = num;
	}
	factors[idx] = 0;
	return factors;
}

void *producer_thread_func(void *p) {
	int* factors = malloc(sizeof(int) * 20);
	int in = 0;
	int out = 0;
	struct bufdata *pdata = (struct bufdata *)p;

	while(1) {
		sem_wait(&(pdata+1)->sem_full);
		if ( (pdata+1)->buffer[in] == 0 ) break;
		sem_wait(&pdata->sem_empty);
		pdata->buffer[out] = -1;
		out = (out + 1) % BUFFER_SIZE;

		pdata->buffer[out] = (pdata + 1)->buffer[in];

		out = (out + 1) % BUFFER_SIZE;
		sem_post(&pdata->sem_full);	
	// ***************************** Put in your factoring code dummy!!!
		int cnt = 0;
		factors = Factors((pdata+1)->buffer[in]);
		while(factors[cnt] > 0) {	
			sem_wait(&pdata->sem_empty);
			pdata->buffer[out] = factors[cnt];	
			sem_post(&pdata->sem_full);
			cnt++;
			out = (out + 1) % BUFFER_SIZE;
		}

		sem_post(&(pdata+1)->sem_empty);
		in = (in + 1) % BUFFER_SIZE;
	}

	sem_wait(&pdata->sem_empty);

	pdata->buffer[out] = 0;

	sem_post(&pdata->sem_full);
	return NULL;
}

/*
	consumer_thread_func - Sum the content of the buffer
*/
void *consumer_thread_func(void *p) {
	int out = 0;
	int numCnt = 0;
	struct bufdata* pdata = (struct bufdata*)p;

	while(1) {
		sem_wait(&pdata->sem_full);
		//printf("%d", pdata->buffer[out]);
		if ( pdata->buffer[out] == 0){
			sem_post(&pdata->sem_empty);
			break;
		}
		if( pdata -> buffer[out] == -1 ) {
			if(numCnt == 1)	printf("\n");	
			out = (out+1) % BUFFER_SIZE;
			printf("%d:", pdata -> buffer[out]);
			out = (out + 1) % BUFFER_SIZE;
			numCnt = 1;
		}
		printf(" %d", pdata->buffer[out]);		

		sem_post(&pdata->sem_empty);

		out = (out + 1) % BUFFER_SIZE;

	}
	printf("\n");
	return NULL;
}

/*
	Main method created THREAD_COUNT * 2 threads to increment and
	decrement the count variable.
*/
int main(int argc, char *argv[]) {
	pthread_t prod_thread;
	pthread_t cons_thread;
	struct bufdata *pdata = malloc(sizeof(struct bufdata)*2); 
	if ( argc < 2 ) {
		printf("Usage:./assn4 <numbers to factor>...\n");
		exit(-1);
	}
	// pdata->number = atoi(argv[1]) {
	// pdata->sum = 0;
	
	// Initialize the Prod/Cons buffer
	sem_init(&pdata->sem_empty, 0, BUFFER_SIZE);
	sem_init(&pdata->sem_full, 0, 0);
	// Initialize the Main/Producer buffer
	sem_init(&(pdata+1)->sem_empty, 0, BUFFER_SIZE);
	sem_init(&(pdata+1)->sem_full, 0, 0);
	// Create the threads
	pthread_create(&prod_thread, NULL, producer_thread_func, pdata);
	pthread_create(&cons_thread, NULL, consumer_thread_func, pdata);
	int in = 0;
	int cnt = 1;
	while (cnt < argc) {
		if(atoi(argv[cnt]) < 2) {
			printf("Yo Jolly...\nI can't work with that shit...\nGive me an integer greater then 1.\n");
			cnt++;
			continue;
		}

			
		sem_wait(&(pdata+1)->sem_empty);

		(pdata+1)->buffer[in] = atoi(argv[cnt]);

		sem_post(&(pdata+1)->sem_full);

		cnt++;

		in = (in + 1) % BUFFER_SIZE;
	}


	sem_wait(&(pdata+1)->sem_empty);

	(pdata+1)->buffer[in] = 0;

	sem_post(&(pdata+1)->sem_full);

	pthread_join(prod_thread, NULL);
	pthread_join(cons_thread, NULL);

	// printf("Sum of buffer is %d\n", pdata->sum);

	free(pdata);

	return 0;
}
