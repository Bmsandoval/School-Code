// Bryan
// CS3060-001
// Assn5

/* Promise of Originality
I promise that this source code file has, in it's entirety, been
written by myself and by no other person or persons. If at any time an
exact copy of this source code is found to be used by another person in
this term, I understand that both myself and the student that submitted
the copy will receive a zero on this assignment.
*/



#include<stdio.h>

#define MAX_JOBS (100)
#define QUANTUM (100)

void RRobin(int count, int sub[], int run[]) {
	printf("Round Robin with Time Quantum of 100\n");
	// Variables
	int ready_remain[MAX_JOBS]={-1};
	int ready_job[MAX_JOBS]={-1};
	int cJob = 0;
	int q_add = 1; // next available slot in the ready queue
	int end_clock, clock = 0;
	int wait=0, resp=0, ta = 0;
	// increment clock to first available job and add it to the ready queue
	ready_remain[0] = run[0];
	ready_job[0] = 0;
	int jobsComp = 0;
	clock = sub[0];
	int qEnded = 0;
	int queueFront = 0;
	int queueRear = 1;
	int rdyJob = 0;
	while(jobsComp < count) {
		/* Job Selection */
		cJob = queueFront;
		rdyJob = ready_job[queueFront];
		queueFront = (queueFront + 1)%MAX_JOBS;

		// First run through code
		if(ready_remain[cJob] == run[rdyJob]) {
			resp += clock - sub[rdyJob]; // First run stats
		}
		// job finished or quantum ending?
		if(ready_remain[cJob] <= QUANTUM){
			// Job finished on it's own
			end_clock = clock + ready_remain[cJob];	
			ready_remain[cJob] = 0;
			jobsComp++;

			/* Completion Stats */
			ta += end_clock - sub[rdyJob];
			wait += end_clock - sub[rdyJob] - run[rdyJob];	
		}
		else {
			// Quantum Ended
			ready_remain[cJob] -= QUANTUM;
			end_clock = clock + QUANTUM;
			qEnded=1;
		}

		/* add jobs to the ready queue *//************************************* removed the = on the <= */
		while(q_add < count && sub[q_add] < end_clock) {
			ready_remain[queueRear] = run[q_add];
			ready_job[queueRear] = q_add;
			queueRear = (queueRear + 1) % MAX_JOBS;
			q_add++;
		}

		// No jobs available in ready queue, increment to next available job.
		if(qEnded == 1) {
			ready_remain[queueRear] = ready_remain[cJob];
			ready_job[queueRear] = ready_job[cJob];
			queueRear = (queueRear + 1) % MAX_JOBS;
			qEnded = 0;
		}	
		if(queueRear == queueFront && q_add < count) {
			// Add next available job no matter the clock time
			while(1) {
				ready_remain[queueRear] = run[q_add];
				ready_job[queueRear] = q_add;
				queueRear = (queueRear + 1) % MAX_JOBS;	
				end_clock = sub[q_add];
				q_add++;
				// See if there are any other jobs at the same clock time
				if(sub[q_add] == sub[q_add+1])
					continue;
				else
					break;
			}
		}
		clock = end_clock;
	} // End While Loop
	printf("Avg. Resp.: %.2f, Avg. T.A.: %.2f, Avg. Wait: %.2f\n", (double)resp/count, (double)ta/count, (double)wait/count);
}// End of RRobin Function

void Srtn(int count, int sub[], int run[]) {
	printf("Shortest Remaining Time Next\n");

	// Variables
	int ready_remain[MAX_JOBS]={-1};
	int cJob = 0;
	int q_add = 1; // next available slot in the ready queue
	int end_clock, clock = 0;
	int wait=0, resp=0, ta = 0;

	// increment clock to first available job and add it to the ready queue
	ready_remain[0] = run[0];
	int rdyCnt = 1;
	int jobsComp = 0;
	clock = sub[0];
	int k;
	int preempted = 0;
	while(jobsComp < count) {

		/* Job Selection */
		// Find the shortest job in the ready queue and add it's index to cJob
		for(k = 0; k < q_add; k++) {
			if(0 == ready_remain[cJob]) {
				cJob = k;
				continue;	
			}
			if(ready_remain[cJob] > ready_remain[k] && ready_remain[k] > 0) {
				cJob = k;
			}
		}
		// First run through code
		if(ready_remain[cJob] == run[cJob]) {
			resp += clock - sub[cJob]; // First run stats
		}
			

		// Preemption Code
		int pre = 1;
		// check all values from 1 to count - current job number
		for(pre = 1; pre < count-cJob; pre++) {
			if(sub[cJob + pre] > clock && sub[cJob + pre] < clock + ready_remain[cJob]) {// check for submission times between the job's start and finish
				ready_remain[cJob] = ready_remain[cJob] + clock - sub[cJob+pre];
				preempted = 1;
				// If preemption, set clock to beginning of next job.
				end_clock = sub[cJob+pre];
                                break;	
			}
		}

		// Job Completion Code
		if(0 == preempted) {
			end_clock = clock + ready_remain[cJob];
			ready_remain[cJob] = 0;
			rdyCnt--;
			jobsComp++;

			/* Completion Stats */
			ta += end_clock - sub[cJob];
			wait += end_clock - sub[cJob] - run[cJob];
		}
		preempted = 0;

		/* add jobs to the ready queue */
		while(q_add < count && sub[q_add] <= end_clock) {
			ready_remain[q_add] = run[q_add];
			rdyCnt++;
			q_add++;
		}

		// No jobs available in ready queue, increment to next available job.
		if(0 == rdyCnt && q_add < count) {
			// Add next available job no matter the clock time
			while(1) {
				ready_remain[q_add] = run[q_add];
				end_clock = sub[q_add];
				q_add++;
				rdyCnt++;
				// See if there are any other jobs at the same clock time
				if(sub[q_add] == sub[q_add+1])
					continue;
				else
					break;
			}
		}
		clock = end_clock;
	} // End While Loop
	printf("Avg. Resp.: %.2f, Avg. T.A.: %.2f, Avg. Wait: %.2f\n", (double)resp/count, (double)ta/count, (double)wait/count);
} // End SRTN Function
void Sjf(int count, int sub[], int run[]) {
	printf("Shortest Job First\n");
	// Variables
	int ready_remain[MAX_JOBS];
	int cJob = 0;
	int q_add = 1; // next available slot in the ready queue
	int end_clock, clock = 0;
	int wait=0, resp=0, ta = 0;

	// increment clock to first available job and add it to the ready queue
	ready_remain[0] = run[0];
	int rdyCnt = 1;
	int jobsComp = 0;
	clock = sub[0];
	int k;
	while(jobsComp < count) {

		/* Job Selection */
		// Find the shortest job in the ready queue and add it's index to cJob
		for(k = 0; k < q_add; k++) {
			if(0 == ready_remain[cJob]) {
				cJob = k;
				continue;	
			}
			if(ready_remain[cJob] > ready_remain[k] && ready_remain[k] > 0) {
				cJob = k;
			}
		}


		rdyCnt--;
		// ************************ Job completed code
		/* Set clock */
		end_clock = clock + ready_remain[cJob];

		/* Stats */
		resp += clock - sub[cJob];
		ta += end_clock - sub[cJob];
		wait += end_clock - sub[cJob] - run[cJob];
		jobsComp++;


		/* add jobs to the ready queue */
		while(q_add < count && sub[q_add] <= end_clock) {
			ready_remain[q_add] = run[q_add];
			rdyCnt++;
			q_add++;
		}

		// No jobs available in ready queue, increment to next available job.
		if(0 == rdyCnt && q_add < count) {
			// Add next available job no matter the clock time
			while(1) {
				ready_remain[q_add] = run[q_add];
				end_clock = sub[q_add];
				q_add++;
				rdyCnt++;
				// See if there are any other jobs at the same clock time
				if(sub[q_add] == sub[q_add+1])
					continue;
				else
					break;
			}
		}
		clock = end_clock;
		ready_remain[cJob] = 0;
	} // End While Loop
	printf("Avg. Resp.: %.2f, Avg. T.A.: %.2f, Avg. Wait: %.2f\n", (double)resp/count, (double)ta/count, (double)wait/count);
} // End SJF Function
void Fcfs(int count, int sub[], int run[]) {
	printf("First Come, First Served\n");
	int ready_remain[MAX_JOBS];
	int q = 0;
	int q_add = 1; // next empty area I can put into my queue
	int end_clock, clock = 0;
	int wait=0, resp=0, ta = 0;
	int rdyCnt = 1;
	ready_remain[0] = run[0];

	clock = sub[0];

	while(q < count) {
		/* Job selection */

		rdyCnt--;
		/* Time eval */
		end_clock = clock + ready_remain[q];

		/* Statistics */
		resp += clock - sub[q];
		ta += end_clock - sub[q];
		wait += end_clock - sub[q] - run[q];

		q++;

		/* Add jobs */
		while(q_add < count && sub[q_add] <= end_clock) {
			ready_remain[q_add] = run[q_add];
			q_add++;
			rdyCnt++;
		}
                if(0 == rdyCnt && q_add < count) {
                        while(1) {
                                ready_remain[q_add] = run[q_add];
                                end_clock = sub[q_add];
                                // check all jobs at same clock time
                                if(sub[q_add] == sub[q_add+1])
                                        continue;
                                else
                                        break;
				q_add++;
				rdyCnt++;
                        }
                }
		clock = end_clock;
	}
	printf("Avg. Resp.: %.2f, Avg. T.A.: %.2f, Avg. Wait: %.2f\n", (double)resp/count, (double)ta/count, (double)wait/count);

}



int main () {

	int sub[MAX_JOBS];
	int run[MAX_JOBS];
	int i = 0;
	while (fscanf(stdin, "%d %d", &sub[i], &run[i]) ==2) {
		i++; // as long as we are finding values, add them and increment i.
	}

	Fcfs(i, sub, run);
	Sjf(i, sub, run);
	Srtn(i, sub, run);
	RRobin(i, sub, run);
	
	return 0;
}

