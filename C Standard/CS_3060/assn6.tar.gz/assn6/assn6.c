// Bryan
// CS3060-001
// Assn6

/* Promise of Originality
I promise that this source code file has, in it's entirety, been
written by myself and by no other person or persons. If at any time an
exact copy of this source code is found to be used by another person in
this term, I understand that both myself and the student that submitted
the copy will receive a zero on this assignment.
*/


#include<stdio.h>
#include<stdlib.h>

int main(int argc, char *argv[]) {
	long unsigned int number;

	if(argc !=2) {
		printf("Usage: %s <address>\n", argv[0]);
		return-1;
	}
	number = strtol(argv[1], NULL, 16);
	printf("Logical Addr:0x%08lX, - Page Index:0x%08lX - Page Offset:0x%08lX\n", number, number >> 12 /* number / 4096 */, number % 4096); 
	return 0;
}
