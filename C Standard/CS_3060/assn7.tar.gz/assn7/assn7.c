// Bryan
// CS3060-001
// Assn7

/* Promise of Originality
I promise that this source code file has, in it's entirety, been
written by myself and by no other person or persons. If at any time an
exact copy of this source code is found to be used by another person in
this term, I understand that both myself and the student that submitted
the copy will receive a zero on this assignment.
*/

#include<stdio.h>
#include<stdlib.h>
#define MAX_JOBS (100)



void Fcfs(int count, int block[]) {
        int q = 1;
	int prevBlock = block[0];
	int currBlock = 0;
	int totSeek = 0;
        while(q < count) {
                /* Block Select */
		currBlock = block[q++];
                /* Time eval */
		totSeek+=abs(currBlock-prevBlock);
		prevBlock = currBlock;
        }
        printf("FCFS Total Seek: %d\n", totSeek);
}


void Sstf(int count, int block[]) {
        int q = 1;
        int prevBlock = block[0];
        int curr = 0;
        int totSeek = 0;
	int dist = 0;

	//make a copy of the array that I can mess with
	int cBlock[MAX_JOBS];
	int i = 0;
	for(i = 0; i < count; i++)
		cBlock[i] = block[i];
	cBlock[0] = 0;

        while(q < count) {
                /* Block Select */
                int i = 1;
		dist = 0;
		while(i < count) {
                        // Select shortest distance to next block
			if(0 == cBlock[i]) {
				i++;
				continue;
			}
			int tmpDist = abs(prevBlock - cBlock[i]);
			if((tmpDist > 0 && tmpDist<dist) || dist <1){
				dist = tmpDist;
				curr = i;
			}
			i++;
                }
		prevBlock = block[curr];
		cBlock[curr] = 0;
                /* Time eval */
		totSeek+=dist;
		q++;
        }
        printf("SSTF Total Seek: %d\n", totSeek);
}
void Look(int count, int block[]) {
        int q = 1;
        int curr = 0;
        int totSeek = 0;
        int nextBlock = 0;
	int flag = 0; // flip the flag once we hit the largest value
	int cBlock[MAX_JOBS];
        int i = 0;
        for(i = 0; i < count; i++)
        	cBlock[i] = block[i];
	int prevBlock = block[0];
	cBlock[0] = 0;

        while(q < count) {
                /* Block Select */
              	nextBlock = 0;
		if(0 == flag) {
			/* Select the next closest block in the positive direction */

			// Find the next possible block larger then the current
			i = 0;
			while(i < count) {
	                        if(cBlock[i] > prevBlock) {
                                	nextBlock = block[i];
                                	curr = i;
                                	break;
                        	}
				i++;
			}
	                // If none found, flip the flag
        	        if(0==nextBlock) {
                       	        flag = 1;
			}
			else {
				i = 0;
	                        while(i < count) {
                	                if(cBlock[i] > prevBlock && cBlock[i] < nextBlock){
                        	        	nextBlock = cBlock[i];
						curr = i;
                                	}
                                	// Select shortest distance to next block
                                       	i++;
                        	}
			}
		}
                // This will run if we've hit the end once already       
		if(1 == flag) {
			/* Select the next largest block */
			i = 0;
			while(i < count) {
				if(cBlock[i] > nextBlock) {
					nextBlock = cBlock[i];
					curr = i;
				}	
				i++;
			}
		}
		totSeek+=abs(prevBlock-nextBlock);
                prevBlock = nextBlock;
		nextBlock = 0;
                cBlock[curr] = 0;
		curr = 0;
                q++;
        }
        printf("LOOK Total Seek: %d\n", totSeek);
}
void CLook(int count, int block[]) {
        int q = 1;
        int curr = 0;
        int totSeek = 0;
        int nextBlock = 0;
        int cBlock[MAX_JOBS];
        int i = 0;
        for(i = 0; i < count; i++)
                cBlock[i] = block[i];
	int prevBlock = cBlock[0];
        cBlock[0] = 0;

        while(q < count) {
                /* Block Select */
                nextBlock = 0;
		/* Select the next closest block in the positive direction */

		// Find the next possible block larger then the current
		i = 1;
		while(i < count) {
			if(cBlock[i] > prevBlock) {
				nextBlock = block[i];
				curr = i;
				break;
			}
			i++;
		}
		if(0==nextBlock) {
			// Find the smallest possible block and start from there
			i = 1;
			while(i < count) {
				if(nextBlock == 0 && cBlock[i] > 0) {
					nextBlock = cBlock[i];
					curr = i;
					i++;
					break;
				}
				i++;
			}
			while(i < count) {
				if(cBlock[i] < nextBlock && cBlock[i] > 0) {
					nextBlock = cBlock[i];
					curr = i;
				}		
				i++;
			}
		}
		i = 1;
		while(i < count) {
			if(cBlock[i] > prevBlock && cBlock[i] < nextBlock){
				nextBlock = cBlock[i];
				curr = i;
			}
			// Select shortest distance to next block
			i++;
		}
		                
                totSeek+=abs(prevBlock-nextBlock);
                prevBlock = nextBlock;
                nextBlock = 0;
                cBlock[curr] = 0;
                curr = 0;
                q++;
        }
        printf("C-LOOK Total Seek: %d\n", totSeek);
}

int main () {

        int block[MAX_JOBS];
        int i = 0;
        while (fscanf(stdin, "%d", &block[i]) ==1) {
                i++; // as long as we are finding values, add them and increment i.
        }

        Fcfs(i, block);
        Sstf(i, block);
        Look(i, block);
        CLook(i, block);
        return 0;
}
