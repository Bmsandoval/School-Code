// Bryan
// CS3060-001
// Assn8

/* Promise of Originality
I promise that this source code file has, in it's entirety, been
written by myself and by no other person or persons. If at any time an
exact copy of this source code is found to be used by another person in
this term, I understand that both myself and the student that submitted
the copy will receive a zero on this assignment.
*/


#include<stdio.h>
#include<dirent.h>
#include<string.h>
#include "sys/stat.h"
#include<stdlib.h>



int Recurse(char* dir, int numTabs) {
        DIR *dp;
        struct dirent *dent;
        struct stat st;
	// open the directory as specified
        dp = opendir(dir);
	int fileSize = 0;
	// examine each file in the directory
        while(( dent = readdir(dp)) != NULL) {

		// Create a new string containing the file path
		char* fullpath = (char*)malloc(strlen(dir)+strlen(dent->d_name)+2);
		sprintf(fullpath, "%s/%s", dir, dent->d_name);
		// Skip the item if it starts with .
                if(dent->d_name[0] == '.' ) continue;
                stat(fullpath, &st);
		// Check if the current file is a directory
                if(S_ISDIR(st.st_mode) ) {
			int i;
			// Format the output with tabs as needed
			for(i = 0; i < numTabs; i++)
				printf("\t");
			printf("dir %s\n", fullpath);
			fileSize+= Recurse(fullpath, numTabs +1);
		//Run this if it failed
                } else {
			int i;
                        for(i = 0; i < numTabs; i++)
                                printf("\t");
                        printf("%d:%s\n", (int)st.st_size, dent->d_name);
			fileSize+= (int)st.st_size;
                }
        }
        return fileSize;
}
int main(int argc, char *argv[]) {
	char* dir;
	if(0 == argc)
		dir = ".";
	else
		dir = argv[1];
	printf("dir %s\n", argv[1]);
	printf("Total file space used: %d\n", Recurse(argv[1], 0));
	return 0;	}
}
