﻿// File Prologue
// Name: Bryan M. Sandoval
// Project: lab01
// Date: 1/17/13

// I declare that the following source code was written by me, or provided
// by the instructor for this project. I understand that copying 
// source code from any other source constitutes cheating, and that I will
// receive a zero grade on this project if I am found in violation of
// this policy.

using System;

static class Program
{
    static void Main()
    {
        // This program displays my student information
        string name = "Bryan Sandoval";
        string course = "CS 1400";
        string section = "001";
        string project = "Lab One";


        // This code displays the strings on the console
        Console.WriteLine("Name: {0}", name);
        Console.WriteLine("Course: {0}", course);
        Console.WriteLine("Section: {0}", section);
        Console.WriteLine("Project: {0}", project);

        Console.ReadLine();
    }// End Main
} // End Class Program
