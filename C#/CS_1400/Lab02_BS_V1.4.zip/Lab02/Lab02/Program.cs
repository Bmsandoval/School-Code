﻿// File Prologue
// Name: Bryan M. Sandoval
// CS 1400 Section 001
// Project: Lab02
// Date: 1/14/2013
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;

static class Program
{

    static void Main()
    {
        //1. Declare constants
        const int SECONDPOWER = 2;
        const int TWICERADIUS = 2;
        //2. declare radius, area, result as doubles
        double radius = 10.0;
        double result = 10.0;
        //3. get radius of crop circle
        Console.Write("Please enter the radius of one crop circle: ");
        radius = double.Parse(Console.ReadLine());
        //4. calculate ((2r)^2) - (pi * r^2)
        result = Math.Pow((TWICERADIUS * radius), SECONDPOWER) - Math.Pow(radius, SECONDPOWER) * Math.PI;
        //5. display unused area
        Console.WriteLine("The area of unused ground is {0:f2}", result);
        Console.ReadLine();
    }//End Main()
}//End class Program
