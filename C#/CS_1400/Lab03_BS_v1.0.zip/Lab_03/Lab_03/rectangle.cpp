#include "rectangle.h"
const string HEIGHT = "The height is: ";
const string WIDTH = "The width is: ";
const string AREA = "The area is: ";
void main()
{
	Area();
	system("PAUSE");
}

void Area()
{
	MyRectangle rectMachina(7.0, 4.0);

	cout << HEIGHT << rectMachina.GetHeight() << endl;
	cout << WIDTH << rectMachina.GetWidth() << endl;
	cout << AREA << rectMachina.GetArea() << endl;
}

MyRectangle::MyRectangle(double h, double w)
{
	_height = h;
	_width = w;
}

double MyRectangle::GetHeight()
{
	return _height;
}

double MyRectangle::GetWidth()
{
	return _width;
}

double MyRectangle::GetArea()
{
	return (_height * _width);
}