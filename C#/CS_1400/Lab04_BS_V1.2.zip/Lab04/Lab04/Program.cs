﻿// File Prologue
// Name: Bryan M. Sandoval
// CS 1400 Section 001
// Project: Lab04
// Date: 1/21/2013
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;

static class Program
{
    static void Main()
    {
        //Const
        const string RQSTNAME = "Please enter your full name:     ";
        const string RQSTCOURSE = "Please enter your course number:        and section number: ";
        const string RQSTAGE = "How old are you?        ";
        const string RQSTMONEY = "How much money do you have in your pocket?      ";
        const string GIVENAME = "Thank you {0}";
        const string GIVECOURSE = "In {0} - {1}";
        const string GIVEAGE = "Your age is {0:d2}";
        const string GIVEVALUE = "You have {0:C2} in your wallet";
        const string CONTINUE = "Press any key to continue . . . ";
        const int CURSORONEX = 33;
        const int CURSORONEY = 3;
        const int CURSORTWOX = 60;
        const int CURSORTWOY = 3;

        //declarations
        string name = "";
        string course = "";
        string section = "";
        int age = 0;
        double value = 0.0;

        // Here you must supply code that does the following:
        // 1) Sets the BackgroundColor to Cyan.
        Console.BackgroundColor = ConsoleColor.Cyan;
        // 2) Sets the ForegroundColor to DarkBlue.
        Console.ForegroundColor = ConsoleColor.DarkBlue;
        // 3) Clears the Console Window.
        Console.Clear();
        // 4) Sets the Console Title to "My Super/Duper Console Window"
        Console.Title = "My Super/Duper Console Window";
        // 5) Prompts the user to enter their full name.
        Console.WriteLine();
        Console.Write(RQSTNAME);
        // 6) Gets their name and stores it in the variable name.
        name = Console.ReadLine();
        Console.WriteLine();
        // 7) Prompts the user to enter their course and section information.
        Console.Write(RQSTCOURSE);
        // 8) Positions the cursor to left = 33 and top = 3
        Console.SetCursorPosition(CURSORONEX, CURSORONEY);
        // 9) Gets their course information and stores it in the variable course
        course = Console.ReadLine();
        // 10) Positions the cursor to left = 60 and top = 3
        Console.SetCursorPosition(CURSORTWOX, CURSORTWOY);
        // 11) Gets the section information and stores it in section
        section = Console.ReadLine();
        Console.WriteLine();
        // 12) Prompts the user for their age.
        Console.Write(RQSTAGE);
        // 13) Gets their age and stores it in the variable age.
        age = int.Parse(Console.ReadLine());
        Console.WriteLine();
        // 14) Prompts the user for how much money they have.
        Console.Write(RQSTMONEY);
        // 15) Gets the amount of money and stores it in the variable value.
        value = double.Parse(Console.ReadLine());
        Console.WriteLine();
        // 16) Displays the following. Use format specifiers to display the information and
        // to control the format of your output:
        //    a) The person's name. You must display the full name
        Console.WriteLine(GIVENAME, name);
        //    b) The person's course and section.
        Console.WriteLine(GIVECOURSE, course, section);
        //    c) The person's age.
        Console.WriteLine(GIVEAGE, age);
        //    d) The amount of money the person has. Display the dollar symbol (hint use “C”)
        //    and two digits after the decimal point.
        Console.WriteLine(GIVEVALUE, value);
        Console.WriteLine(CONTINUE);
        Console.ReadLine();
    }//End Main()
}//End class Program
