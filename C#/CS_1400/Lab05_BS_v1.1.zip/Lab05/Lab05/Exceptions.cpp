#include "Exceptions.h";




const string ERROR = "Invalid input: A Non-Integer value was input";

void main()
{
	UserInput();
	system("PAUSE");
}

void UserInput()
{
	// Declare an integer value to store the user's input.
	string cinput = NULL;
	int square = 0;
	// Prompt the user to enter a positive, non-zero integer value.
	cout << "Please enter a positive, non-zero, integer value.";
	getline(cin, cinput);
	// Pass this value to a function named�CalculateSquare. This function will only work on positive, non-zero values.
	[
		square = CalculateSquare(cinput);
	]
}

int CalculateSquare(string inpt)
{
	// Since the function has no idea where the data came from it has no way to recover if the parameter it receives is invalid.
	try
	{
		
		
	// If the value passed is zero or negative the function will throw an exception that
	// (1) indicates what the error was, and 
	// (2) what the value of the offending parameter is. 
	// If the parameter is okay, it calculates and returns the square of the number.
}

	// You will have to create an exception class capable of storing information about what the error was, and the value passed to the function.
ApplicationError::ApplicationError(const string& e)
{
	_error = e;
}
ApplicationError::~ApplicationError()
{

}
ApplicationError::string& what()
{
	return _error;
}