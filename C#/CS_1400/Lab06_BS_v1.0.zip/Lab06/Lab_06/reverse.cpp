#include "reverse.h"

const char NULL_TERM = '\0';
const char WHITE_SPACE = ' ';

const int HALF = 2;


void main( )
{

    Reverse( );
	system("PAUSE");
}

void Reverse()
{
	int total = 0;
// declare a C-String to reverse
	char myString[] = "Hello World!";
// call the reverser function
	total = Count(myString);
	Swap(total, myString);
// output the result
	cout << myString << endl;
}


int Count(char* text)
{
	int count = 0;
	
	while(*text != NULL_TERM)
	{
		count++;
		text++;
	}
	return count;
}



void Swap(int ct, char* text)
{
	char temp = ' ';
	char* pOne = (text);
	char* pTwo = (text + (ct - 1));
	for(int i = 0; i < (ct / HALF); i++)
	{
		temp = *pOne;
		*pOne = *pTwo;
		*pTwo = temp;
		pOne++;
		pTwo--;
	}
}