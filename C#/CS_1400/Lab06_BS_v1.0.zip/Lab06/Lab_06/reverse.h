///Course: CS 1410 Section 002
///Author: Bryan Sandoval
///Date: 10/24/13
///Project: Lab06
///-----------------------------------------------------------
///I declare that the following source code was written
///solely by me, or provided by the instructor.�
///I understand that copying any source
///code, in whole or in part, constitutes cheating, and
///that I will receive a zero in this assignment if I am
///found in violation of this policy.
///------------------------------------------------------------

#include <string>
#include <iostream>
#include <iomanip>
#include <cctype>

using namespace std;

// ----------------------------------------------------------------------------
// Purpose: To declare a string and pass it to the count and swap functions
// Parameters: None
// Returns: None
// ----------------------------------------------------------------------------
void Reverse();
// ----------------------------------------------------------------------------
// Purpose: To return the number of characters in a string up until a null terminator
// Parameters: a string terminated by a null
// Returns: an int representing the langth of the string
// ----------------------------------------------------------------------------
int Count(char*);
// ----------------------------------------------------------------------------
// Purpose: all of the elements in an array
// Parameters: A string array terminated by a null, and an int containing the length of the array
// Returns: None
// ----------------------------------------------------------------------------
void Swap(int, char*);
