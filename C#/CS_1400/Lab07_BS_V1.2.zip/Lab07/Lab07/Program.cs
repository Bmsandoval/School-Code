﻿// File Prologue
// Name: Bryan Sandoval
// CS 1400 Section 001
// Project: Lab07
// Date: 1/31/2013 12:52:04 PM
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;

static class Program
{
    const int PAIRS = 2;
    const int MAX = 500;
    const string TOTALS = "{0}\t{1}\t{2}\t{3}";
    const string GREETING = "Table of rabbit populations depicted in pairs.\n\nMonth\tAdults\tBabies\tTotal";
    const string OUT = "You ran out of cages on Month {0}";
    static void Main()
    {
        int mAdults = 0;
        int babies = 2;
        int nonMAdults = 0;
        int month = 0;
        int total = 0;
        Console.WriteLine(GREETING);
        do
        {
            //Increment to the next month
            month++;
            //Add the nonmating adults into the mating adults
            mAdults += nonMAdults;
            //non mating adults will now be filled with last generation's ofspring
            nonMAdults = babies;
            //calculate new generation of babies
            babies = (mAdults / PAIRS) * PAIRS;
            //calculate totals
            total = (babies + mAdults + nonMAdults);
            //separate each group into pairs and print results
            Console.WriteLine(TOTALS, month, (mAdults + nonMAdults) / PAIRS, babies / PAIRS, total / PAIRS);
            //loop back until the number of pairs reaches 500.
            if(total/PAIRS >= MAX)
            {
                Console.WriteLine(OUT, month);
            }
        } while ((total / PAIRS) <= MAX);
        Console.ReadLine();
    }//End Main()
}//End class Program
