﻿// File Prologue
// Name: Bryan Sandoval
// CS 1400 Section 001
// Project: Lab08
// Date: 2/4/2013
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;

static class Program
{
    const string SUN = "sunday";
    const string MON = "monday";
    const string TUE = "tuesday";
    const string WED = "wednesday";
    const string THU = "thursday";
    const string FRI = "friday";
    const string SAT = "saturday";
    const string DAY = "What day of the week is it?";
    const string WORK = "You have work today.";
    const string NOWORK = "You have the day off of work!";
    const string MONWEDFRI = "You need to go to your monday, wednesday friday classes.";
    const string TUETHU = "You need to go to your Tuesday Thursday classes";

    static void Main()
    {

        //Part 1 (Using IF-ELSE statements)
        string today = "";
        string output = "";
        Console.Write(DAY);
        today = Console.ReadLine().ToLower();
        if (today == SUN || today == SAT)
        {

            Console.WriteLine(NOWORK);
        }
        else
        {
            Console.WriteLine(WORK);
            if (today == MON || today == WED || today == FRI)
            {
                Console.WriteLine(MONWEDFRI);
            }
            else
            {
                Console.WriteLine(TUETHU);
            }
        }


        //Part 2 (Using Turnary Operators)
        today = "";
        Console.Write(DAY);
        today = Console.ReadLine().ToLower();
        output = (today == SUN || today == SAT) ? NOWORK : WORK;
        Console.WriteLine(output);
        output = (output == WORK && (today == MON || today == WED || today == FRI)) ? MONWEDFRI : output;
        output = (output == WORK && (today == TUE || today == THU)) ? TUETHU : output;
        output = (today == SUN || today == SAT) ? null : output;
        Console.WriteLine(output);
       
        //Part 3 Using Switch statements
        today = "";
        Console.Write(DAY);
        today = Console.ReadLine().ToLower();
        switch (today)
        {
            case MON:
                Console.WriteLine(WORK);
                Console.WriteLine(MONWEDFRI);
                break;
            case TUE:
                Console.WriteLine(WORK);
                Console.WriteLine(TUETHU);
                break;
            case WED:
                Console.WriteLine(WORK);
                Console.WriteLine(MONWEDFRI);
                break;
            case THU:
                Console.WriteLine(WORK);
                Console.WriteLine(TUETHU);
                break;
            case FRI:
                Console.WriteLine(WORK);
                Console.WriteLine(MONWEDFRI);
                break;
            default:
                Console.WriteLine(NOWORK);
                break;
        }


        Console.ReadLine();
    }//End Main()
}//End class Program
