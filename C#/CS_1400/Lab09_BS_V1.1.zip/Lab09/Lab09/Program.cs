﻿// File Prologue
// Name: Bryan Sandoval
// CS 1400 Section 001
// Project: Lab09
// Date: 2/12/2013
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;

static class Program
{
    const string MAINMENU = "Hello out there in C# land, I'm your happy menu:-)\n------------------------------------------------------\n\tI)nteger Values\n\tD)ouble Values\n\tC)haracterValues\n\tS)tring Values\n\tQ)uit Program\nEnter your choice: ";
    const string INTSUM = "The sum of {0} + {1} = {2}";
    const string DOUBSUM = "The sum of {0:f2} + {1:f2} = {2:f2}";
    const string ALPHASUM = "The concantenation of {0} and {1} = {0}{1}";
    const string INTEGERONE = "First integer value: ";
    const string INTEGERTWO = "Second integer value: ";
    const string STRINGONE = "First String: ";
    const string STRINGTWO = "Second String: ";
    const string CHARONE = "First char: ";
    const string CHARTWO = "Second char: ";
    const string DOUBLEONE = "First double: ";
    const string DOUBLETWO = "Second double: ";
    const string CONT = "Press enter to continue...";
    const string INVALID = "Invalid entry, please try again";
    const string QUIT = "You have chosen to quit.";
    const char USERI = 'I';
    const char USERD = 'D';
    const char USERC = 'C';
    const char USERS = 'S';
    const char USERQ = 'Q';
        static void Main()
    {
        string caseInput = "";
        string stringOne = "";
        string stringTwo = "";
        int integerOne = 0;
        int integerTwo = 0;

        double doubleOne = 0.0;
        double doubleTwo = 0.0;
        char charOne = 'z';
        char charTwo = 'z';

        do
        {
            Console.Clear();
            //title
            Console.Write(MAINMENU);
            //change to upper case
            caseInput = (Console.ReadLine()).ToUpper();
            //check if they just pressed enter
            if (caseInput == "" || caseInput == null)
            {
                Console.WriteLine(INVALID);
                Console.WriteLine(CONT);
                Console.ReadLine();
                continue;
            }
            else
            { //check enter
                switch (caseInput[0])
                { //check userinput
                    case USERI:
                        Console.Write(INTEGERONE);
                        if (int.TryParse(Console.ReadLine(), out integerOne))
                        { //result if int
                            Console.Write(INTEGERTWO);
                            if (int.TryParse(Console.ReadLine(), out integerTwo))
                            { //result if int
                                Console.WriteLine(integerTwo);
                                Console.WriteLine(INTSUM, integerOne, integerTwo, integerOne + integerTwo);
                                Console.WriteLine(CONT);
                                Console.ReadLine();
                            }
                            else
                            { //return if invalid
                                Console.Clear();
                                Console.WriteLine(INVALID);
                                Console.WriteLine(CONT);
                                Console.ReadLine();
                                continue;
                            }
                        }
                        else
                        { //return if invalid
                            Console.Clear();
                            Console.WriteLine(INVALID);
                            Console.WriteLine(CONT);
                            Console.ReadLine();
                            continue;
                        }
                        break;
                    case USERD:
                        Console.Write(DOUBLEONE);
                        if (double.TryParse(Console.ReadLine(), out doubleOne))
                        { //result if double
                            Console.Write(DOUBLETWO);
                            if (double.TryParse(Console.ReadLine(), out doubleTwo))
                            { //result if double
                                Console.WriteLine(doubleTwo);
                                Console.WriteLine(DOUBSUM, doubleOne, doubleTwo, doubleOne + doubleTwo);
                                Console.WriteLine(CONT);
                                Console.ReadLine();
                            }
                            else
                            { //return if invalid
                                Console.Clear();
                                Console.WriteLine(INVALID);
                                Console.WriteLine(CONT);
                                Console.ReadLine();
                                continue;
                            }
                        }
                        else
                        { //return if invalid
                            Console.Clear();
                            Console.WriteLine(INVALID);
                            Console.WriteLine(CONT);
                            Console.ReadLine();
                            continue;
                        }
                        break;
                    case USERC:
                        Console.Write(CHARONE);
                        if (char.TryParse(Console.ReadLine(), out charOne))
                        { //result if char
                            Console.Write(CHARTWO);
                            if (char.TryParse(Console.ReadLine(), out charTwo))
                            { //result if char
                                Console.WriteLine(ALPHASUM, charOne, charTwo);
                                Console.WriteLine(CONT);
                                Console.ReadLine();
                            }
                            else
                            { //return if invalid
                                Console.Clear();
                                Console.WriteLine(INVALID);
                                Console.WriteLine(CONT);
                                Console.ReadLine();
                                continue;
                            }
                        }
                        else
                        { //return if invalid
                            Console.Clear();
                            Console.WriteLine(INVALID);
                            Console.WriteLine(CONT);
                            Console.ReadLine();
                            continue;
                        }
                        break;
                    case USERS:
                        //ask for strings one and two (read results)
                        Console.Write(STRINGONE);
                        stringOne = Console.ReadLine();
                        Console.Write(STRINGTWO);
                        stringTwo = Console.ReadLine();
                        //concantenate and print result
                        Console.WriteLine(ALPHASUM, stringOne, stringTwo);
                        Console.WriteLine(CONT);
                        Console.ReadLine();
                        break;
                    case USERQ:
                        // quit program
                        goto end;
                    default:
                        // result if invalid choice for case
                        Console.Clear();
                        Console.WriteLine(INVALID);
                        Console.WriteLine(CONT);
                        Console.ReadLine();
                        continue;
                }
            }
        }while(true);

    end:
        Console.WriteLine(QUIT);
        Console.WriteLine(CONT);
        Console.ReadLine();
    }//End Main()
}//End class Program
