﻿// File Prologue
// Name: Bryan Sandoval
// CS 1400 Section 001
// Project: Lab10
// Date: 2/18/2013
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;

static class Program
{
    const string rqstValueX = "Please enter an X value: ";
    const string rqstValueY = "Please enter a Y value: ";
    const double CONV_FACT = 180.00 / Math.PI;
    const string INVALIDCHOICE = "You have made an invalid selection/nPress enter to continue...";
    const string GOODBYE = "Goodbye";
    const string RQSTCONV = "Would you like to convert x-y coordinates to polar coordinates? (Y/N)";
    const string INVALIDVALUES = "your values cannot be either zero or negative\nPress enter to try again...";
    const string RESULTS = "For x = {0:d2} and y = {1:d2}, the polar coordinates are:\nDistance from origin r = {2:f3},\nAngle (in degrees) from the x-axis = {3:f3}";
    const string USERINPT_Y = "Y";
    const string USERINPT_y = "y";
    const string USERINPT_yes = "yes";
    const string USERINPT_Yes = "Yes";
    const string USERINPT_n = "n";
    const string USERINPT_N = "N";
    const string USERINPT_no = "no";
    const string USERINPT_No = "No";
    static void Main()
    {
        //Declare variables
        int xCoord = 0;
        int yCoord = 0;
        double distance = 0.0;
        double angle = 0.0;
        string userInput = "Y";
        do
        {
            //Ask the user if they want to convert coordinates using a switch
            Console.Write(RQSTCONV);
            userInput = Console.ReadLine();
            switch (userInput)
            {
                //If they do want to convert coordinates (y, Y, yes, Yes)
                case USERINPT_Y:
                case USERINPT_y:
                case USERINPT_yes:
                case USERINPT_Yes:
                //Get X and Y values
                    GetUserInput(ref xCoord, ref yCoord);
                //Method 2 (Calculate polar coordinates)
                    PolarTranslation(xCoord, yCoord, out angle, out distance);
                //Method 3 (Display results)
                    DisplayResults(xCoord, yCoord, angle, distance);
                    break;
                //If they do not want to convert coordinates (n, N, no, No)
                case USERINPT_n:
                case USERINPT_N:
                case USERINPT_no:
                case USERINPT_No:
                //Say "Goodbye"
                    Console.Write(GOODBYE);
                    Console.ReadLine();
                    return;
                default:
                    Console.WriteLine(INVALIDCHOICE);
                    Console.ReadLine();
                    Console.Clear();
                    continue;
            }
        } while (true);

    }//End Main()

    //1. A method that gets input from the user and validates it. You can't return two values from a method, so you must use reference parameters to pass the user's input back to your Main( ) Method.
    //GetUserInput() method
    //Purpose: This method will retrieve user input and validate it
    //Inputs: The method's input is retrieving the console
    //Returns: yes, no, or invalid
    //Preconditions: None
    //Postconditions: Return the user's answer
    //--------------------------------------------------------------------------------------------------------------------------------------------
    static void GetUserInput(ref int xVal, ref int yVal)
    {
        bool test = true;
        do
        {
            Console.Write(rqstValueX);
            if(int.TryParse(Console.ReadLine(), out xVal))
            {
                if (xVal > 0)
                {
                    test = false;
                    continue;
                }
                else
                {
                    Console.WriteLine(INVALIDVALUES);
                    Console.ReadLine();
                    Console.Clear();
                    continue;
                }
            }
            else
            {
                Console.WriteLine(INVALIDCHOICE);
                Console.ReadLine();
                Console.Clear();
                continue;
            }
        } while (test == true);

        do
        {
            Console.Write(rqstValueY);
            if (int.TryParse(Console.ReadLine(), out yVal))
            {
                if (yVal > 0)
                {
                    test = false;
                    continue;
                }
                else
                {
                    Console.WriteLine(INVALIDVALUES);
                    Console.ReadLine();
                    Console.Clear();
                    continue;
                }
            }
            else
            {
                Console.WriteLine(INVALIDCHOICE);
                Console.ReadLine();
                Console.Clear();
                continue;
            }
        } while (test == true);

        return;

    }

    //2. A method that takes the x and y coordinates given by the user, and returns the polar coordinates. You can't return two values from a method, so you must use out reference parameters to pass the polar coordinates back to your Main( ) method.
    //PolarTranslation() method
    //Purpose: Transform x and y values into polar coordinates
    //Inputs: x and y
    //Returns: angle and distance
    //Preconditions: x and y must not be negative
    //Postconditions: none
    //--------------------------------------------------------------------------------------------------------------------------------------------
    static void PolarTranslation(double xVal, double yVal, out double ang, out double dist)
    {
        ang = (Math.Atan(yVal / xVal)) * CONV_FACT;
        dist = Math.Sqrt(xVal * xVal + yVal * yVal);
        return;
    }

    //3. A method that takes the polar coordinates as parameters and displays them.
    //DisplayResults() method
    //Purpose: Display the original values as well as the polar coordinates
    //Inputs: x, y, angle, and distance
    //Returns: none
    //Preconditions: x and y must not be negative, angle and distance must have been evaluated
    //Postconditions: none
    //--------------------------------------------------------------------------------------------------------------------------------------------
    static void DisplayResults(int xVal, int yVal, double ang, double dist)
    {
        Console.WriteLine(RESULTS, xVal, yVal, ang, dist);
        Console.ReadLine();
    }

}//End class Program
