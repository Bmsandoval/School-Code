﻿// File Prologue
// Name: Bryan Sandoval
// CS 1400 Section 001
// Project: Lab11
// Date: 2/24/2013
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;

static class Program
{
    const string RQSTSCORES = "Please enter a Bowling scores for up to 10 players (Name Score)\nIf less than 10 players, simply press 'enter' to finish:\n";
    const string INVALID = "You have entered an invalid selection\nPress enter to try again";
    const string RESULT = "{0} had the highest score at {1}\n{2} had the lowest score at {3}\nThe average score was about {4:f2}\nThank you, Please press enter to continue...";
    const string DISPLAYSCORES = "\t{0} {1}\n";
    const string TOTALS = "Total Scores: \n";
    const int SIZE = 10;
    static void Main()
    {
        string[] arrNames = new string[] { "z", "z", "z", "z", "z", "z", "z", "z", "z", "z"};
        int[] arrScores = new int[] {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
        int asize = 0;

        RequestInput(out arrScores, out arrNames, ref asize);
        SortEach(arrScores, arrNames, out arrNames, out arrScores, asize);
        DisplayResults(arrScores, arrNames, asize);

        return;
    }//End Main()

    //1. A method that takes the names and scores from the user and tests if the scores are ints
    //RequestInput() method
    //Purpose: to populate the strings
    //Inputs: None
    //Returns: An array of names and an array of scores in parallel arrays
    //Preconditions: None
    //Postconditions: Scores must be valid ints
    //--------------------------------------------------------------------------------------------------------------------------------------------

    static void RequestInput(out int[] scores, out string[] names, ref int asize)
    {
        string userInput = "";
        string[] parsedInput = new string[] { "", "" };
        scores = new int[10];
        names = new string[10];


        Console.Write(RQSTSCORES);
        for (int i = 0; i < names.Length; i++)
        {
            //do
            //{
                Console.Write("Score: ");
                userInput = Console.ReadLine();
                if (userInput == "")
                {
                    break;
                }
                else
                {
                    parsedInput = userInput.Split();
                    if (parsedInput.Length == 1)
                    {
                        Console.WriteLine(INVALID);
                        Console.ReadLine();
                        Console.Clear();
                        Console.Write(RQSTSCORES);
                        continue;
                    }
                    else
                    {
                        if (int.TryParse(parsedInput[1], out scores[i]))
                        {

                            names[i] = parsedInput[0];
                            asize++;
                            continue;
                        }
                        else
                        {
                            Console.WriteLine(INVALID);
                            Console.ReadLine();
                            Console.Clear();
                            Console.Write(RQSTSCORES);
                            continue;
                        }
                    }
                }
            //} while (true);
        }

    }
    //2. A method that takes the parallel array data and sorts it by high and low scores
    //SortEach() method
    //Purpose: Sort arrays by value
    //Inputs: Two arrays
    //Returns: Two arrays
    //Preconditions: Two populated arrays to sort.
    //Postconditions: Two sorted arrays
    //--------------------------------------------------------------------------------------------------------------------------------------------
    static void SortEach(int[] scores, string[] names, out string[] namesOut, out int[] scoresOut, int asize)
    {
        scoresOut = new int[SIZE];
        namesOut = new string[SIZE];
        for(int j = 0; j < asize - 1; j++)
        {
            for(int i = 0; i < asize - 1; i++)
            {
                if(scores[i]>=scores[i+1])
                    Swap(ref scores[i], ref scores[i+1]);
                    Swap(ref names[i], ref names[i+1]);
            }
        }
        scoresOut = scores;
        namesOut = names;
        return;

    }


    //3. A method that sorts arrays containing integer elements
    //SortEach() method
    //Purpose: Sort integers
    //Inputs: One array with integer elements
    //Returns: One array with sorted integer elements
    //Preconditions: One populated array
    //Postconditions: One sorted array
    //--------------------------------------------------------------------------------------------------------------------------------------------
    static void Swap(ref int a, ref int b)
    {
        int temp = a;
        a = b;
        b = temp;
    }

    //4. A method that sorts arrays containing string elements
    //SortEach() method
    //Purpose: Sort strings
    //Inputs: One array with strings elements
    //Returns: One array with sorted strings elements
    //Preconditions: One populated array
    //Postconditions: One sorted array
    //--------------------------------------------------------------------------------------------------------------------------------------------
    static void Swap(ref string a, ref string b)
    {
        string temp = a;
        a = b;
        b = temp;
    }


    //5. A method that takes the parallel arrays and prints the data. Will also: display highest/lowest scores, display average scores.
    //DisplayResults() method
    //Purpose: Display scores along with the high/low/avg
    //Inputs: Two arrays
    //Returns: None
    //Preconditions: One populated array of names and one of ints.
    //Postconditions: None
    //--------------------------------------------------------------------------------------------------------------------------------------------
    static void DisplayResults(int[] scores, string[] names, int asize)
    {
        double total = 0.0;
        double result = 0.0;

        for (int i = 0; i <= asize - 1; i++)
        {
            if (scores[i] == -1)
                break;
            else
                total += scores[i];
        }
        Console.WriteLine(TOTALS);
        for (int j = 0; j <= asize - 1; j++)
        {
            if (scores[j] == -1)
                break;
            else
                Console.WriteLine(DISPLAYSCORES, names[j], scores[j]);
        }
        result = total / (double)(asize);

        Console.WriteLine(RESULT, names[asize - 1], scores[asize - 1], names[0], scores[0], result);
        Console.ReadLine();

    }
}//End class Program
