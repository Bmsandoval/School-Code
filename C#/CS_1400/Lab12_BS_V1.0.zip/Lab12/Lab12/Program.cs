﻿// File Prologue
// Name: Bryan Sandoval
// CS 1400 Section 001
// Project: Lab11
// Date: 2/24/2013
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;

static class Program
{
    const string INTRO = "Please enter a Bowling scores for up to 10 players (Josh 110)\nIf less than 10 players, simply press 'enter' on a blank line\n";
    const string RQSTSCORES = "Please enter a name and score: ";
    const string INVALID = "You have entered an invalid selection\nPress enter to try again";
    const string RESULT = "{0} your score of {1} was the highest\n{2} your score of {3} was the lowest\nThe team average for this game was {4}\nThank you, Please press enter to continue...";
    const string DISPLAYHIGH = "\t{0} {1}*\n";
    const string DISPLAYNORM = "\t{0} {1}\n";
    const string TOTALS = "----------------------------Input Complete----------------------------\nThe scores for the game are: \n";
    static void Main()
    {
        string[] arrNames = new string[10];
        int[] arrScores = new int[10];

        RequestInput(out arrScores, out arrNames);
        SortEach(arrScores, arrNames, out arrNames, out arrScores);
        DisplayResults(arrScores, arrNames);

        return;
    }//End Main()

    //1. A method that takes the names and scores from the user and tests if the scores are ints
    //RequestInput() method
    //Purpose: to populate the strings
    //Inputs: None
    //Returns: An array of names and an array of scores in parallel arrays
    //Preconditions: None
    //Postconditions: Scores must be valid ints
    //--------------------------------------------------------------------------------------------------------------------------------------------

    static void RequestInput(out int[] scores, out string[] names)
    {
        string userInput = "";
        string[] parsedInput = new string[] { "", "" };
        scores = new int[10];
        names = new string[10];

        Console.Write(INTRO);
        for (int i = 0; i < names.Length; i++)
        {
            do
            {
                Console.Write(RQSTSCORES);
                userInput = Console.ReadLine();
                if (userInput == null)
                {
                    return;
                }
                else
                {
                    parsedInput = userInput.Split();
                    if (parsedInput.Length == 1)
                    {
                        Console.WriteLine(INVALID);
                        Console.ReadLine();
                        Console.Clear();
                        Console.Write(INTRO);
                        continue;
                    }
                    else
                    {
                        if (int.TryParse(parsedInput[1], out scores[i]))
                        {

                            names[i] = parsedInput[0];
                            break;
                        }
                        else
                        {
                            Console.WriteLine(INVALID);
                            Console.ReadLine();
                            Console.Clear();
                            Console.Write(INTRO);
                            continue;
                        }
                    }
                }
            } while (true);
        }

    }
    //2. A method that takes the parallel array data and sorts it by high and low scores
    //SortEach() method
    //Purpose: Sort arrays by value
    //Inputs: Two arrays
    //Returns: Two arrays
    //Preconditions: Two populated arrays to sort.
    //Postconditions: Two sorted arrays
    //--------------------------------------------------------------------------------------------------------------------------------------------
    static void SortEach(int[] scores, string[] names, out string[] namesOut, out int[] scoresOut)
    {
        scoresOut = new int[10];
        namesOut = new string[10];
        for (int j = 0; j < scores.Length - 1; j++)
        {
            for (int i = 0; i < scores.Length - 1; i++)
            {
                if (scores[i] < scores[i + 1])
                {
                    Swap(ref scores[i], ref scores[i + 1]);
                    Swap(ref names[i], ref names[i + 1]);
                }
            }
        }
        scoresOut = scores;
        namesOut = names;
        return;

    }


    //3. A method that sorts arrays containing integer elements
    //SortEach() method
    //Purpose: Sort integers
    //Inputs: One array with integer elements
    //Returns: One array with sorted integer elements
    //Preconditions: One populated array
    //Postconditions: One sorted array
    //--------------------------------------------------------------------------------------------------------------------------------------------
    static void Swap(ref int a, ref int b)
    {
        int temp = a;
        a = b;
        b = temp;
    }

    //4. A method that sorts arrays containing string elements
    //SortEach() method
    //Purpose: Sort strings
    //Inputs: One array with strings elements
    //Returns: One array with sorted strings elements
    //Preconditions: One populated array
    //Postconditions: One sorted array
    //--------------------------------------------------------------------------------------------------------------------------------------------
    static void Swap(ref string a, ref string b)
    {
        string temp = a;
        a = b;
        b = temp;
    }


    //5. A method that takes the parallel arrays and prints the data. Will also: display highest/lowest scores, display average scores.
    //DisplayResults() method
    //Purpose: Display scores along with the high/low/avg
    //Inputs: Two arrays
    //Returns: None
    //Preconditions: One populated array of names and one of ints.
    //Postconditions: None
    //--------------------------------------------------------------------------------------------------------------------------------------------
    static void DisplayResults(int[] scores, string[] names)
    {
        int total = 0;
        int result = 0;

        for (int i = 0; i <= scores.Length - 1; i++)
        {
            total += scores[i];
        }
        Console.WriteLine(TOTALS);
        for (int j = 0; j <= scores.Length - 1; j++)
        {
            if (j == 0)
            {
                Console.WriteLine(DISPLAYHIGH, names[j], scores[j]);
            }
            else
            {
                if (scores[j] >= 300)
                {
                    Console.WriteLine(DISPLAYHIGH, names[j], scores[j]);
                }
                else
                {
                    Console.WriteLine(DISPLAYNORM, names[j], scores[j]);
                }
            }
        }
        result = total / scores.Length;

        Console.WriteLine(RESULT, names[0], scores[0], names[9], scores[9], result);
        Console.ReadLine();

    }
}//End class Program