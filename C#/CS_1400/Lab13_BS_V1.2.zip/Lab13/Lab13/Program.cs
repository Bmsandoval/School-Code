﻿// File Prologue
// Name: Bryan Sandoval
// CS 1400 Section 001
// Project: Lab13
// Date: 3/3/2013
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;

static class Program
{
    const string USER_Y = "Y";
    const string USER_N = "N";
    const string RQSTINPT = "Wound you like to roll dice? (y/n): ";
    const string INVALID = "You have made an invalid selection\nPress enter to continue";
    const string GOODBYE = "Goodbye";
    const string SNAKEEYES = "You have rolled Snake Eyes";
    const string BOXCARS = "You have rolled Box Cars";
    const string GENERIC = "You have rolled {0} and {1}";
    const int MAX = 7;
    const int BOX = 6;
    const int SNAKE = 1;

    static void Main()
    {

        Dice();

    }//End Main()


    // The Dice Method
    // Purpose: Call UserInput() and Display() methods
    // Parameters: None
    // Returns: None
    static void Dice()
    {
        string input = "";
        do
        {

            input = UserInput();
            if (input == USER_Y)    //if y: generate two random numbers: each between 1 and 6
            {
                Display();
                continue;
            }
            else
            {
                Console.WriteLine(GOODBYE);    //if n: display "goodbye" and quit.
                return;
            }
        } while (true);
    } //End Dice()


    // The UserInput Method
    // Purpose: Request user input and validate it
    // Parameters: None
    // Returns: User's choice as a capital letter.
    static string UserInput()     //get and validate user input for y or n
    {
        do
        {

            string select = "";
            Console.Write(RQSTINPT); //User input requested
            select = Console.ReadLine().ToUpper();
            if (!(select == USER_Y || select == USER_N)) //Validate input as either Y || N
            {
                Console.Clear();
                Console.WriteLine(INVALID);
                Console.ReadLine();
                continue;
            }
            else
            {
                return select;
            }

        } while (true);
    } //End UserInput()


    // The Display Method
    // Purpose: Call random numbers, and display results depending on the results of the randoms.
    // Parameters: None
    // Returns: None
    static void Display()
    {
        int d1 = 0;
        int d2 = 0;
        Random randomNums = new Random();
        d1 = randomNums.Next(1, MAX);
        d2 = randomNums.Next(1, MAX);

        if (!(d1 == BOX && d2 == BOX))
        {
            if (!(d1 == SNAKE && d2 == SNAKE))
            {
                Console.WriteLine(GENERIC, d1, d2);    //for all other cases, display "you rolled ..."
            }
            else
            {
                Console.WriteLine(SNAKEEYES);    //if the two numbers are 1 and 1, display "You rolled snake eyes"
            }
        }
        else
        {
            Console.WriteLine(BOXCARS);     //if the two numbers are 6 and 6, display "You rolled boxcars"
        }
        
    }









}//End class Program
