﻿// File Prologue
// Name: Bryan Sandoval
// CS 1400 Section 001
// Project: Lab14
// Date: 3/5/2013
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;

static class Program
{
    const int DOUBLE = 2;
    const char YES = 'Y';
    const char NO = 'N';
    const string RESTART = "Would you like to start over? (Yes/No)\nSelection: ";
    const string FIRST = "Please enter the first side's value: ";
    const string SECOND = "Please enter the second side's value: ";
    const string PRINT = "\n\tGiven the sides {0:f2} and {1:f2}, the hypotenuse is {2:f2}\n";
    const string INVALID = "You have entered an invalid value\nPress enter to continue...";
    const string RETRY = "Please enter the value for the same side: ";

    static void Main()
    {

        Hypotenuse();

    }//End Main()



    // The Hypotenuse() Method
    // Purpose: Run my program
    // Parameters: None
    // Returns: None

    static void Hypotenuse()
    {
        char test = 'z';
        double sideOne = 0.0;
        double sideTwo = 0.0;
        double hyp = 0.0;

        do
        {
            Console.Write(FIRST);
            sideOne = UserInput(); //get value for side one
            Console.Write(SECOND);
            sideTwo = UserInput(); //get value for size two
            hyp = Calculate(sideOne, sideTwo); // calculate hypotenuse
            PrintResult(sideOne, sideTwo, hyp); // print the results
            continue;
        } while (Loop()); // check if user wants to do it again.
    }

    // The UserInput() Method
    // Purpose: Take user input and validate it.
    // Parameters: None
    // Returns: Double value

    static double UserInput()
    {
        do
        {
            double length = 0.0;
            if (double.TryParse(Console.ReadLine(), out length))
            {
                return length;
            }
            else
            {
                Console.Clear();
                Console.WriteLine(INVALID);
                Console.ReadLine();
                Console.Write(RETRY);
                continue;
            }
        } while (true);
    }


    // The Calculate() Method
    // Purpose: Calculate the hyp (square root of a^2 + b^2)
    // Parameters: Two double side values
    // Returns: One double hypotenuse value

    static double Calculate(double sideOne, double sideTwo)
    {
        double hyp = 0.0;
        hyp = Math.Sqrt(Math.Pow(sideOne, DOUBLE) + Math.Pow(sideTwo, DOUBLE));
        return hyp;
    }

    // The PrintResult() Method
    // Purpose: Print both side lengths and the hyp value
    // Parameters: two double side values and a double hyp value
    // Returns: None
    static void PrintResult(double sideOne, double sideTwo, double hyp)
    {
        Console.WriteLine(PRINT, sideOne, sideTwo, hyp);
        return;
    }

    // The Loop() Method
    // Purpose: Test if user wants to loop back
    // Parameters: None
    // Returns: None
    static bool Loop()
    {
        do
        {
            string loop = "";
            Console.Write(RESTART);
            loop = Console.ReadLine().ToUpper();
            switch (loop[0])
            {
                case YES:
                    Console.Clear();
                    return true;
                case NO:
                    return false;
                default:
                    Console.Clear();
                    Console.WriteLine(INVALID);
                    Console.ReadLine();
                    continue;
            }
        } while (true);
    }
}//End class Program
