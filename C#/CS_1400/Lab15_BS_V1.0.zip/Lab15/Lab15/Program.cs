﻿// File Prologue
// Name: Bryan Sandoval
// CS 1400 Section 001
// Project: Lab15
// Date: 3/15/2013
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;

static class Program
{
    const string RQST = "Enter in a year (for example, 1923): ";
    const string INVALID = "You entered an invalid value";
    const string QUIT = "You have chosen to quit, press enter to continue";
    const string LEAP = "{0} is a leap year.";
    const string NOTLEAP = "{0} is not a leap year.";
    const string RPT = "Do another year (y or n): ";
    const char USER_Y = 'Y';
    const char USER_N = 'N';
    const int FIRST = 4;
    const int SECOND = 100;
    const int THIRD = 400;

    static void Main()
    {
        Leap();

    }//end Main( )



    static void Leap() // my main program
    {
        int year = 0;
        string decision = "";
        do
        {
            Console.Write(RQST);
            if (int.TryParse(Console.ReadLine(), out year))
            {
                if (IsLeap(year))
                    Console.WriteLine(LEAP, year);
                else
                    Console.WriteLine(NOTLEAP, year);
            }
            else
            {
                Console.WriteLine(INVALID);
                Console.ReadLine();
                continue;
            }
            do
            {
                Console.Write(RPT);
                decision = Console.ReadLine().ToUpper();
            } while (decision[0] != USER_Y && decision[0] != USER_N);
        } while (decision[0] == USER_Y);
        Console.WriteLine(QUIT);
        Console.ReadLine();
        return;
    }

    // The IsLeap method
    // Purpose: Determines if the year given is a leap year
    //               it is a leap year if the year is divisible by 4,
    //               but not divisible by 100 unless it is divisible by 400
    // Parameters: The year, as a positive integer
    // Returns: A Boolean, true if the year is a leap year
    // ------------------------------------------------------------------
    // write the code for the method IsLeap here. 
    static bool IsLeap(int date)
    {
        if (date % FIRST == 0)
        {
            if (date % SECOND == 0)
            {
                if (date % THIRD == 0)
                {
                    return true;
                }

                return false;
            }
            return true;
        }
            
            return false;
    }


}//End class Program