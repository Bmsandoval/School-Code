﻿// File Prologue
// Name: Bryan M. Sandoval
// CS 1400 Section 001
// Project: Lab17
// Date: 3/20/2013
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;
using System.IO;

static class Program
{
    const string DISPLAY = "For t = {0:f2}\nand v = {1:f2}\nWind chill index = {2:f2}\n";
    const string DOUBSLAS = "\\";
    const string RQSTFILE = "Please enter a file name: ";
    const double SQVAL = 0.16;
    const double FIRSTVAL = 35.74;
    const double SECONDVAL = 0.6215;
    const double THIRDVAL = 35.75;
    const double FOURTHVAL = 0.4275;

    static void Main()
    {
        ReadFile();
    }

    // ReadFile() Method
    // Purpose: Calculate windchill based on wind temperature and speed
    //          using information taken from a file in users mydocs.
    // Inputs: None
    // Outputs: None
    public static void ReadFile()
    {
        string filePath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        string fileName = null;
        string save = null;
        string[] split = new string[] {"", ""};
        double valueV = 0.0;
        double valueT = 0.0;
        double valueW = 0.0;
        Console.Write(RQSTFILE);
        fileName = filePath + DOUBSLAS + Console.ReadLine();
        StreamReader sr = new StreamReader(fileName);

        do //loops until it reaches the eof.
        {
            save = sr.ReadLine();
            if (save == null)
            {
                break;
            }
            else
            {
                split = save.Split();
                valueV = double.Parse(split[0]);
                valueT = double.Parse(split[1]);
                valueW = FIRSTVAL + SECONDVAL * valueT - THIRDVAL * (Math.Pow(valueV, SQVAL)) + FOURTHVAL * valueT * (Math.Pow(valueV, SQVAL));
                Console.WriteLine(DISPLAY, valueT, valueV, valueW);
                continue;
            }
        } while (true);
        sr.Close();
        Console.ReadLine();
    }//End Main()
}//End class Program