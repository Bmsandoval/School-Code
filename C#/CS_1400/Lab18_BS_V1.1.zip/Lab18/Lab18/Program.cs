﻿// File Prologue
// Name: Bryan Sandoval
// CS 1400 Section 001
// Project: Lab18
// Date: 4/2/2013
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;

static class Program
{
    // some  class level constants
    const int HALVES = 50;
    const int QUARTERS = 25;
    const int DIMES = 10;
    const int NICKELS = 5;
    const int PENNIES = 1;
    const string INVALID = "You did not enter a valid integer!";
    const string INTRO = "I will make change for you.";
    const string RQST = "Enter in an amount between 1 and 99: ";
    const string VALUE = "For {0} you get:";
    const string HALVESPOST = "{0} halves";
    const string QUARTERSPOST = "{0} quarters";
    const string DIMESPOST = "{0} dimes";
    const string NICKELSPOST = "{0} nickels";
    const string PENNIESPOST = "{0} pennies\n";

    static void Main()
    {
        MakeChangeRef();
        MakeChangeOut();
    }//End Main( )


    static void MakeChangeRef()
    {
        int money = 0;  // the value we want to count change for
        Console.WriteLine(INTRO);
        Console.Write(RQST);
        if (int.TryParse(Console.ReadLine(), out money))
        {
            Console.WriteLine(VALUE, money);
            Console.WriteLine(HALVESPOST, ComputeChange(ref money, HALVES));
            Console.WriteLine(QUARTERSPOST, ComputeChange(ref money, QUARTERS));
            Console.WriteLine(DIMESPOST, ComputeChange(ref money, DIMES));
            Console.WriteLine(NICKELSPOST, ComputeChange(ref money, NICKELS));
            Console.WriteLine(PENNIESPOST, ComputeChange(ref money, PENNIES));
            Console.ReadLine();
        }
        else
        {
            Console.WriteLine(INVALID);
            Console.ReadLine();
        }
    }

    static void MakeChangeOut()
    {
        int money = 0;  // the value we want to count change for
        int coinValue = 0;
        Console.WriteLine(INTRO);
        Console.Write(RQST);
        if (int.TryParse(Console.ReadLine(), out money))
        {
            Console.WriteLine(VALUE, money);
            ComputeChange(ref money, HALVES, out coinValue);
            Console.WriteLine(HALVESPOST, coinValue);
            ComputeChange(ref money, QUARTERS, out coinValue);
            Console.WriteLine(QUARTERSPOST, coinValue);
            ComputeChange(ref money, DIMES, out coinValue);
            Console.WriteLine(DIMESPOST, coinValue);
            ComputeChange(ref money, NICKELS, out coinValue);
            Console.WriteLine(NICKELSPOST, coinValue);
            ComputeChange(ref money, PENNIES, out coinValue);
            Console.WriteLine(PENNIESPOST, coinValue);
            Console.ReadLine();
        }
        else
        {
            Console.WriteLine(INVALID);
            Console.ReadLine();
        }
    }
    // ComputeChange()
    // Purpose: find amount of one coin value that can fit in a change value
    // inputs: a change value and a coin value
    // outputs: number of coins that fit in the change value
    static int ComputeChange(ref int changeValue, int coinValue)
    {
        return changeValue / coinValue;

    }//End ComputeChange( )





    // ComputeChange()
    // Purpose: find amount of one coin value that can fit in a change value
    // inputs: a change value and a coin value
    // outputs: number of coins that fit in the change value
    static void ComputeChange(ref int changeValue, int coinValue, out int coin)
    {
        coin = changeValue / coinValue;
        return;

    }
}//End class Program
