﻿

// File Prologue
// Name: Bryan Sandoval
// CS 1400 Section 001
// Project: Lab19
// Date: 4/15/2013
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;

static class Program
{

    const string AVERAGE = "The average score was {0:f2}";
    const string RQSTSCORE = "Please enter a scores for students followed by enter\r\ncan exit by submitting a score of -1 or just hitting enter\r\nStudent Scores:\r\n";
    const string ERROR = "No Scores Given";
    const string PROV_SCORES = "Given the following student's scores:\r\n";
    const string SCORES = "\r\n {0}";

    static void Main()
    {
        Scores();
    }//End Main()

    // Method: Scores()
    // Purpose: Run the program
    // Inputs: None
    // Outputs: None
    // Returns: None
    // ///////////////////////////////////////////////////////////////////////////////////////////
    static void Scores()
    {
        double average = 0.0;
        int[] Scores = new int[] { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
        int length = 0;
        Rqst(ref Scores, out length);
        average = Comp(Scores, length);
        Write(average, Scores, length);
    }

    // Method: Rqst()
    // Purpose: Request all scores from the user
    // Inputs: An empty array of 10 integers
    // Outputs: length of the array
    // Returns: None
    // ///////////////////////////////////////////////////////////////////////////////////////////
    static void Rqst(ref int[] Scores, out int lng)
    {
        string tmp = "";
        Console.Write(RQSTSCORE);
        lng = 0;
        for (int i = 0; i < Scores.Length; i++)
        {
            tmp = Console.ReadLine();
            if (tmp == "")
            {
                return;
            }

            if (int.Parse(tmp) == -1)
            {
                return;
            }

            Scores[i] = int.Parse(tmp);
            lng++;

        }
    }

    // Method: Comp()
    // Purpose: Calculates the average scores
    // Inputs: An array of 10 integers, and an int denoting the length of the array
    // Outputs: None
    // Returns: Average
    // ///////////////////////////////////////////////////////////////////////////////////////////
    static double Comp(int[] Scores, int lng)
    {
        int total = 0;
        double avg = 0.0;
        for (int i = 0; i < (lng); i++)
        {
            total += Scores[i];
        }
        avg = (double)(total) / (double)(lng);
        return avg;
    }

    // Method: Write()
    // Purpose: Display scores and averages
    // Inputs: An array of 10 integers, an int calling length of the array, and a double calling the average score
    // Outputs: None
    // Returns: None
    // ///////////////////////////////////////////////////////////////////////////////////////////

    static void Write(double avg, int[] Scores, int lng)
    {
        if (lng == 0)
        {
            Console.WriteLine(ERROR);
            Console.ReadLine();
            return;
        }
        Console.WriteLine(PROV_SCORES);
        for (int i = 0; i < (lng); i++)
        {
            Console.WriteLine(SCORES, Scores[i]);
        }

        Console.WriteLine(AVERAGE, avg);
    }
}//End class Program

