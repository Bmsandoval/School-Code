﻿// File Prologue
// Name: Bryan Sandoval
// CS 1400 Section 001
// Project: Lab20
// Date: 4/3/2013
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;

static class Program
{
    // declare constants - no magic numbers
    const double BIG = 40000;
    const double SMALL = 25000;
    const double BIG_BONUS = 0.1;
    const double SMALL_BONUS = 0.05;
    const double SMALLER_BONUS = 0.03;
    const string RQST = "Please enter the person's Sales: ";
    const string STATEPAY = "This person's gross pay will be {0}";
    const string REPEAT = "Do you want to do another (y or n)? ";
    const string INVALID = "You have made an invalid selection";
    const string CONTINUE = "Press enter to continue...";
    const string GOODBYE = "Thanks ... goodbye";
    const char USER_Y = 'Y';
    const char USER_N = 'N';

    static void Main()
    {
        Menu();
        Console.ReadLine();
    }//end Main()

    //Menu() method
    //Purpose: Calculate salaries of employees
    //Inputs: None
    //Outputs: None
    static void Menu()
    {
        double sales = 0.0;
        double salary = 0.0;
        double commission = 0.0;
        double pay = 0.0;
        bool check = true;


        do
        {
            Console.Write(RQST);
            if (double.TryParse(Console.ReadLine(), out sales) == false)
            {
                Console.WriteLine(INVALID);
                Console.WriteLine(CONTINUE);
                Console.ReadLine();
                Console.Clear();
                continue;
            }
            else
            {
                if (sales > BIG)
                {
                    commission = sales * BIG_BONUS;
                }
                else
                {
                    if (sales < SMALL)
                    {
                        commission = sales * SMALLER_BONUS;
                    }
                    else
                    {
                        commission = sales * SMALL_BONUS;
                    }
                }
                pay = salary + commission;
                Console.WriteLine(STATEPAY, pay);
                check = Repeat();
            }
        } while (check == true);

        Console.WriteLine(GOODBYE);
    }

    //Repeat() method
    //Purpose: Ask the user if they want to continue.
    //Inputs: None
    //Outputs: Bool value
    static bool Repeat()
    {
        char response = 'Y';

        do
        {
            Console.Write(REPEAT);
            if (char.TryParse(Console.ReadLine().ToUpper(), out response) == true)
            {
                if (response != USER_Y && response != USER_N)
                {
                    Console.WriteLine(INVALID);
                    Console.WriteLine(CONTINUE);
                    Console.ReadLine();
                    Console.Clear();
                    continue;
                }
                else
                {
                    if (response == USER_Y)
                        return true;
                    else
                        return false;
                }
            }
            else
            {
                Console.WriteLine(INVALID);
                Console.WriteLine(CONTINUE);
                Console.ReadLine();
                Console.Clear();
                continue;
            }

        } while (true);
    }
}//end class Program