﻿// File Prologue
// Name: Bryan Sandoval
// CS 1400 Section 001
// Project: Lab21
// Date: 4/3/2013
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;

static class Program
{
    const string OUTERITER = "Iteration {0} for the outer loop";
    const string INNERITER = "\nIteration {0} for the inner loop";
    const string HEADER = "\n\n*****  The sorted array is: *****";
    const string DISPLAY = "{0} ";
    const string SWAP = "Swapping {0} and {1}";

    static void Main()
    {
        Sort();
        Console.ReadLine();
    }

    // Sort() Method
    // Purpose: Sort a list of integers
    // Inputs: None
    // Outputs: None
    // ---------------------------------------------------
    static void Sort()
    {
            // this is the date to be sorted
        int[] theData = { 45, 12, 23, 34 };

        // sort the array in ascending order
        // print out lots of messages so we can see the sort work
        for (int j = 0; j < theData.Length - 1; j++)  // index for outer loop is j
        {
            Console.WriteLine(OUTERITER, j);
            for (int i = 0; i < theData.Length - 1; i++)  // index for inner loop
            {
                Console.WriteLine(INNERITER, i);
                if (theData[i] > theData[i + 1])
                    Swap(ref theData[i], ref theData[i + 1]);
            }
        }
        // print out the sorted array
        Console.WriteLine(HEADER);
        for (int i = 0; i < theData.Length; i++)
        {
            Console.Write(DISPLAY, theData[i]);
        }
        Console.WriteLine();
    }



    // method prototype for the swap routine
    // parameters: two integers, passed by reference
    // routines: none
    // The two integer values are swapped
    // ---------------------------------------------------
    static void Swap(ref int a, ref int b)
    {
        Console.WriteLine(SWAP, a, b);
        int temp = a;
        a = b;
        b = temp;
    }
}