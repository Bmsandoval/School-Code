﻿// File Prologue
// Name: Bryan Sandoval
// CS 1400 Section 001
// Project: Lab22
// Date: 4/24/2013
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;
using System.IO;

static class Program
{
    const int ASIZE = 50;
    const string RQST = "Please enter a file name: ";
    const string PRINT = "The average of the above values is {0:f2}";

    static void Main()
    {
        RunProg();
        Console.ReadLine();
    }//End Main()

    static void RunProg()
    {
        double avg = 0.0;
        int[] values = new int[ASIZE];
        int count = 0;
        count = ReadFile(ref values, count);
        avg = Calculate(values, count);
        Print(avg);
    }

    static int ReadFile(ref int[] array, int count)
    {
        string myDocs = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        string fileName = "";
        string location = "";
        string test = "";

        Console.Write(RQST);
        fileName = Console.ReadLine();
        location = myDocs + "\\" + fileName;
        StreamReader sr = new StreamReader(location);

        for (int i = 0; i < array.Length - 1; i++)
        {
            test = sr.ReadLine();
            if (test == "")
                break;
            else
                array[i] = int.Parse(test);
            Console.WriteLine(test);
            count++;
        }
        sr.Close();
        return count;
    }

    static double Calculate(int[] array, int count)
    {
        int sum = 0;
        double average = 0.0;
        for (int i = 0; i < count - 1; i++)
        {
            sum += array[i];
        }
        average = (double)sum / (double)count;
        return average;
    }

    static void Print(double avg)
    {
        Console.WriteLine(PRINT, avg);
    }
}//End class Program
