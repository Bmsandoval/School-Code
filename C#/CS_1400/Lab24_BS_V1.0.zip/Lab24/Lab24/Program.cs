﻿// File Prologue
// Name: bmsan_000
// CS 1400 Section xxx
// Project: Lab24
// Date: 4/25/2013 3:42:57 PM
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;

static class Program
{
    static void Main()
    {
        Tokens();
        Console.ReadLine();
        // the code for Main ...
    }//end Main()

    static void Tokens()
    {
        // write the code here to
        // 1) create a TokenGiver object using the default constructor.
        TokenGiver myTokenGiver = new TokenGiver();
        // 2) store 10 tokens in it
        myTokenGiver.AddTokens(10);
        // 3) ask the TokenGiver object how many tokens it has and display the result
        Console.WriteLine(myTokenGiver.GetNumTokens());
        // 4) take 2 tokens out of the TokenGiver object
        myTokenGiver.TakeToken();
        myTokenGiver.TakeToken();
        // 5) ask the TokenGiver object how many tokens it has and display the result
        Console.WriteLine(myTokenGiver.GetNumTokens());
    }
}//end class Program

// The TokenGiver class
// Models a machine that dispenses tokens
class TokenGiver
{
    private int numTokens;

    // The Default Constructor
    // Purpose: initialize the number of tokens to zero
    // Parameters: none
    // Returns: none
    public TokenGiver()
    {
        numTokens = 0;
    }

    // The Parameterized Constructor
    // Purpose: initializes the number of tokens
    // Parameters: an integer, the initial number of tokens
    // Returns: none
    public TokenGiver(int t)
    {
        numTokens = t;
    }

    // The AddTokens method
    // Purpose: add tokens to the tokengiver object
    // Parameters: an integer, the number of tokens to add
    // Returns: none
    public void AddTokens(int n)
    {
        numTokens += n;
    }

    // The TakeToken method
    // Purpose: takes a token from the tokengiver object
    // Parameters: none
    // Returns: none
    public void TakeToken()
    {
        numTokens--;
    }

    // The GetNumTokens method
    // Purpose: returns the number of tokens in the object
    // Parameters: none
    // Returns: an integer, the number of tokens in the object
    public int GetNumTokens()
    {
        return numTokens;
    }
}//end class TokenGiver