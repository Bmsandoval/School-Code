﻿// File Prologue
// Name: bmsan_000
// CS 1400 Section xxx
// Project: Lab25
// Date: 4/25/2013 4:16:20 PM
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;

static class Program
{
    static void Main()
    {
        CoinP();
        CoinDP();
        CoinPP();
    }//End Main()

    static void CoinP()
    {
        double moneys = 0.0;
        CoinPurse cp = new CoinPurse();
        cp.EmptyPurse();
        cp.Penny(3);
        cp.Nickel(4);
        cp.Dime(2);
        cp.Quarter(1);
        moneys = cp.CountMoney();
        Console.WriteLine("The purse currently contains ${0:f2}", moneys);
        cp.Dime(-2);
        moneys = cp.CountMoney();
        Console.WriteLine("The purse currently contains ${0:f2}", moneys);
        Console.ReadLine();
    }

    static void CoinDP()
    {
        double moneys = 0.0;
        CoinPurseDP cpdp = new CoinPurseDP();
        cpdp.EmptyPurse();
        cpdp[0] = 3;
        cpdp[1] = 4;
        cpdp[2] = 2;
        cpdp[3] = 1;
        moneys = cpdp.CountMoney();
        Console.WriteLine("The purse currently contains ${0:f2}", moneys);
        cpdp[2] += -2;
        moneys = cpdp.CountMoney();
        Console.WriteLine("The purse currently contains ${0:f2}", moneys);
        Console.ReadLine();
    }

    static void CoinPP()
    {
        double moneys = 0.0;
        CoinPurseP cpp = new CoinPurseP();
        cpp.EmptyPurse();
        cpp[0] = 3;
        cpp[1] = 4;
        cpp[2] = 2;
        cpp[3] = 1;
        moneys = cpp.CountMoney();
        Console.WriteLine("The purse currently contains ${0:f2}", moneys);
        cpp[2] += -2;
        moneys = cpp.CountMoney();
        Console.WriteLine("The purse currently contains ${0:f2}", moneys);
        Console.ReadLine();
    }
}//End class Program


public class CoinPurse
{
    private int _pennies;
    private int _nickels;
    private int _dimes;
    private int _quarters;
    private int _halves;

    public CoinPurse()
    {
        _pennies = 0;
        _nickels = 0;
        _dimes = 0;
        _quarters = 0;
        _halves = 0;
    }

    public void Penny(int p)
    {
        _pennies += p;
    }

    public void Nickel(int n)
    {
        _nickels += n;
    }

    public void Dime(int d)
    {
        _dimes += d;
    }

    public void Quarter(int q)
    {
        _quarters += q;
    }

    public void Half(int h)
    {
        _halves += h;
    }

    public double CountMoney()
    {
        double total = 0.0;

        total = _pennies;
        total += (_nickels * 5);
        total += (_dimes * 10);
        total += (_quarters * 25);
        total += (_halves * 50);

        return (total / 100.0);
    }

    public void EmptyPurse()
    {
        _pennies = 0;
        _nickels = 0;
        _dimes = 0;
        _quarters = 0;
        _halves = 0;
    }
}

public class CoinPurseDP
{
    private int _pennies;
    private int _nickels;
    private int _dimes;
    private int _quarters;
    private int _halves;

    public CoinPurseDP()
    {
        _pennies = 0;
        _nickels = 0;
        _dimes = 0;
        _quarters = 0;
        _halves = 0;
    }

    public int this[int index]
    {
        get
        {
            if (index == 0)
                return _pennies;
            else if (index == 1)
                return _nickels;
            else if (index == 2)
                return _dimes;
            else if (index == 3)
                return _quarters;
            else
                return _halves;
        }

        set
        {
            if (index == 0)
                _pennies = value;
            else if (index == 1)
                _nickels = value;
            else if (index == 2)
                _dimes = value;
            else if (index == 3)
                _quarters = value;
            else if (index == 4)
                _halves = value;
        }
    }

        public double CountMoney()
    {
        double total = 0.0;

        total = _pennies;
        total += (_nickels * 5);
        total += (_dimes * 10);
        total += (_quarters * 25);
        total += (_halves * 50);

        return (total / 100.0);
    }

    public void EmptyPurse()
    {
        _pennies = 0;
        _nickels = 0;
        _dimes = 0;
        _quarters = 0;
        _halves = 0;
    }
}



public class CoinPurseP
{
    private int _pennies;
    private int _nickels;
    private int _dimes;
    private int _quarters;
    private int _halves;

    public CoinPurseP()
    {
        _pennies = 0;
        _nickels = 0;
        _dimes = 0;
        _quarters = 0;
        _halves = 0;
    }

    public int this[int index]
    {
        get
        {
            if (index == 0)
                return _pennies;
            else if (index == 1)
                return _nickels;
            else if (index == 2)
                return _dimes;
            else if (index == 3)
                return _quarters;
            else
                return _halves;
        }

        set
        {
            if (index == 0)
                _pennies = value;
            else if (index == 1)
                _nickels = value;
            else if (index == 2)
                _dimes = value;
            else if (index == 3)
                _quarters = value;
            else if (index == 4)
                _halves = value;
        }
    }

    public double CountMoney()
    {
        double total = 0.0;

        total = _pennies;
        total += (_nickels * 5);
        total += (_dimes * 10);
        total += (_quarters * 25);
        total += (_halves * 50);

        return (total / 100.0);
    }

    public void EmptyPurse()
    {
        _pennies = 0;
        _nickels = 0;
        _dimes = 0;
        _quarters = 0;
        _halves = 0;
    }
}