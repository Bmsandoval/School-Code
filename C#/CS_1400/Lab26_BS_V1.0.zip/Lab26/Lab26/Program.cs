﻿// File Prologue
// Name: bmsan_000
// CS 1400 Section xxx
// Project: Lab26
// Date: 4/25/2013 3:08:55 PM
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;

static class Program
{
    const int SIZE = 5;

    static void Main()
    {
        CInt();
        Console.ReadLine();
    }//End Main()

    static void CInt()
    {
        CInteger[] _numbers = new CInteger[SIZE];

        for(int idx=0; idx < SIZE; idx++)
        {
            _numbers[idx] = new CInteger(idx+5);
        }

        for (int i = 0; i < SIZE; i++)
        {
            Console.WriteLine(_numbers[i].GetValue());
        }


        for (int i = 0; i < SIZE; i++)
        {
            Console.WriteLine(_numbers[i].IValue);
        }
    }

}//End class Program

class CInteger
{
    // const (as well as static) Max Value of an int
    public const int MAXINT = int.MaxValue;
    // const (as well as static) Min Value of an int
    public const int MININT = int.MinValue;
    // the data member is a valid value of the integer
    private int _ivalue;
    /// <summary>
    /// IValue property sets or gets _ivalue that is the value of the
    /// integer.
    /// </summary>
    public int IValue
    {
        get { return _ivalue; }
        set
        {
            if (value >= MININT && value <= MAXINT)
                _ivalue = value;
            else
            {
                _ivalue = 0;
                Console.WriteLine("Invalid int value");
            }
        }
    }
    /// <summary>
    /// Purpose: Default Constructor - Initializes the value of the CInteger to zero
    /// </summary>
    public CInteger()
    {
        _ivalue = 0;
    }

    /// <summary>
    /// Purpose: Parameterized Constructor - Initialize the value 
    /// of the CInteger to the parameter n
    /// </summary>
    /// <param name="n">Valid int</param>
    public CInteger(int n)
    {
        _ivalue = n;
    }
    /// <summary>
    /// Purpose: Sets the value of the CInteger to ival
    /// </summary>
    /// <returns>Valid int</returns>
    /// <param name="ival">Valid int</param>
    public int SetValue(int ival)
    {
        _ivalue = ival;
        return ival;
    }
    /// <summary>
    /// Purpose: Gets the value of the CInteger object
    /// </summary>
    /// <returns>Valid int value</returns>
    public int GetValue()
    {
        return _ivalue;
    }
    /// <summary>
    /// Purpose: Parses the input string to an int or throws
    /// a FormatException.
    /// </summary>
    /// <param name="istrg">String representing the int value</param>
    /// <returns>valid int</returns>
    public int Parse(string istrg)
    {
        int tempInt = 0;
        try
        {
            tempInt = int.Parse(istrg);
        }
        catch (FormatException exp)
        {
            Console.WriteLine(exp.Message);
        }
        catch (Exception exp)
        {
            Console.WriteLine(exp.Message);
        }
        return tempInt;
    }
}//End class CInteger
