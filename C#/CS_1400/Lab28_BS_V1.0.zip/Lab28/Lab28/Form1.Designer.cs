﻿namespace Lab28
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn_Incr = new System.Windows.Forms.Button();
            this.Btn_Decr = new System.Windows.Forms.Button();
            this.Btn_Clr = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.Btn_Ext = new System.Windows.Forms.ToolStripMenuItem();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Btn_Incr
            // 
            this.Btn_Incr.Location = new System.Drawing.Point(83, 46);
            this.Btn_Incr.Name = "Btn_Incr";
            this.Btn_Incr.Size = new System.Drawing.Size(109, 29);
            this.Btn_Incr.TabIndex = 0;
            this.Btn_Incr.Text = "Increment";
            this.Btn_Incr.UseVisualStyleBackColor = true;
            this.Btn_Incr.Click += new System.EventHandler(this.Btn_Incr_Click);
            // 
            // Btn_Decr
            // 
            this.Btn_Decr.Location = new System.Drawing.Point(83, 81);
            this.Btn_Decr.Name = "Btn_Decr";
            this.Btn_Decr.Size = new System.Drawing.Size(109, 29);
            this.Btn_Decr.TabIndex = 0;
            this.Btn_Decr.Text = "Decrement";
            this.Btn_Decr.UseVisualStyleBackColor = true;
            this.Btn_Decr.Click += new System.EventHandler(this.Btn_Decr_Click);
            // 
            // Btn_Clr
            // 
            this.Btn_Clr.Location = new System.Drawing.Point(83, 116);
            this.Btn_Clr.Name = "Btn_Clr";
            this.Btn_Clr.Size = new System.Drawing.Size(109, 29);
            this.Btn_Clr.TabIndex = 0;
            this.Btn_Clr.Text = "Clear";
            this.Btn_Clr.UseVisualStyleBackColor = true;
            this.Btn_Clr.Click += new System.EventHandler(this.Btn_Clr_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Btn_Ext});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(282, 28);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // Btn_Ext
            // 
            this.Btn_Ext.Name = "Btn_Ext";
            this.Btn_Ext.Size = new System.Drawing.Size(45, 24);
            this.Btn_Ext.Text = "Exit";
            this.Btn_Ext.Click += new System.EventHandler(this.Btn_Ext_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(83, 191);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(108, 22);
            this.textBox1.TabIndex = 3;
            this.textBox1.Text = "0";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(282, 253);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Btn_Clr);
            this.Controls.Add(this.Btn_Decr);
            this.Controls.Add(this.Btn_Incr);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Btn_Incr;
        private System.Windows.Forms.Button Btn_Decr;
        private System.Windows.Forms.Button Btn_Clr;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem Btn_Ext;
        private System.Windows.Forms.TextBox textBox1;
    }
}

