﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lab28
{
    public partial class Form1 : Form
    {

        private int _count = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Btn_Ext_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Btn_Incr_Click(object sender, EventArgs e)
        {
            ++_count;
            textBox1.Text = _count.ToString();
        }

        private void Btn_Decr_Click(object sender, EventArgs e)
        {
            if (_count == 0)
                _count = 0;
            else
                --_count;
            textBox1.Text = _count.ToString();
        }

        private void Btn_Clr_Click(object sender, EventArgs e)
        {
            _count = 0;
            textBox1.Text = _count.ToString();
        }

        private void Rtxt_Display_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
