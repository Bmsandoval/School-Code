﻿// Name: Bryan M. Sandoval
// CS3260 Section 001
// Project: Lab_01A
// Date: 1/9/2015
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Console;

namespace _3260_Lab_01A
{ 
    class Program
    {
        const string HELLO = "Hello, world!";
        /// <summary>
        /// Purpose: Main method, to be used for testing and calling rest of program.
        /// </summary>
        static void Main(string[] args)
        {
            Output();
        }

        /// <summary>
        /// Purpose: Print "Hello, world!" and await user response.
        /// </summary>
        static void Output()
        {
            // Print "Hello, world!"
            WriteLine(HELLO);
            // Wait for user to press button
            ReadLine();
        }

    }
}
