﻿// Name: Bryan M. Sandoval
// CS3260 Section 001
// Project: Lab_01B
// Date: 1/09/2015
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Console;

namespace _3260_Lab_01B
{
    class Program
    {
        const string INT_MAX = "Max int value is: {0}";
        const string INT_MIN = "Min int value is: {0}";
        const string UINT_MAX = "Max Unsigned int value is: {0}";
        const string UINT_MIN = "Min Unsigned int value is: {0}";
        const string CHAR_MAX = "Max char value is: {0}";
        const string CHAR_MIN = "Min char value is: {0}";
        const string FLOAT_MAX = "Max float value is: {0}";
        const string FLOAT_MIN = "Min float value is: {0}";
        const string DEC_MAX = "Max decimal value is: {0}";
        const string DEC_MIN = "Min decimal value is: {0}";
        const string BOOL_MAX = "Max bool value is: true";
        const string BOOL_MIN = "Min bool value is: false";

        /// <summary>
        /// Purpose: Start program, and for testing as needed.
        /// </summary>
        static void Main(string[] args)
        {
            Output();
        }
        /// <summary>
        /// Purpose: Display max and min values for all c# simple data types
        /// </summary>
        static void Output()
        {
            // print Int max and min
            WriteLine(INT_MAX, int.MaxValue);
            WriteLine(INT_MIN, int.MinValue);
            // print UInt max and min
            WriteLine(UINT_MAX, uint.MaxValue);
            WriteLine(UINT_MIN, uint.MinValue);
            // print Char max and min
            WriteLine(CHAR_MAX, char.MaxValue);
            WriteLine(CHAR_MIN, char.MinValue);
            // print Float max and min
            WriteLine(FLOAT_MAX, float.MaxValue);
            WriteLine(FLOAT_MIN, float.MinValue);
            // print Decimal max and min
            WriteLine(DEC_MAX, decimal.MaxValue);
            WriteLine(DEC_MIN, decimal.MinValue);
            // print Bool max and min
            WriteLine(BOOL_MAX);
            WriteLine(BOOL_MIN);
            ReadLine();
        }
    }
}
