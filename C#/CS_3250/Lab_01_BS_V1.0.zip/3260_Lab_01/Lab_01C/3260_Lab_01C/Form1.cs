﻿// Name: Bryan M. Sandoval
// CS3260 Section 001
// Project: Lab_01C
// Date: 1/09/2015
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3260_Lab_01C
{
    public partial class Form1 : Form
    {
        const string INT_MAX = "Max int value is: ";
        const string INT_MIN = "Min int value is: ";
        const string UINT_MAX = "Max Unsigned int value is: ";
        const string UINT_MIN = "Min Unsigned int value is: ";
        const string CHAR_MAX = "Max char value is: ";
        const string CHAR_MIN = "Min char value is: ";
        const string FLOAT_MAX = "Max float value is: ";
        const string FLOAT_MIN = "Min float value is: ";
        const string DEC_MAX = "Max decimal value is: ";
        const string DEC_MIN = "Min decimal value is: ";
        const string BOOL_MAX = "Max bool value is: true";
        const string BOOL_MIN = "Min bool value is: false";
        public Form1()
        {
            InitializeComponent();

            // print Int max and min
            Txt_MaxMin.AppendText(INT_MAX + int.MaxValue);
            Txt_MaxMin.AppendText("\n" + INT_MIN + int.MinValue);
            // print UInt max and min
            Txt_MaxMin.AppendText("\n" + UINT_MAX + uint.MaxValue);
            Txt_MaxMin.AppendText("\n" + UINT_MIN + uint.MinValue);
            // print Char max and min
            Txt_MaxMin.AppendText("\n" + CHAR_MAX + char.MaxValue);
            Txt_MaxMin.AppendText("\n" + CHAR_MIN + char.MinValue);
            // print Float max and min
            Txt_MaxMin.AppendText("\n" + FLOAT_MAX + float.MaxValue);
            Txt_MaxMin.AppendText("\n" + FLOAT_MIN + float.MinValue);
            // print Decimal max and min
            Txt_MaxMin.AppendText("\n" + DEC_MAX + decimal.MaxValue);
            Txt_MaxMin.AppendText("\n" + DEC_MIN + decimal.MinValue);
            // print Bool max and min
            Txt_MaxMin.AppendText("\n" + BOOL_MAX);
            Txt_MaxMin.AppendText("\n" + BOOL_MIN);
        }

        private void Txt_MaxMin_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
