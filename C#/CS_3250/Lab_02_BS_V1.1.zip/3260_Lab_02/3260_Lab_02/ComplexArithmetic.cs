﻿// Name: Bryan M. Sandoval
// CS3260 Section 001
// Project: Lab_02
// Date: 1/19/2015
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;

namespace _3260_Lab_02
{
    /// <summary>
    /// Do arithmetic for complex numbers
    /// </summary>
    class ComplexArithmetic
    {
        /// <summary>
        /// create a blank class
        /// </summary>
        public ComplexArithmetic(){}
        /// <summary>
        /// calculate the result of two complex numbers using a given operator
        /// </summary>
        /// <param name="one"></param>
        /// <param name="two"></param>
        /// <param name="oper"></param> 
        /// <returns></returns> 
        public ComplexData Calculate(ComplexData one, ComplexData two, char oper)
        { 
            ComplexData temp = new ComplexData();
            switch (oper)
            {
                // Add the two complex numbers
                case Program.PLUS: 
                    temp.Real = one.Real + two.Real;
                    temp.Imag = one.Imag + two.Imag;
                    return temp;
                // Subtract two complex numbers
                case Program.MIN:
                    temp.Real = one.Real - two.Real;
                    temp.Imag = one.Imag - two.Imag;
                    return temp;
                // Divide two complex numbers
                case Program.DIV:
                    double tempDenom;
                    // First - Last
                    temp.Real = one.Real * two.Real - one.Imag * (two.Imag * -1);
                    // Inside + Outside
                    temp.Imag = one.Real * (two.Imag * -1) + one.Imag * two.Real;
                    // denominator = real^2 + imaginary(turned real)^2
                    tempDenom = two.Real * two.Real + two.Imag * two.Imag;
                    // simplify
                    temp.Real = temp.Real / tempDenom;
                    temp.Imag = temp.Imag / tempDenom;
                    return temp;
                // Multiply two complex numbers
                case Program.MULT:
                    // first - last
                    temp.Real = one.Real * two.Real - one.Imag * two.Imag;
                    // outside + inside
                    temp.Imag = one.Real * two.Imag + two.Real * one.Imag;

                    return temp;
                default:
                    return null;
            }
        }
    }
}
