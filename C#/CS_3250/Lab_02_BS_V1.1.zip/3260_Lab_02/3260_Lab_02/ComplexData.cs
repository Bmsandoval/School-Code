﻿// Name: Bryan M. Sandoval
// CS3260 Section 001
// Project: Lab_02
// Date: 1/19/2015
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;


namespace _3260_Lab_02
{
    class ComplexData
    {
        private const string PRECISION_TWO = "{0:F2}";
        private const char IMAGINARY = 'i';
        private const string PLUS = " + ";
        private const double NEG_ZERO = -0.00000001;
        private const double POS_ZERO = 0.00000001;
        private double _real;
        private double _imag;

        public double Real
        {
            get
            {
                return _real;
            }

            set
            {
                _real = value;
            }
        }

        public double Imag
        {
            get
            {
                return _imag;
            }

            set
            {
                _imag = value;
            }
        }
        /// <summary>
        /// Default constructor
        /// </summary>
        public ComplexData()
        {
            _real = 0.0;
            _imag = 0.0;
        }
        /// <summary>
        /// Hold a real part and an imaginary part of a single complex number
        /// </summary>
        /// <param name="real"></param> real part
        /// <param name="imag"></param> Imaginary part
        public ComplexData(double real, double imag)
        {
            _real = real;
            _imag = imag;
        }
        /// <summary>
        /// Overridden tostring method
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            string tReal = String.Format(PRECISION_TWO, _real);
            string tImag = String.Format(PRECISION_TWO, _imag);
            string temp = "";
            if (_real < POS_ZERO && _real > NEG_ZERO && _imag < POS_ZERO && _imag > NEG_ZERO)
                return "0";
            if (!(_real < POS_ZERO && _real > NEG_ZERO))
                temp += tReal;
            if (_imag < POS_ZERO && _imag > NEG_ZERO)
                temp += "";
            else if (_imag > POS_ZERO)
                temp += PLUS + tImag + IMAGINARY;
            else
                temp += tImag + IMAGINARY;
            return temp;
        }
    } 
}
