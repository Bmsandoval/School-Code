﻿namespace _3260_Lab_02
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Txt_FirstReal = new System.Windows.Forms.TextBox();
            this.Txt_FirstImag = new System.Windows.Forms.TextBox();
            this.Txt_SecondReal = new System.Windows.Forms.TextBox();
            this.Txt_SecondImag = new System.Windows.Forms.TextBox();
            this.Txt_Display = new System.Windows.Forms.TextBox();
            this.Btn_Calculate = new System.Windows.Forms.Button();
            this.CBx_Operator = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Txt_FirstReal
            // 
            this.Txt_FirstReal.Location = new System.Drawing.Point(7, 63);
            this.Txt_FirstReal.Name = "Txt_FirstReal";
            this.Txt_FirstReal.Size = new System.Drawing.Size(59, 22);
            this.Txt_FirstReal.TabIndex = 21;
            // 
            // Txt_FirstImag
            // 
            this.Txt_FirstImag.Location = new System.Drawing.Point(120, 63);
            this.Txt_FirstImag.Name = "Txt_FirstImag";
            this.Txt_FirstImag.Size = new System.Drawing.Size(59, 22);
            this.Txt_FirstImag.TabIndex = 22;
            // 
            // Txt_SecondReal
            // 
            this.Txt_SecondReal.Location = new System.Drawing.Point(7, 121);
            this.Txt_SecondReal.Name = "Txt_SecondReal";
            this.Txt_SecondReal.Size = new System.Drawing.Size(59, 22);
            this.Txt_SecondReal.TabIndex = 23;
            // 
            // Txt_SecondImag
            // 
            this.Txt_SecondImag.Location = new System.Drawing.Point(120, 121);
            this.Txt_SecondImag.Name = "Txt_SecondImag";
            this.Txt_SecondImag.Size = new System.Drawing.Size(59, 22);
            this.Txt_SecondImag.TabIndex = 24;
            // 
            // Txt_Display
            // 
            this.Txt_Display.Enabled = false;
            this.Txt_Display.Location = new System.Drawing.Point(7, 174);
            this.Txt_Display.Name = "Txt_Display";
            this.Txt_Display.Size = new System.Drawing.Size(172, 22);
            this.Txt_Display.TabIndex = 25;
            // 
            // Btn_Calculate
            // 
            this.Btn_Calculate.Location = new System.Drawing.Point(56, 204);
            this.Btn_Calculate.Name = "Btn_Calculate";
            this.Btn_Calculate.Size = new System.Drawing.Size(75, 23);
            this.Btn_Calculate.TabIndex = 26;
            this.Btn_Calculate.Text = "Calculate";
            this.Btn_Calculate.UseVisualStyleBackColor = true;
            this.Btn_Calculate.Click += new System.EventHandler(this.Btn_Calculate_Click);
            // 
            // CBx_Operator
            // 
            this.CBx_Operator.FormattingEnabled = true;
            this.CBx_Operator.Location = new System.Drawing.Point(70, 90);
            this.CBx_Operator.Name = "CBx_Operator";
            this.CBx_Operator.Size = new System.Drawing.Size(41, 24);
            this.CBx_Operator.TabIndex = 28;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(85, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 17);
            this.label1.TabIndex = 30;
            this.label1.Text = "+";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(85, 126);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 17);
            this.label2.TabIndex = 31;
            this.label2.Text = "+";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(36, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 17);
            this.label3.TabIndex = 32;
            this.label3.Text = "Input in for a+bi";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 43);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 17);
            this.label4.TabIndex = 33;
            this.label4.Text = "Real";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(20, 101);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 17);
            this.label5.TabIndex = 34;
            this.label5.Text = "Real";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(117, 43);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 17);
            this.label6.TabIndex = 35;
            this.label6.Text = "Imaginary";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(117, 101);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 17);
            this.label7.TabIndex = 36;
            this.label7.Text = "Imaginary";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(67, 154);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 17);
            this.label8.TabIndex = 37;
            this.label8.Text = "Result";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(185, 63);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(11, 17);
            this.label9.TabIndex = 38;
            this.label9.Text = "i";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(185, 121);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(11, 17);
            this.label10.TabIndex = 39;
            this.label10.Text = "i";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(200, 238);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CBx_Operator);
            this.Controls.Add(this.Btn_Calculate);
            this.Controls.Add(this.Txt_Display);
            this.Controls.Add(this.Txt_SecondImag);
            this.Controls.Add(this.Txt_SecondReal);
            this.Controls.Add(this.Txt_FirstImag);
            this.Controls.Add(this.Txt_FirstReal);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Txt_FirstReal;
        private System.Windows.Forms.TextBox Txt_FirstImag;
        private System.Windows.Forms.TextBox Txt_SecondReal;
        private System.Windows.Forms.TextBox Txt_SecondImag;
        private System.Windows.Forms.TextBox Txt_Display;
        private System.Windows.Forms.Button Btn_Calculate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox CBx_Operator;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
    }
}

