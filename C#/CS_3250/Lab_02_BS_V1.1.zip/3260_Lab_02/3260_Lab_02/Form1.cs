﻿// Name: Bryan M. Sandoval
// CS3260 Section 001
// Project: Lab_02
// Date: 1/19/2015
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;
using System.Windows.Forms;
using System.Globalization;


namespace _3260_Lab_02
{
    public partial class Form1 : Form
    {
        const string PARSE_ERROR = "Error: Cannot parse";
        ComplexArithmetic compAR = new ComplexArithmetic();
        char opertr;
        public Form1()
        {
            InitializeComponent();
            CBx_Operator.Items.Add(Program.PLUS);
            CBx_Operator.Items.Add(Program.MIN);
            CBx_Operator.Items.Add(Program.MULT);
            CBx_Operator.Items.Add(Program.DIV);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Btn_Calculate_Click(object sender, EventArgs e)
        {
            // allow user to do whole host of things
            var numberStyle = NumberStyles.AllowLeadingWhite | NumberStyles.AllowTrailingWhite | NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign;

            double firstReal = 0.0;
            double secondReal = 0.0;
            double firstImag = 0.0;
            double secondImag = 0.0;
            // Try-Catch for user input errors
            try
            {
                // Parse user input to doubles
                firstReal = double.Parse(Txt_FirstReal.Text.ToString(), numberStyle);
                secondReal = double.Parse(Txt_SecondReal.Text.ToString(), numberStyle);
                firstImag = double.Parse(Txt_FirstImag.Text.ToString(), numberStyle);
                secondImag = double.Parse(Txt_SecondImag.Text.ToString(), numberStyle);
                // put doubles into ComplexData objects
                ComplexData compOne = new ComplexData(firstReal, firstImag);
                ComplexData compTwo = new ComplexData(secondReal, secondImag);
                // grab operator
                opertr = char.Parse(CBx_Operator.Text);
                // call ComplexArithmetic.Calculate
                ComplexData result = compAR.Calculate(compOne, compTwo, opertr);
                // Display result
                Txt_Display.Clear();
                Txt_Display.AppendText(result.ToString());
            }
            // Catch error with user input
            catch(FormatException)
            {
                // Display error
                Txt_Display.Clear();
                Txt_Display.AppendText(PARSE_ERROR);
            }
        }
    }
}
