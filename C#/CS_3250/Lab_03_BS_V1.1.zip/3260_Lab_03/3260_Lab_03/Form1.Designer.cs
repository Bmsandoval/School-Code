﻿namespace _3260_Lab_03
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Txt_Output = new System.Windows.Forms.RichTextBox();
            this.Btn_TestData = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Txt_Output
            // 
            this.Txt_Output.Location = new System.Drawing.Point(12, 12);
            this.Txt_Output.Name = "Txt_Output";
            this.Txt_Output.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Txt_Output.Size = new System.Drawing.Size(213, 355);
            this.Txt_Output.TabIndex = 12;
            this.Txt_Output.Text = "";
            // 
            // Btn_TestData
            // 
            this.Btn_TestData.Location = new System.Drawing.Point(12, 374);
            this.Btn_TestData.Name = "Btn_TestData";
            this.Btn_TestData.Size = new System.Drawing.Size(213, 23);
            this.Btn_TestData.TabIndex = 14;
            this.Btn_TestData.Text = "Test Data";
            this.Btn_TestData.UseVisualStyleBackColor = true;
            this.Btn_TestData.Click += new System.EventHandler(this.Btn_TestData_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(237, 406);
            this.Controls.Add(this.Btn_TestData);
            this.Controls.Add(this.Txt_Output);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.RichTextBox Txt_Output;
        private System.Windows.Forms.Button Btn_TestData;
    }
}

