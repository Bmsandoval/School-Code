﻿// Name: Bryan M. Sandoval
// CS3260 Section 001
// Project: Lab_03
// Date: 1/26/2015
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace _3260_Lab_03
{
    public partial class Form1 : Form
    {
        private const string NewLine = "\n";
        private const char COMMENT = '#';
        private List<Employee> empList = new List<Employee>();
        // private string filePath = Path.Combine(Directory.GetCurrentDirectory(), "\\PreLoad.txt");
        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// user clicks test data button
        /// </summary>
        private void Btn_TestData_Click(object sender, EventArgs e)
        {
            StringReader reader = new StringReader(_3260_Lab_03.Properties.Resources.PreLoad);
            string empType = "";
            string firstName = "";
            string lastName = "";
            string empID = "";
            double optOne = 0;
            int optTwo = 0;
            double salesComm = 0;
            // Add all employees from a file.
            while (reader.Peek() != -1)
            {
                // ignore any commented lines
                while (reader.Peek() == COMMENT)
                    reader.ReadLine();
                // grab the blank line between employees
                reader.ReadLine();
                // pull all base information
                empType = reader.ReadLine();
                firstName = reader.ReadLine();
                lastName = reader.ReadLine();
                empID = reader.ReadLine();
                double.TryParse(reader.ReadLine(), out optOne);
                // grab extra one from hourly, two from sales.
                if (empType == Employee.HOURLY)
                {
                    int.TryParse(reader.ReadLine(), out optTwo);
                }
                else if (empType == Employee.SALES)
                {
                    int.TryParse(reader.ReadLine(), out optTwo);
                    double.TryParse(reader.ReadLine(), out salesComm);
                }
                // create new objects, cast to employee, and add to employee list.
                switch (empType)
                {
                    case Employee.SALARY:
                        empList.Add((Employee)new Salary(firstName, lastName, empID, Employee.SALARY, optOne));
                        break;
                    case Employee.CONTRACT:
                        empList.Add((Employee)new Contract(firstName, lastName, empID, Employee.CONTRACT, optOne));
                        break;
                    case Employee.HOURLY:
                        empList.Add((Employee)new Hourly(firstName, lastName, empID, Employee.HOURLY, optOne, optTwo));
                        break;
                    case Employee.SALES:
                        empList.Add((Employee)new Sales(firstName, lastName, empID, Employee.SALES, optOne, optTwo, salesComm));
                        break;
                    default:
                        break;
                }
            }
            reader.Close();
            // print result.
            foreach(Employee emp in empList)
            {
                switch(emp.EmpType)
                {
                    case Employee.HOURLY:
                        Txt_Output.AppendText(((Hourly)emp).ToString() + NewLine);
                        break;
                    case Employee.SALARY:
                        Txt_Output.AppendText(((Salary)emp).ToString() + NewLine);
                        break;
                    case Employee.CONTRACT:
                        Txt_Output.AppendText(((Contract)emp).ToString() + NewLine);
                        break;
                    case Employee.SALES:
                        Txt_Output.AppendText(((Sales)emp).ToString() + NewLine);
                        break;
                    default:
                        break;
                }
            }
        }
    }
}
