﻿// Name: Bryan M. Sandoval
// CS3260 Section 001
// Project: Lab_04
// Date: 4/23/2015
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_04
{
    /// <summary>
    /// Holds Employee objects. Overrides ToString() and employs indexing.
    /// </summary>
    class BusinessRules
    {
        private const string NEWLINE = "\n";
        private Employee[] _eArray = new Employee[10];
        private int _size = 10; // Current max array size
        private int _length = 0; //Number of elements in the array. 0 for empty array
        public BusinessRules() { }

        /// <summary>
        /// Empty contents of array
        /// </summary>
        ~BusinessRules()
        {
            for (int i = 0; i < _size; i++)
                _eArray[i] = null;
        }
        /// <summary></summary>
        /// <returns>Current max array size</returns>
        public int Size()
        {
            return _size;
        }
        /// <summary>
        /// Adds a single employee object to the array
        /// </summary>
        /// <param name="empAdd">Employee object</param>
        public void Push(Employee empAdd)
        {
            if (empAdd != null)
                _eArray[++_length] = empAdd;
        }
        /// <summary>Calls ToString() on each item in the array.</summary>
        /// <returns>Formatted string containing all member data</returns>
        public override string ToString()
        {
            String returnString = null;
            for (int i = 0; i < _size; i++)
            {
                if (_eArray[i] == null)
                    continue;
                switch (_eArray[i].EmpType)
                {
                    case Employee.HOURLY:
                        returnString += (((Hourly)_eArray[i]).ToString() + NEWLINE);
                        break;
                    case Employee.SALARY:
                        returnString += (((Salary)_eArray[i]).ToString() + NEWLINE);
                        break;
                    case Employee.CONTRACT:
                        returnString += (((Contract)_eArray[i]).ToString() + NEWLINE);
                        break;
                    case Employee.SALES:
                        returnString += (((Sales)_eArray[i]).ToString() + NEWLINE);
                        break;
                    default:
                        break;
                }
            }
            return returnString;
        }
    }
}
