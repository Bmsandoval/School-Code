﻿// Name: Bryan M. Sandoval
// CS3260 Section 001
// Project: Lab_04
// Date: 4/23/2015
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Lab_04
{
    public partial class MainForm : Form
    {

        //private const char COMMENT = '#';
        private BusinessRules empList = new BusinessRules();
        //private List<Employee> empList = new List<Employee>();
        // private string filePath = Path.Combine(Directory.GetCurrentDirectory(), "\\PreLoad.txt");
        String fNameOne = "Josh";
        String fNameTwo = "Jack";
        String fNameThree = "John";
        String fNameFour = "Jill";
        String lNameOne = "Jeffereys";
        String lNameTwo = "Johnson";
        String lNameThree = "Jackson";
        String lNameFour = "Kensington";
        String eIDOne = "1";
        String eIDTwo = "2";
        String eIDThree = "3";
        String eIDFour = "4";
        Double Salary = 3000;
        Double Wage = 4000;
        Double Hours = 40;
        Double Rate = 20;
        int Sales = 20;
        Double Commission = 100;

        public MainForm()
        {
            InitializeComponent();
        }
        /// <summary>
        /// user clicks test data button
        /// </summary>
        private void Btn_TestData_Click(object sender, EventArgs e)
        {
            empList.Push((Employee)new Salary(fNameOne, lNameOne, eIDOne, Employee.SALARY, Salary));
            empList.Push((Employee)new Contract(fNameTwo, lNameTwo, eIDTwo, Employee.CONTRACT, Wage));
            empList.Push((Employee)new Hourly(fNameThree, lNameThree, eIDThree, Employee.HOURLY, Rate, Hours));
            empList.Push((Employee)new Sales(fNameFour, lNameFour, eIDFour, Employee.SALES, Salary, Sales, Commission));
            Txt_Output.AppendText(empList.ToString());
        }
    }
}