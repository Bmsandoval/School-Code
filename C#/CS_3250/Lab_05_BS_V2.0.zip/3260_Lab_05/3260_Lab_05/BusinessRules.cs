﻿// Name: Bryan M. Sandoval
// CS3260 Section 001
// Project: Lab_05
// Date: 2/9/2015
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3260_Lab_05
{
    /// <summary>
    /// Manages DArray
    /// Overrides ToString() and employs indexing.
    /// </summary>
    class BusinessRules
    {
        private const string NEWLINE = "\n";
        /// <summary>
        /// Default constructor
        /// </summary>
        public BusinessRules() {}

        /// <summary>
        /// Adds a single employee object to the array
        /// </summary>
        /// <param name="empAdd">Employee object</param>
        public void Push(Employee empAdd)
        {
            DArray.Instance.AddValue(empAdd);
        }

        /// <summary>Calls ToString() on each item in the array.</summary>
        /// <returns>Formatted string containing all member data</returns>
        public override string ToString()
        {
            String returnString = null;
            foreach (Employee emp in DArray.Instance)
            {
                switch (emp.EmpType)
                {
                    case Employee.HOURLY:
                        returnString += (((Hourly)emp).ToString() + NEWLINE);
                        break;
                    case Employee.SALARY:
                        returnString += (((Salary)emp).ToString() + NEWLINE);
                        break;
                    case Employee.CONTRACT:
                        returnString += (((Contract)emp).ToString() + NEWLINE);
                        break;
                    case Employee.SALES:
                        returnString += (((Sales)emp).ToString() + NEWLINE);
                        break;
                    default:
                        break;
                }
            }
            return returnString;
        }
    }
}