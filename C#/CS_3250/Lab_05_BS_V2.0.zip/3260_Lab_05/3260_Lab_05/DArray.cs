﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3260_Lab_05
{
    /// <summary>
    /// Purpose: Hold Employee objects
    /// </summary>
    public sealed class DArray : IEnumerable<Employee>
    {
        static readonly DArray _instance = new DArray();
        private int _AIndex = 0;
        private int _Capacity;
        private Employee[] _RArray;
        private Employee[] _TempArray;
        private int _Top;

        /// <summary>
        /// Gives instance of the object to the caller
        /// </summary>
        public static DArray Instance
        {
            get
            {
                return _instance;
            }
        }

        /// <summary>
        /// Empties out the contents of the array for garbage collection
        /// </summary>
        ~DArray()
        {
            for(int i = 0; i < _Capacity; i++)
            {
                _RArray[i] = null;
            }
        }

        /// <summary>
        /// Creates a new employee object of size 4. set's the capacity and top location.
        /// </summary>
        DArray()
        {
            _RArray = new Employee[4];
            _Capacity = 4;
            _Top = 0;
        }

        /// <summary>
        /// Allows pushing to the top of the array.
        /// </summary>
        /// <param name="empAdd"></param>
        public void AddValue(Employee empAdd)
        {
            if (_Top == _Capacity)
                Resize();
            _RArray[_Top++] = empAdd;

        }

        /// <summary>
        /// IEnumerator, included to allow use of foreach.
        /// </summary>
        /// <returns></returns>
        IEnumerator<Employee> IEnumerable<Employee>.GetEnumerator()
        {
            _AIndex = 0;
            while (true)
            {
                if (_RArray[_AIndex] == null)
                    break;
                yield return _RArray[_AIndex];
                _AIndex++;
            }
        }

        /// <summary>
        /// Unparameterized GetEnumerator required, not used.
        /// </summary>
        /// <returns></returns>
        IEnumerator IEnumerable.GetEnumerator()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Doubles array size
        /// </summary>
        public void Resize()
        {
            _TempArray = new Employee[_Capacity];
            // put all data elements in a temporary array
            _RArray.CopyTo(_TempArray, 0);
            // Make new array with double capacity
            _RArray = new Employee[_Capacity *= 2];
            // Move elements from temp back to normal array
            _TempArray.CopyTo(_RArray, 0);
            // clean up
            for(int i = 0; i < _Capacity/2; i++)
            {
                _TempArray[i] = null;
            }
            _TempArray = null;
        }

        /// <summary>
        /// Allows indexing into the array.
        /// </summary>
        /// <param name="idx"></param>
        /// <returns></returns>
        public Employee this[int idx]
        {
            get
            {
                if (idx > -1 && idx < _Capacity)
                    if (_RArray[idx] != null)
                        return _RArray[idx];
                return null;
            }

            set
            {
                if (idx > -1 && idx < _Capacity)
                    _RArray[idx] = value;
            }
        }
    }
}
