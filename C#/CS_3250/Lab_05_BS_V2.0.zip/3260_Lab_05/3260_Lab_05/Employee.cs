﻿// Name: Bryan M. Sandoval
// CS3260 Section 001
// Project: Lab_05
// Date: 2/9/2015
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3260_Lab_05
{
    //*************************************************************************************************** Employee
    /// <summary>
    /// abstract class Employee
    /// Purpose: Hold employee information
    /// </summary>
    public abstract class Employee
    {
        public const string HOURLY = "Hourly";
        public const string SALES = "Sales";
        public const string SALARY = "Salary";
        public const string CONTRACT = "Contract";
        protected const string OUT_BASE = "{0}\nName: {1} {2}\nID: {3} \n";
        protected const string OUT_SALES = "Sales: {0}\nCommission: {1}\n";
        protected const string OUT_CONTRACT = "Contract Wage: {0}\n";
        protected const string OUT_SALARY = "Salary: {0}\n";
        protected const string OUT_HOURLY = "Hourly Rate: {0}\nHours Worked: {1}\n";

        // Variables: EmpID, EmpType, FirstName, LastName
        private string _empID;
        private string _empType;
        private string _firstName;
        private string _lastName;

        // Getters & Setters
        public string EmpID
        {
            get
            {
                return _empID;
            }

            set
            {
                _empID = value;
            }
        }

        public string EmpType
        {
            get
            {
                return _empType;
            }

            set
            {
                _empType = value;
            }
        }

        public string FirstName
        {
            get
            {
                return _firstName;
            }

            set
            {
                _firstName = value;
            }
        }

        public string LastName
        {
            get
            {
                return _lastName;
            }

            set
            {
                _lastName = value;
            }
        }
        /// <summary>
        /// Employee object. Cannot be instantiated.
        /// </summary>
        /// <param name="fName"></param>
        /// <param name="lName"></param>
        /// <param name="eID"></param>
        /// <param name="empType"></param>
        public Employee(string fName, string lName, string eID, string empType)
        {
            _firstName = fName;
            _lastName = lName;
            _empID = eID;
            _empType = empType;
        }

        /// <summary>
        /// Calculate employee's pay. Will vary by employee type.
        /// </summary>
        /// <param name="tax"></param>
        /// <returns>Double representing post-tax pay</returns>
        //public abstract double CalculatePay(double tax);

        public override string ToString()
        {
            return string.Format(OUT_BASE, _empType, _firstName, _lastName, _empID);
        }
    }
    //*************************************************************************************************** Hourly
    /// <summary>
    /// Sealed class Hourly inherits from Employee
    /// </summary>
    public sealed class Hourly : Employee
    {
        // Properties: HourlyRate, HoursWorked
        private double _hourlyRate;
        private double _hoursWorked;

        // Getters & Setters
        public double HourlyRate
        {
            get
            {
                return _hourlyRate;
            }

            set
            {
                _hourlyRate = value;
            }
        }

        public double HoursWorked
        {
            get
            {
                return _hoursWorked;
            }

            set
            {
                _hoursWorked = value;
            }
        }
        /// <summary>
        /// Create an Hourly Employee object.
        /// </summary>
        /// <param name="fName">First Name</param>
        /// <param name="lName">Last Name</param>
        /// <param name="eID">Employee ID</param>
        /// <param name="empType">Employee Type</param>
        /// <param name="hRate">Hourly Rate</param>
        /// <param name="hWorked">Hours Worked</param>
        public Hourly(string fName, string lName, string eID, string empType, double hRate, double hWorked) : base(fName, lName, eID, empType)
        {
            HourlyRate = hRate;
            HoursWorked = hWorked;
        }

        /// <summary>
        /// CalculatePay {Hourly Rate * Hours Worked}
        /// </summary>
        /// <param name="tax"></param>
        /// <returns>Double representing post-tax pay</returns>
        //public override double CalculatePay(double tax)
        //{
        //    return 0;
        //}
        public override string ToString()
        {
            //string tString = base.ToString() + "Hourly Rate: %s\nHours Worked: %s\n", HourlyRate, HoursWorked;
            return base.ToString() + string.Format(OUT_HOURLY, HourlyRate, HoursWorked);
        }
    }
    //************************************************************************************************* Contract
    /// <summary>
    /// Sealed class Contract inherits from Employee
    /// </summary>
    public sealed class Contract : Employee
    {
        // Properties: ContractWage
        private double _contractWage;

        // Getters & Setters
        public double ContractWage
        {
            get
            {
                return _contractWage;
            }

            set
            {
                _contractWage = value;
            }
        }
        /// <summary>
        /// Create a Contract Employee object.
        /// </summary>
        /// <param name="fName">First Name</param>
        /// <param name="lName">Last Name</param>
        /// <param name="eID">Employee ID</param>
        /// <param name="empType">Employee Type</param>
        /// <param name="cWage">Contract Wage</param>
        public Contract(string fName, string lName, string eID, string empType, double cWage) : base(fName, lName, eID, empType)
        {
            ContractWage = cWage;
        }

        /// <summary>
        /// Override CalculatePay {ContractWage}
        /// </summary>
        /// <param name="tax"></param>
        /// <returns>Double representing post-tax pay</returns>
        //public override double CalculatePay(double tax)
        //{
        //    return 0;
        //}
        public override string ToString()
        {
            return base.ToString() + string.Format(OUT_CONTRACT, ContractWage);
        }
    }
    //*************************************************************************************************** Salary
    /// <summary>
    /// (NON-sealed) class Salary inherits from Employee
    /// </summary>
    public class Salary : Employee
    {
        // Properties: MonthlySalary
        private double _monthlySalary;

        // Getters & Setters
        public double MonthlySalary
        {
            get
            {
                return _monthlySalary;
            }

            set
            {
                _monthlySalary = value;
            }
        }
        /// <summary>
        /// Create a Salary Employee object.
        /// </summary>
        /// <param name="fName">First Name</param>
        /// <param name="lName">Last Name</param>
        /// <param name="eID">Employee ID</param>
        /// <param name="empType">Employee Type</param>
        /// <param name="mSal">Monthly Salary</param>
        public Salary(string fName, string lName, string eID, string empType, double mSal) : base(fName, lName, eID, empType)
        {
            MonthlySalary = mSal;
        }

        /// <summary>
        /// Override CalculatePay {MonthlySalary}
        /// </summary>
        /// <param name="tax">Double representing post-tax pay</param>
        /// <returns></returns>
        //public override double CalculatePay(double tax)
        //{
        //    return 0;
        //}
        public override string ToString()
        {
            return base.ToString() + string.Format(OUT_SALARY, MonthlySalary);
        }
    }
    //**************************************************************************************************** Sales
    /// <summary>
    /// Sealed class Sales inherits from Salary
    /// </summary>
    public sealed class Sales : Salary
    {
        // Properties: Commission, GrossSales
        private double _commission;
        private double _grossSales;

        // Getters & Setters
        public double Commission
        {
            get
            {
                return _commission;
            }

            set
            {
                _commission = value;
            }
        }

        public double GrossSales
        {
            get
            {
                return _grossSales;
            }

            set
            {
                _grossSales = value;
            }
        }
        /// <summary>
        /// Create a Sales Employee object.
        /// </summary>
        /// <param name="fName">First Name</param>
        /// <param name="lName">Last Name</param>
        /// <param name="eID">Employee ID</param>
        /// <param name="empType">Employee Type</param>
        /// <param name="mSal">Monthly Salary</param>
        /// <param name="gSales">Gross Sales</param>
        /// <param name="salesComm">Commission</param>
        public Sales(string fName, string lName, string eID, string empType, double mSal, int gSales, double salesComm) : base(fName, lName, eID, empType, mSal)
        {
            GrossSales = gSales;
            Commission = salesComm;
        }

        /// <summary>
        /// CalculatePay {Commision based on gross sales}
        /// </summary>
        /// <param name="tax"></param>
        /// <returns>Double representing post-tax pay</returns>
        //public override double CalculatePay(double tax)
        //{
        //    return 0;
        //}
        public override string ToString()
        {
            return base.ToString() + string.Format(OUT_SALES, GrossSales, Commission);
        }
    }
}