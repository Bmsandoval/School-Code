﻿// Name: Bryan M. Sandoval
// CS3260 Section 001
// Project: Lab_05
// Date: 2/9/2015
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace _3260_Lab_05
{
    /// <summary>
    /// User interaction
    /// </summary>
    public partial class MainForm : Form
    {

        //private const char COMMENT = '#';
        private BusinessRules empList = new BusinessRules();
        //private List<Employee> empList = new List<Employee>();
        // private string filePath = Path.Combine(Directory.GetCurrentDirectory(), "\\PreLoad.txt");
        String fNameOne = "Josh";
        String fNameTwo = "Jack";
        String fNameThree = "John";
        String fNameFour = "Jill";
        String fNameFive = "Legend";
        String fNameSix = "Avatar";
        String lNameOne = "Jeffereys";
        String lNameTwo = "Johnson";
        String lNameThree = "Jackson";
        String lNameFour = "Kensington";
        String lNameFive = "Korra";
        String lNameSix = "Aang";
        String eIDOne = "1";
        String eIDTwo = "2";
        String eIDThree = "3";
        String eIDFour = "4";
        String eIDFive = "5";
        String eIDSix = "6";
        Double Salary = 3000;
        Double Wage = 4000;
        Double Hours = 40;
        Double Rate = 20;
        int Sales = 20;
        Double Commission = 100;

        /// <summary>
        /// Initializes the form
        /// </summary>
        public MainForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// user clicks test data button, inserts test data and provides output.
        /// </summary>
        private void Btn_TestData_Click(object sender, EventArgs e)
        {
            empList.Push((Employee)new Salary(fNameOne, lNameOne, eIDOne, Employee.SALARY, Salary));
            empList.Push((Employee)new Contract(fNameTwo, lNameTwo, eIDTwo, Employee.CONTRACT, Wage));
            empList.Push((Employee)new Hourly(fNameThree, lNameThree, eIDThree, Employee.HOURLY, Rate, Hours));
            empList.Push((Employee)new Sales(fNameFour, lNameFour, eIDFour, Employee.SALES, Salary, Sales, Commission));
            empList.Push((Employee)new Hourly(fNameFive, lNameFive, eIDFive, Employee.HOURLY, Rate, Hours));
            empList.Push((Employee)new Sales(fNameSix, lNameSix, eIDSix, Employee.SALES, Salary, Sales, Commission));
            Txt_Output.AppendText(empList.ToString());
        }
    }
}