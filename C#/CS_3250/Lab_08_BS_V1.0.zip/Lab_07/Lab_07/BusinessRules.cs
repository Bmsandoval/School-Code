﻿// Name: Bryan M. Sandoval
// CS3260 Section 001
// Project: Lab_07
// Date: 4/20/2015
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace Lab_07
{


    /// <summary>
    /// Manages DArray
    /// Overrides ToString() and employs indexing.
    /// </summary>
    public sealed class BusinessRules
    {

        private const string NOT_ENROLLED = "GPA: N/A\nGPA Required: {0}\nAllowed Credits: {1}\n\nEnrolled Classes:\n\nEmployee not currently enrolled in any classes";
        private const string ENROLLED = "GPA: {0}\nGPA Required: {1}\nAllowed Credits: {2}\n\nEnrolled Classes:\n\n";
        private const string NULL_EMP = "No information on file for employee with ID: ";

        private const string NEWLINE = "\n";
        private const string A = "A";
        private const string A_Minus = "A-";
        private const string B_Plus = "B+";
        private const string B = "B";
        private const string B_Minus = "B-";
        private const string C_Plus = "C+";
        private const string C = "C";
        private const string C_Minus = "C-";
        private const string D_Plus = "D+";
        private const string D = "D";
        private const string D_Minus = "D-";
        private const string E = "E";
        private const string MIN_GPA = "E";

        private const int MIN_CRED = 0;

        // Used to convert letter format grades into double format grades
        SortedDictionary<string, double> letterToDouble = new SortedDictionary<string, double>
        {
            {A, 4.00 },
            {A_Minus, 3.70 },
            {B_Plus, 3.33 },
            {B, 3.00 },
            {B_Minus, 2.70 },
            {C_Plus, 2.30 },
            {C, 2.00 },
            {C_Minus, 1.70 },
            {D_Plus, 1.30 },
            {D, 1.00 },
            {D_Minus, .70 },
            {E, 0.0 }
        };

        FileIO file = new FileIO();

        static readonly BusinessRules _instance = new BusinessRules();
        public SortedDictionary<uint, Employee> _empDB = new SortedDictionary<uint, Employee>();
        /// <summary>
        /// Default constructor
        /// </summary>
        public BusinessRules() { }
        public static BusinessRules Instance
        {
            get
            {
                return _instance;
            }
        }

        /// <summary>
        /// Saves the database to the disk through the FileIO class
        /// </summary>
        public void SaveDB()
        {
            try
            {
                file.DB = _empDB;
                file.openDB();
                file.writeDB();
                file.closeDB();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Reads the database from disk through the FileIO class
        /// </summary>
        public void LoadDB()
        {
            try
            {
                file.openDB();
                file.readDB();
                file.closeDB();
                _empDB = file.DB;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public string Name(uint empNum)
        {
            return _empDB[empNum].FirstName + " " + _empDB[empNum].LastName;
        }

        public string Print_Classes(uint empID)
        {
            string returnString = "";
            string listCourses = "";
            int cred = 0;
            double grade = 0.0;
            int allowedCredits = MIN_CRED;
            string reqGPA = MIN_GPA;

            switch (_empDB[empID].EmpType)
            {
                case Employee.HOURLY:
                    allowedCredits = (((Hourly)_empDB[empID]).MAX_CREDITS);
                    reqGPA = (((Hourly)_empDB[empID]).GPA_REQUIRED);
                    break;
                case Employee.SALARY:
                    allowedCredits = (((Salary)_empDB[empID]).MAX_CREDITS);
                    reqGPA = (((Salary)_empDB[empID]).GPA_REQUIRED);
                    break;
                case Employee.CONTRACT:
                    allowedCredits = (((Contract)_empDB[empID]).MAX_CREDITS);
                    reqGPA = (((Contract)_empDB[empID]).GPA_REQUIRED);
                    break;
                case Employee.SALES:
                    allowedCredits = (((Sales)_empDB[empID]).MAX_CREDITS);
                    reqGPA = (((Sales)_empDB[empID]).GPA_REQUIRED);
                    break;
                default:
                    break;
            }


            if (_empDB[empID]._Classes.Count > 0)
            {
                foreach (Course c in _empDB[empID]._Classes.Values)
                {
                    grade += letterToDouble[c.CGrade] * c.Credits;
                    cred += c.Credits;
                    listCourses += c.ToString();
                }
                double gpa = Math.Round((grade / (double)cred),2);
                if (gpa > letterToDouble[reqGPA])
                    returnString += string.Format(ENROLLED, gpa.ToString(), letterToDouble[reqGPA].ToString(), allowedCredits.ToString());
                else
                    returnString += string.Format(ENROLLED, gpa.ToString(), letterToDouble[reqGPA].ToString(), MIN_CRED);
                returnString += listCourses;
                return returnString;
            }
            else
            {
                return string.Format(NOT_ENROLLED, reqGPA, allowedCredits);
            }
        }


        /// <summary>
        /// Provides for indexing into _empDB
        /// </summary>
        /// <param name="idx"></param>
        /// <returns></returns>
        public Employee this[uint idx]
        {
            get
            {
                if (idx < _empDB.Count)
                    if (_empDB[idx] != null)
                        return _empDB[idx];
                return null;
            }

            set
            {
                if (idx < _empDB.Count)
                {
                    _empDB[idx] = value;
                }
            }
        }
        /// <summary>
        /// Adds a single employee object to the array
        /// </summary>
        /// <param name="empAdd">Employee object</param>
        public void Push(Employee empAdd)
        {
            _empDB.Add(empAdd.EmpID, empAdd);
        }

        /// <summary>Calls ToString() on each item in the array.</summary>
        /// <returns>Formatted string containing all member data</returns>
        public override string ToString()
        {
            String returnString = null;
            foreach (uint emp in _empDB.Keys)
            {
                if (null == _empDB[emp])
                {
                    returnString += (NULL_EMP + emp + NEWLINE);
                    continue;
                }
                switch (_empDB[emp].EmpType)
                {
                    case Employee.HOURLY:
                        returnString += (((Hourly)_empDB[emp]).ToString() + NEWLINE);
                        break;
                    case Employee.SALARY:
                        returnString += (((Salary)_empDB[emp]).ToString() + NEWLINE);
                        break;
                    case Employee.CONTRACT:
                        returnString += (((Contract)_empDB[emp]).ToString() + NEWLINE);
                        break;
                    case Employee.SALES:
                        returnString += (((Sales)_empDB[emp]).ToString() + NEWLINE);
                        break;
                    default:
                        break;
                }
            }
            return returnString;
        }
    }


}