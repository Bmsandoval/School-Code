﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_07
{
    [Serializable]public class Course
    {
        const string COURSE_OUT = "UVU Course ID: {0}\nCourse Description: {1}\nCourse Grade: {2}\nApproved Date: {3}\nCourse Credits: {4}\n\n";
        private string _cID;
        private string _desc;
        private string _cGrade;
        private string _dateApproved;
        private int _credits;

        public string CID
        {
            get
            {
                return _cID;
            }

            set
            {
                _cID = value;
            }
        }

        public string Desc
        {
            get
            {
                return _desc;
            }

            set
            {
                _desc = value;
            }
        }

        public string CGrade
        {
            get
            {
                return _cGrade;
            }

            set
            {
                _cGrade = value;
            }
        }

        public string DateApproved
        {
            get
            {
                return _dateApproved;
            }

            set
            {
                _dateApproved = value;
            }
        }

        public int Credits
        {
            get
            {
                return _credits;
            }

            set
            {
                _credits = value;
            }
        }

        public Course(string cID, string desc, string cGrade, string dateApp, int cred)
        {
            CID = cID;
            Desc = desc;
            CGrade = cGrade;
            DateApproved = dateApp;
            Credits = cred;
        }
        public override string ToString()
        {
            return string.Format(COURSE_OUT, CID, Desc, CGrade, DateApproved, Credits);
        }
    }
}
