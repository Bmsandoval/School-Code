﻿// Name: Bryan M. Sandoval
// CS3260 Section 001
// Project: Lab_07
// Date: 4/20/2015
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace Lab_07
{

    /// <summary>
    /// Handles the interaction with the disk
    /// </summary>
    class FileIO : object, IFileAccess
    {
        private const string DIALOG_TITLE = "Open/Save File";
        private const string DEFAULT_DIR = @"C:\";
        private FileStream _fs;
        private BinaryFormatter _bf;
        private SortedDictionary<uint, Employee> _empDB;
        public SortedDictionary<uint, Employee> DB
        {
            get
            {
                return _empDB;
            }

            set
            {
                _empDB = value;
            }
        }

        /// <summary>
        /// Handles writing to a file
        /// </summary>
        public void writeDB()
        {
            try
            {
                _bf = new BinaryFormatter();
                _bf.Serialize(_fs, _empDB.Count);
                foreach (var emp in _empDB)
                {
                    _bf.Serialize(_fs, emp.Key);
                    if (emp.Value != null)
                    {
                        _bf.Serialize(_fs, 0);
                        _bf.Serialize(_fs, emp.Value);
                        _bf.Serialize(_fs, emp.Value._Classes.Count());
                        if (emp.Value._Classes.Count() > 0)
                        {
                            foreach(var clss in emp.Value._Classes)
                            {
                                _bf.Serialize(_fs, clss.Value);
                            }
                        }
                    }
                    else
                        _bf.Serialize(_fs, 1);
                }
                _fs.Flush();
                _bf = null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Handles reading from a file
        /// </summary>
        public void readDB()
        {
            try
            {
                _empDB = new SortedDictionary<uint, Employee>();
                _bf = new BinaryFormatter();
                _fs.Seek(0, SeekOrigin.Begin);
                int empCount = (int)(_bf.Deserialize(_fs));
                for(int i = 0; i < empCount; i++)
                {
                    uint key = (uint)(_bf.Deserialize(_fs));
                    int isNull = (int)(_bf.Deserialize(_fs));
                    if(1 == isNull)
                    {
                        _empDB[key] = null;
                    }
                    else
                    {
                        _empDB[key] = (Employee)(_bf.Deserialize(_fs));
                        int classCount = (int)(_bf.Deserialize(_fs));
                        _empDB[key].InitDic();
                        for(int j = 0; j < classCount; j++)
                        {
                            Course tmpCourse = (Course)(_bf.Deserialize(_fs));
                            _empDB[key]._Classes.Add(tmpCourse.CID, tmpCourse);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Opens a new file
        /// </summary>
        public void openDB()
        {
            try
            {
                OpenFileDialog theDialog = new OpenFileDialog();
                theDialog.Title = DIALOG_TITLE;
                theDialog.InitialDirectory = DEFAULT_DIR;
                if (theDialog.ShowDialog() == DialogResult.OK)
                {
                    _fs = new FileStream(theDialog.FileName, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                }
            }
            catch (Exception ex)
            {
                throw ex;

            }
        }

        /// <summary>
        /// Closes current file
        /// </summary>
        public void closeDB()
        {
            try
            {
                _fs.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }//end class FileIO

    /// <summary>
    /// Typical Interface things
    /// </summary>
    interface IFileAccess
    {
        void writeDB();
        void readDB();
        void openDB();
        void closeDB();
        SortedDictionary<uint, Employee> DB { get; set; }
    }//end interface IFileAccess
}
