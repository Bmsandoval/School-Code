﻿// Name: Bryan M. Sandoval
// CS3260 Section 001
// Project: Lab_07
// Date: 4/20/2015
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------


namespace Lab_07
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Btn_TestData = new System.Windows.Forms.Button();
            this.Btn_SaveDB = new System.Windows.Forms.Button();
            this.Btn_LoadDB = new System.Windows.Forms.Button();
            this.Tab_EmpOptions = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.RTxt_Output = new System.Windows.Forms.RichTextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.EPv_Search = new System.Windows.Forms.ErrorProvider(this.components);
            this.RTxt_CourseShow = new System.Windows.Forms.RichTextBox();
            this.Btn_CourseAdd = new System.Windows.Forms.Button();
            this.Txt_CID = new System.Windows.Forms.TextBox();
            this.Txt_Desc = new System.Windows.Forms.TextBox();
            this.Txt_Grade = new System.Windows.Forms.TextBox();
            this.Txt_Approval = new System.Windows.Forms.TextBox();
            this.Txt_Credits = new System.Windows.Forms.TextBox();
            this.Lbl_Emp = new System.Windows.Forms.Label();
            this.EPv_AddCourse = new System.Windows.Forms.ErrorProvider(this.components);
            this.Btn_Search = new System.Windows.Forms.Button();
            this.Txt_EID = new System.Windows.Forms.TextBox();
            this.Tab_EmpOptions.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.EPv_Search)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EPv_AddCourse)).BeginInit();
            this.SuspendLayout();
            // 
            // Btn_TestData
            // 
            this.Btn_TestData.Location = new System.Drawing.Point(12, 371);
            this.Btn_TestData.Name = "Btn_TestData";
            this.Btn_TestData.Size = new System.Drawing.Size(135, 23);
            this.Btn_TestData.TabIndex = 14;
            this.Btn_TestData.Text = "Test Data";
            this.Btn_TestData.UseVisualStyleBackColor = true;
            this.Btn_TestData.Click += new System.EventHandler(this.Btn_TestData_Click);
            // 
            // Btn_SaveDB
            // 
            this.Btn_SaveDB.Location = new System.Drawing.Point(188, 371);
            this.Btn_SaveDB.Name = "Btn_SaveDB";
            this.Btn_SaveDB.Size = new System.Drawing.Size(103, 23);
            this.Btn_SaveDB.TabIndex = 15;
            this.Btn_SaveDB.Text = "Save DB";
            this.Btn_SaveDB.UseVisualStyleBackColor = true;
            this.Btn_SaveDB.Click += new System.EventHandler(this.Btn_SaveDB_Click);
            // 
            // Btn_LoadDB
            // 
            this.Btn_LoadDB.Location = new System.Drawing.Point(332, 371);
            this.Btn_LoadDB.Name = "Btn_LoadDB";
            this.Btn_LoadDB.Size = new System.Drawing.Size(103, 23);
            this.Btn_LoadDB.TabIndex = 16;
            this.Btn_LoadDB.Text = "Load DB";
            this.Btn_LoadDB.UseVisualStyleBackColor = true;
            this.Btn_LoadDB.Click += new System.EventHandler(this.Btn_LoadDB_Click);
            // 
            // Tab_EmpOptions
            // 
            this.Tab_EmpOptions.Controls.Add(this.tabPage1);
            this.Tab_EmpOptions.Controls.Add(this.tabPage2);
            this.Tab_EmpOptions.Location = new System.Drawing.Point(12, 12);
            this.Tab_EmpOptions.Name = "Tab_EmpOptions";
            this.Tab_EmpOptions.SelectedIndex = 0;
            this.Tab_EmpOptions.Size = new System.Drawing.Size(430, 341);
            this.Tab_EmpOptions.TabIndex = 17;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.RTxt_Output);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(422, 312);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "View Database";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // RTxt_Output
            // 
            this.RTxt_Output.Location = new System.Drawing.Point(0, 0);
            this.RTxt_Output.Name = "RTxt_Output";
            this.RTxt_Output.ReadOnly = true;
            this.RTxt_Output.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.RTxt_Output.Size = new System.Drawing.Size(422, 312);
            this.RTxt_Output.TabIndex = 12;
            this.RTxt_Output.Text = "";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.Btn_Search);
            this.tabPage2.Controls.Add(this.Txt_EID);
            this.tabPage2.Controls.Add(this.Lbl_Emp);
            this.tabPage2.Controls.Add(this.Txt_Credits);
            this.tabPage2.Controls.Add(this.Txt_Approval);
            this.tabPage2.Controls.Add(this.Txt_Grade);
            this.tabPage2.Controls.Add(this.Txt_Desc);
            this.tabPage2.Controls.Add(this.Txt_CID);
            this.tabPage2.Controls.Add(this.Btn_CourseAdd);
            this.tabPage2.Controls.Add(this.RTxt_CourseShow);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(422, 312);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Add Benefits";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // EPv_Search
            // 
            this.EPv_Search.ContainerControl = this;
            // 
            // RTxt_CourseShow
            // 
            this.RTxt_CourseShow.Location = new System.Drawing.Point(3, 6);
            this.RTxt_CourseShow.Name = "RTxt_CourseShow";
            this.RTxt_CourseShow.ReadOnly = true;
            this.RTxt_CourseShow.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.RTxt_CourseShow.Size = new System.Drawing.Size(234, 300);
            this.RTxt_CourseShow.TabIndex = 13;
            this.RTxt_CourseShow.Text = "";
            // 
            // Btn_CourseAdd
            // 
            this.Btn_CourseAdd.Location = new System.Drawing.Point(243, 283);
            this.Btn_CourseAdd.Name = "Btn_CourseAdd";
            this.Btn_CourseAdd.Size = new System.Drawing.Size(176, 23);
            this.Btn_CourseAdd.TabIndex = 19;
            this.Btn_CourseAdd.Text = "Add Course";
            this.Btn_CourseAdd.UseVisualStyleBackColor = true;
            this.Btn_CourseAdd.Visible = false;
            this.Btn_CourseAdd.Click += new System.EventHandler(this.Btn_CourseAdd_Click);
            // 
            // Txt_CID
            // 
            this.Txt_CID.Location = new System.Drawing.Point(243, 143);
            this.Txt_CID.Name = "Txt_CID";
            this.Txt_CID.Size = new System.Drawing.Size(176, 22);
            this.Txt_CID.TabIndex = 20;
            this.Txt_CID.Text = "Course ID";
            this.Txt_CID.Visible = false;
            // 
            // Txt_Desc
            // 
            this.Txt_Desc.Location = new System.Drawing.Point(243, 171);
            this.Txt_Desc.Name = "Txt_Desc";
            this.Txt_Desc.Size = new System.Drawing.Size(176, 22);
            this.Txt_Desc.TabIndex = 21;
            this.Txt_Desc.Text = "Description";
            this.Txt_Desc.Visible = false;
            // 
            // Txt_Grade
            // 
            this.Txt_Grade.Location = new System.Drawing.Point(243, 199);
            this.Txt_Grade.Name = "Txt_Grade";
            this.Txt_Grade.Size = new System.Drawing.Size(176, 22);
            this.Txt_Grade.TabIndex = 22;
            this.Txt_Grade.Text = "Course Grade";
            this.Txt_Grade.Visible = false;
            // 
            // Txt_Approval
            // 
            this.Txt_Approval.Location = new System.Drawing.Point(243, 227);
            this.Txt_Approval.Name = "Txt_Approval";
            this.Txt_Approval.Size = new System.Drawing.Size(176, 22);
            this.Txt_Approval.TabIndex = 23;
            this.Txt_Approval.Text = "Date Approved";
            this.Txt_Approval.Visible = false;
            // 
            // Txt_Credits
            // 
            this.Txt_Credits.Location = new System.Drawing.Point(243, 255);
            this.Txt_Credits.Name = "Txt_Credits";
            this.Txt_Credits.Size = new System.Drawing.Size(176, 22);
            this.Txt_Credits.TabIndex = 24;
            this.Txt_Credits.Text = "Credits";
            this.Txt_Credits.Visible = false;
            // 
            // Lbl_Emp
            // 
            this.Lbl_Emp.AutoSize = true;
            this.Lbl_Emp.Location = new System.Drawing.Point(243, 9);
            this.Lbl_Emp.Name = "Lbl_Emp";
            this.Lbl_Emp.Size = new System.Drawing.Size(176, 17);
            this.Lbl_Emp.TabIndex = 25;
            this.Lbl_Emp.Text = "Must first open a database";
            // 
            // EPv_AddCourse
            // 
            this.EPv_AddCourse.ContainerControl = this;
            // 
            // Btn_Search
            // 
            this.Btn_Search.Location = new System.Drawing.Point(240, 82);
            this.Btn_Search.Name = "Btn_Search";
            this.Btn_Search.Size = new System.Drawing.Size(176, 23);
            this.Btn_Search.TabIndex = 27;
            this.Btn_Search.Text = "Search";
            this.Btn_Search.UseVisualStyleBackColor = true;
            this.Btn_Search.Visible = false;
            this.Btn_Search.Click += new System.EventHandler(this.Btn_Search_Click_1);
            // 
            // Txt_EID
            // 
            this.Txt_EID.Location = new System.Drawing.Point(243, 54);
            this.Txt_EID.Name = "Txt_EID";
            this.Txt_EID.Size = new System.Drawing.Size(173, 22);
            this.Txt_EID.TabIndex = 26;
            this.Txt_EID.Text = "Employee ID";
            this.Txt_EID.Visible = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(480, 406);
            this.Controls.Add(this.Tab_EmpOptions);
            this.Controls.Add(this.Btn_LoadDB);
            this.Controls.Add(this.Btn_SaveDB);
            this.Controls.Add(this.Btn_TestData);
            this.Name = "MainForm";
            this.Text = "Form1";
            this.Tab_EmpOptions.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.EPv_Search)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EPv_AddCourse)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button Btn_TestData;
        private System.Windows.Forms.Button Btn_SaveDB;
        private System.Windows.Forms.Button Btn_LoadDB;
        private System.Windows.Forms.TabControl Tab_EmpOptions;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.RichTextBox RTxt_Output;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ErrorProvider EPv_Search;
        private System.Windows.Forms.Button Btn_CourseAdd;
        private System.Windows.Forms.RichTextBox RTxt_CourseShow;
        private System.Windows.Forms.Label Lbl_Emp;
        private System.Windows.Forms.TextBox Txt_Credits;
        private System.Windows.Forms.TextBox Txt_Approval;
        private System.Windows.Forms.TextBox Txt_Grade;
        private System.Windows.Forms.TextBox Txt_Desc;
        private System.Windows.Forms.TextBox Txt_CID;
        private System.Windows.Forms.ErrorProvider EPv_AddCourse;
        private System.Windows.Forms.Button Btn_Search;
        private System.Windows.Forms.TextBox Txt_EID;
    }
}