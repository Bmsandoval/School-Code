﻿// Name: Bryan M. Sandoval
// CS3260 Section 001
// Project: Lab_07
// Date: 4/20/2015
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;

namespace Lab_07
{
    /// <summary>
    /// User interaction
    /// </summary>
    public partial class MainForm : Form
    {

        private const string REGEX_ADDCOURSE = @"^[A-Z]{2,3}[0-9]{4}$";
        private const string REGEX_DESCRIPTION = @"^[a-zA-Z0-9_]";
        private const string REGEX_COURSE_GRADE = @"^([A][-]?)|([BCD][+-]?)|[E]$";
        private const string REGEX_DATE_APPROVED = @"^[01][0-9][/][0-3][0-9][/][12][0-9]{3}$";
        private const string REGEX_EID = @"^[0-9]{1,}$";
        private const string REGEX_COURSE_CREDITS = @"^[1-9]$";

        private const string REGEX_DESC_FAILED = "Cannot leave blank";
        private const string REGEX_GRADE_FAILED = "Must be A,B,C,D, or E, followed by a +/-";
        private const string REGEX_APPROVAL_FAILED = "Must be in the form 00/00/0000";
        private const string REGEX_CREDITS_FAILED = "Must be a positive integer between 1 and 9";
        private const string REGEX_ADDCOURSE_FAILED = "Must have a 2-3 letter department followed by a 4 digit course number";
        private const string REGEX_EID_FAILED = "Must be a positive integer 1 or greater";

        private const string TXT_APPROVAL_DEFAULT = "Date Approved";
        private const string TXT_CID_DEFAULT = "Course ID";
        private const string TXT_CREDITS_DEFAULT = "Credits";
        private const string TXT_DESCRIPTION_DEFAULT = "Description";
        private const string TXT_COURSE_GRADE_DEFAULT = "Course Grade";

        private const string SELECT_EMP = "Please select an employee.";
        private const string ERROR_SAVING = "Error: Could not save file to disk.\nOriginal error: ";
        private const string ERROR_LOADING = "Error: Could not load file from disk.\nOriginal error: ";
        private const string BTN_SEARCH_DEFAULT = "Employee ID";
        private const string ADDING_CLASSES = "Adding classes for:\n";
        private const string NO_EMP_FOUND = "No employee found with that ID";

        private const String fNameOne = "Josh";
        private const String fNameTwo = "Jack";
        private const String fNameThree = "John";
        private const String fNameFour = "Jill";
        private const String fNameFive = "Legend";
        private const String fNameSix = "Avatar";
        private const String lNameOne = "Jeffereys";
        private const String lNameTwo = "Johnson";
        private const String lNameThree = "Jackson";
        private const String lNameFour = "Kensington";
        private const String lNameFive = "Korra";
        private const String lNameSix = "Aang";
        private const uint eIDOne = 1;
        private const uint eIDTwo = 2;
        private const uint eIDThree = 3;
        private const uint eIDFour = 4;
        private const uint eIDFive = 5;
        private const uint eIDSix = 6;
        private const uint eIDSeven = 7;
        private const Double Salary = 3000;
        private const Double Wage = 4000;
        private const Double Hours = 40;
        private const Double Rate = 20;
        private const int Sales = 20;
        private const Double Commission = 100;

        private uint currentEmpNum;
        private Match _mtch;
        private int _tag;
        private BusinessRules empList = new BusinessRules();


        /// <summary>
        /// Initializes the form
        /// </summary>
        public MainForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// user clicks test data button, inserts test data and provides output.
        /// </summary>
        private void Btn_TestData_Click(object sender, EventArgs e)
        {
            Lbl_Emp.Text = SELECT_EMP;
            Txt_EID.Show();
            Btn_Search.Show();
            Btn_TestData.Hide();
            RTxt_Output.Clear();
            empList.Push((Employee)new Salary(fNameOne, lNameOne, eIDOne, Employee.SALARY, Salary));
            empList.Push((Employee)new Contract(fNameTwo, lNameTwo, eIDTwo, Employee.CONTRACT, Wage));
            empList.Push((Employee)new Hourly(fNameThree, lNameThree, eIDThree, Employee.HOURLY, Rate, Hours));
            empList.Push((Employee)new Sales(fNameFour, lNameFour, eIDFour, Employee.SALES, Salary, Sales, Commission));
            empList.Push((Employee)new Hourly(fNameFive, lNameFive, eIDFive, Employee.HOURLY, Rate, Hours));
            empList.Push((Employee)new Sales(fNameSix, lNameSix, eIDSix, Employee.SALES, Salary, Sales, Commission));
            empList[eIDSeven] = null;
            RTxt_Output.AppendText(empList.ToString());
        }

        /// <summary>
        /// User clicks the 'save' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Btn_SaveDB_Click(object sender, EventArgs e)
        {
            try
            {
                empList.SaveDB();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ERROR_SAVING + ex.Message);
            }
        }

        /// <summary>
        /// User clicks the 'load' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Btn_LoadDB_Click(object sender, EventArgs e)
        {
            try
            {
                empList.LoadDB();
                RTxt_Output.Clear();
                RTxt_Output.AppendText(empList.ToString());
                RTxt_CourseShow.Clear();
                Txt_Approval.Hide();
                Txt_CID.Hide();
                Txt_Credits.Hide();
                Txt_Desc.Hide();
                Txt_Grade.Hide();
                Btn_TestData.Hide();
                Btn_CourseAdd.Hide();

                Lbl_Emp.Text = SELECT_EMP;
                Txt_EID.Show();
                Btn_Search.Show();
                Btn_Search.Text = BTN_SEARCH_DEFAULT;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ERROR_LOADING + ex.Message);
            }

        }

        private void ValidateInput_Select()
        {
            EPv_Search.Clear();
            EPv_Search.Tag = 0;
            _mtch = Regex.Match(Txt_EID.Text, REGEX_EID);
            if (_mtch.Success == false)
            {
                EPv_Search.SetError(Txt_EID, REGEX_EID_FAILED);
                EPv_Search.Tag = 2;
            }
            if ((_tag = (int)EPv_Search.Tag) > 0)
            {
                return;
            }
            else
            {
                currentEmpNum = Convert.ToUInt32(Txt_EID.Text.ToString());
                RTxt_CourseShow.Clear();
                if (empList._empDB.ContainsKey(currentEmpNum))
                {
                    RTxt_CourseShow.AppendText(empList.Print_Classes(currentEmpNum));
                    Lbl_Emp.Text = ADDING_CLASSES + empList.Name(currentEmpNum);
                    Txt_Approval.Show();
                    Txt_CID.Show();
                    Txt_Credits.Show();
                    Txt_Desc.Show();
                    Txt_Grade.Show();
                    Btn_CourseAdd.Show();
                }
                else
                    RTxt_CourseShow.AppendText(NO_EMP_FOUND);
                
            }
        }

        private void ValidateInput_AddCourse()
        {
            EPv_AddCourse.Clear();
            EPv_AddCourse.Tag = 0;
            _mtch = Regex.Match(Txt_CID.Text, REGEX_ADDCOURSE);
            if (_mtch.Success == false)
            {
                EPv_AddCourse.SetError(Txt_CID, REGEX_ADDCOURSE_FAILED);
                EPv_AddCourse.Tag = 2;
            }

            _mtch = Regex.Match(Txt_Desc.Text, REGEX_DESCRIPTION);
            if (_mtch.Success == false)
            {
                EPv_AddCourse.SetError(Txt_Desc, REGEX_DESC_FAILED);
                EPv_AddCourse.Tag = 2;
            }

            _mtch = Regex.Match(Txt_Grade.Text, REGEX_COURSE_GRADE);
            if (_mtch.Success == false)
            {
                EPv_AddCourse.SetError(Txt_Grade, REGEX_GRADE_FAILED);
                EPv_AddCourse.Tag = 2;
            }

            _mtch = Regex.Match(Txt_Approval.Text, REGEX_DATE_APPROVED);
            if (_mtch.Success == false)
            {
                EPv_AddCourse.SetError(Txt_Approval, REGEX_APPROVAL_FAILED);
                EPv_AddCourse.Tag = 2;
            }

            _mtch = Regex.Match(Txt_Credits.Text, REGEX_COURSE_CREDITS);
            if (_mtch.Success == false)
            {
                EPv_AddCourse.SetError(Txt_Credits, REGEX_CREDITS_FAILED);
                EPv_AddCourse.Tag = 2;
            }

            if ((_tag = (int)EPv_AddCourse.Tag) > 0)
            {
                return;
            }
            else
            {
                empList._empDB[currentEmpNum]._Classes.Add(Txt_CID.Text.ToString(), new Course(Txt_CID.Text.ToString(), Txt_Desc.Text.ToString(), Txt_Grade.Text.ToString(), Txt_Approval.Text.ToString(), Convert.ToInt32(Txt_Credits.Text.ToString())));
                RTxt_CourseShow.Clear();
                RTxt_CourseShow.AppendText(empList.Print_Classes(currentEmpNum));
                Txt_Approval.Text = TXT_APPROVAL_DEFAULT;
                Txt_CID.Text = TXT_CID_DEFAULT;
                Txt_Credits.Text = TXT_CREDITS_DEFAULT;
                Txt_Desc.Text = TXT_DESCRIPTION_DEFAULT;
                Txt_Grade.Text = TXT_COURSE_GRADE_DEFAULT;
            }
        }


        private void Btn_Search_Click(object sender, EventArgs e)
        {
            ValidateInput_Select();
        }

        private void Btn_CourseAdd_Click(object sender, EventArgs e)
        {
            ValidateInput_AddCourse();
        }

        private void Btn_Search_Click_1(object sender, EventArgs e)
        {
            ValidateInput_Select();
        }
    }
}