﻿// Name: Bryan M. Sandoval
// CS3260 Section 001
// Project: Lab_09
// Date: 4/23/2015
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_09
{
    /// <summary>
    /// Nodes for the linked list.
    /// </summary>
    abstract class BaseNode
    {
        private BaseNode _next;
        private BaseNode _prev;
        private uint _nodeNumber;

        public BaseNode NextRearNode
        {
            get
            {
                return _next;
            }

            set
            {
                _next = value;
            }
        }

        public BaseNode NextFrontNode
        {
            get
            {
                return _prev;
            }

            set
            {
                _prev = value;
            }
        }

        public uint NodeNumber
        {
            get
            {
                return _nodeNumber;
            }

            set
            {
                _nodeNumber = value;
            }
        }

        public BaseNode()
        {
            NodeNumber = 0;
        }

        public override string ToString()
        {
            return string.Format("\tNode number: {0}\n", _nodeNumber);
        }
    }

    /// <summary>
    /// Node to store supply information
    /// </summary>
    class SNode : BaseNode
    {
        string _description;
        uint _quantity;
        string _supplyName;
        public SNode(string description, uint quantity, string supplyname)
        {
            _description = description;
            _quantity = quantity;
            _supplyName = supplyname;
        }
        public string Description
        {
            get
            {
                return _description;
            }

            set
            {
                _description = value;
            }
        }

        public uint Quantity
        {
            get
            {
                return _quantity;
            }

            set
            {
                _quantity = value;
            }
        }

        public string SupplyName
        {
            get
            {
                return _supplyName;
            }

            set
            {
                _supplyName = value;
            }
        }
        public override string ToString()
        {
            return base.ToString() + string.Format("\tDescription: {0}\n\tQuantity: {1}\n\tSupply Name: {2}\n\n", _description, _quantity, _supplyName);
        }
    }

    /// <summary>
    /// node to store vehicle information
    /// </summary>
    class CNode : BaseNode
    {
        DateTime _cDate;
        decimal _cost;
        string _description;
        string _makeModel;
        uint _year;
        public CNode(string description, DateTime cDate, decimal cost, string makemodel, uint year)
        {
            _description = description;
            _cDate = cDate;
            _cost = cost;
            _makeModel = makemodel;
            _year = year;
        }

        public DateTime CDate
        {
            get
            {
                return _cDate;
            }

            set
            {
                _cDate = value;
            }
        }

        public decimal Cost
        {
            get
            {
                return _cost;
            }

            set
            {
                _cost = value;
            }
        }

        public string Description
        {
            get
            {
                return _description;
            }

            set
            {
                _description = value;
            }
        }

        public string MakeModel
        {
            get
            {
                return _makeModel;
            }

            set
            {
                _makeModel = value;
            }
        }

        public uint Year
        {
            get
            {
                return _year;
            }

            set
            {
                _year = value;
            }
        }
        public override string ToString()
        {
            return base.ToString() + string.Format("\tDescription: {0}\n\tCDate: {1}\n\tCost: {2}\n\tMake/Model: {3}\n\tYear: {4}\n\n", _description, _cDate, _cost, _makeModel, _year);
        }
    }
}
