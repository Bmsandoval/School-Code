﻿// Name: Bryan M. Sandoval
// CS3260 Section 001
// Project: Lab_09
// Date: 4/23/2015
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_09
{
    /// <summary>
    /// Main program form
    /// </summary>
    public partial class MyAwesomeForm : Form
    {
        private const string S_SUPPLY_1 = "Gizmo";
        private const string S_DESC_1 = "Holds gadgets";
        private const uint S_QUANT_1 = 3;

        private const string S_SUPPLY_2 = "Gadget";
        private const string S_DESC_2 = "Holds gizmos";
        private const uint S_QUANT_2 = 7;

        private DateTime C_CDATE_1 = new DateTime(2008, 5, 1, 8, 30, 52);
        private Decimal C_COST_1 = new Decimal(20.25);
        private const string C_DESC_1 = "Coupe";
        private const string C_MAMO_1 = "Saturn Sc2";
        private const uint C_YEAR_1 = 1998;

        private DateTime C_CDATE_2 = new DateTime(2011, 10, 9, 3, 27, 55);
        private Decimal C_COST_2 = new Decimal(38.75);
        private const string C_DESC_2 = "Hybrid";
        private const string C_MAMO_2 = "Toyota Prius";
        private const uint C_YEAR_2 = 2005;



        /// <summary>
        /// It's magic...
        /// </summary>
        public MyAwesomeForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Activates upon depression of the TestProgram button. tests all program functions
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Btn_TestProgram_Click(object sender, EventArgs e)
        {
            NList list = NList.Instance;
            Btn_TestProgram.Hide();
            // push 4 items on front, display
            RTxt_Output.AppendText("Pushing 2 SNodes and 2 CNodes on front\n");
            list.Push_Front(new SNode(S_DESC_1, S_QUANT_1, S_SUPPLY_1));
            list.Push_Front(new CNode(C_DESC_1, C_CDATE_1, C_COST_1, C_MAMO_1, C_YEAR_1));
            list.Push_Front(new SNode(S_DESC_2, S_QUANT_2, S_SUPPLY_2));
            list.Push_Front(new CNode(C_DESC_2, C_CDATE_2, C_COST_2, C_MAMO_2, C_YEAR_2));
            RTxt_Output.AppendText(list.DisplayList());

            // pop back, display
            RTxt_Output.AppendText("Popping off rear\n");
            list.Pop_Rear();
            RTxt_Output.AppendText(list.DisplayList());

            // Get Data
            RTxt_Output.AppendText("Getting data from popped\n");
            RTxt_Output.AppendText(list.GetData.ToString());

            // pop front, display
            RTxt_Output.AppendText("Popping off front\n");
            list.Pop_Front();
            RTxt_Output.AppendText(list.DisplayList());

            // Get Data
            RTxt_Output.AppendText("Getting data from popped\n");
            RTxt_Output.AppendText(list.GetData.ToString());

            // push temp on back, display
            RTxt_Output.AppendText("Pushing temp back onto the rear\n");
            list.Push_Rear(list.GetData);
            RTxt_Output.AppendText(list.DisplayList());

            // clear list, display
            RTxt_Output.AppendText("Clearing list\n");
            list.ClearList();
            RTxt_Output.AppendText(list.DisplayList());
        }
    }
}
