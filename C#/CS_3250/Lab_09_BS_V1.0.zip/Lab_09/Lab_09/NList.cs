﻿// Name: Bryan M. Sandoval
// CS3260 Section 001
// Project: Lab_09
// Date: 4/23/2015
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_09
{
    /// <summary>
    /// Manages a Linked List
    /// </summary>
    class NList
    {
        // Fields
        private static NList instance;
        BaseNode _FrontNode;
        BaseNode _RearNode;
        static uint _nodeCount;
        BaseNode _TempNode;


        // Properties
        public BaseNode GetFrontNode
        {
            get
            {
                return _FrontNode;
            }

            set
            {
                _FrontNode = value;
            }
        }

        public static uint NodeCount
        {
            get
            {
                return _nodeCount;
            }

            set
            {
                _nodeCount = value;
            }
        }

        public BaseNode GetData
        {
            get
            {
                return _TempNode;
            }

            set
            {
                _TempNode = value;
            }
        }

        public static NList Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new NList();
                }
                return instance;
            }
        }

        /// <summary>
        /// default constructor
        /// </summary>
        private NList()
        {
            _FrontNode = null;
            _RearNode = null;
            NodeCount = 0;
        }

        /// <summary>
        /// pushes a given node onto the rear of the list
        /// </summary>
        /// <param name="node"></param>
        public void Push_Rear(BaseNode node)
        {
            // if list already contains one node
            if (NodeCount > 0)
            {
                _RearNode.NextRearNode = node;
                node.NextFrontNode = _RearNode;
                _RearNode = node;
            }
            else
            {
                // if list empty
                _FrontNode = node;
                _RearNode = node;
            }
            NodeCount++;
            node.NodeNumber = NodeCount;
        }

        /// <summary>
        /// pushes a given node on the front of the list
        /// </summary>
        /// <param name="node"></param>
        public void Push_Front(BaseNode node)
        {
            // if list already contains one node
            if (NodeCount > 0)
            {
                _FrontNode.NextFrontNode = node;
                node.NextRearNode = _FrontNode;
                _FrontNode = node;
                BaseNode tmpNode = _FrontNode;
                while (null != tmpNode)
                {
                    tmpNode.NodeNumber++;
                    tmpNode = tmpNode.NextRearNode;
                }
            }
            else
            {
                // if list empty
                _FrontNode = node;
                _RearNode = node;
                node.NodeNumber = 1;
            }
            NodeCount++;
        }

        /// <summary>
        /// pops a node off the back of the list, and stores it in TempNode
        /// </summary>
        public void Pop_Rear()
        {
            if (0 == NodeCount)
                return;
            _TempNode = _RearNode;
            // if node count is 2 or more
            if (NodeCount > 1)
            {
                _RearNode.NextFrontNode.NextRearNode = null;
                _RearNode = _RearNode.NextFrontNode;
                _TempNode.NextFrontNode = null;
            }
            else
            {
                // if node count is only one
                _TempNode.NextFrontNode = null;
                _TempNode.NextRearNode = null;
                _FrontNode = null;
                _RearNode = null;
            }
            _TempNode.NodeNumber = 0;
            NodeCount--;
        }

        /// <summary>
        /// pops a node off the top of the list, and saves it in TempNode
        /// </summary>
        public void Pop_Front()
        {
            if (0 == NodeCount)
                return;
            _TempNode = _FrontNode;
            if (NodeCount > 1)
            {
                _FrontNode.NextRearNode.NextFrontNode = null;
                _FrontNode = _FrontNode.NextRearNode;
                _TempNode.NextRearNode = null;
                BaseNode tmpNode = _FrontNode;
                while (null != tmpNode)
                {
                    tmpNode.NodeNumber--;
                    tmpNode = tmpNode.NextRearNode;
                }
            }
            else
            {
                // if node count is only one
                _TempNode.NextFrontNode = null;
                _TempNode.NextRearNode = null;
                _FrontNode = null;
                _RearNode = null;
            }
            _TempNode.NodeNumber = 0;
            NodeCount--;
        }

        /// <summary>
        /// Display the full contents of the list
        /// </summary>
        /// <returns></returns>
        public string DisplayList()
        {
            if (null == _FrontNode)
                return "\tList is currently empty.\n";
            BaseNode tmpNode = _FrontNode;
            string returnString = "";
            while (null != tmpNode)
            {
                returnString += tmpNode.ToString();
                tmpNode = tmpNode.NextRearNode;
            }

            return returnString;
        }

        /// <summary>
        /// Removes all nodes from the list, releasing them back to the heap.
        /// </summary>
        public void ClearList()
        {
            BaseNode tmpNode = _FrontNode;
            while (tmpNode.NextRearNode != null)
            {
                tmpNode = tmpNode.NextRearNode;
                tmpNode.NextFrontNode.NextFrontNode = null;
                tmpNode.NextFrontNode.NextRearNode = null;
            }
            tmpNode.NextFrontNode = null;
            _FrontNode = null;
            _RearNode = null;
            _nodeCount = 0;
        }
    }
}
