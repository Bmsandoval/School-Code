﻿// Project Prolog
// Name: Bryan S.
// CS 3260 Section 001
// Project: Lab_10
// Date: 4/24/15
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_10
{
    /// <summary>
    /// Program entry point
    /// </summary>
    class Program
    {
        private const string CONT = "Press 'Enter' to continue...";

        /// <summary>
        /// Start program, woo hoo!
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            TestDelegate test = new TestDelegate();
            test.RunTests();
            Console.WriteLine(CONT);
            Console.ReadLine();
        }
    }
}
