﻿// Project Prolog
// Name: Bryan S.
// CS 3260 Section 001
// Project: Lab_10
// Date: 4/24/15
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Lab_10
{
    delegate string MyDelegate(int i, double d, char c, string s);
    delegate string SomeDel(int i, double d, char c, string s);

    /// <summary>
    /// Does things with delegates
    /// </summary>
    class TestDelegate
    {
        private const string LAMBDA_FUNC = "Func in a lambda, duh!";
        private const string EXP_FUNC = "Expression with a func.";
        private const string CHAIN_DEL = "Chaining Delegates";
        private const string LONELY_DEL = "lonely single delegate :(";
        private const string BORING_FUNC = "This is kindof a boring func...";
        private List<Func<int, double, char, string, string>> _DList;
        //other fields as needed
        /// <summary>
        /// set up all my delegates
        /// </summary>
        public TestDelegate()
        {
            MyDelegate mDel = DelMethod_1;
            SomeDel sDel = DelMethod_3;
            mDel += DelMethod_2;

            Func<int, double, char, string, string> MyFunc = (int i, double d, char c, string s) =>
            {
                Console.WriteLine(LAMBDA_FUNC);
                return s;
            };
            Func<int, double, char, string, string> AnotherFunc = BecauseReasons;
            Expression<Func<int, double, char, string, string>> exp = (i, d, c, s) => s;
            Func<int, double, char, string, string> F = exp.Compile();

            _DList = new List<Func<int, double, char, string, string>>();
            _DList.Add(mDel.Invoke);
            _DList.Add(sDel.Invoke);
            _DList.Add(AnotherFunc);
            _DList.Add(MyFunc);
            Console.WriteLine(EXP_FUNC);
            _DList.Add(F);


            //other statements as needed
        }

        /// <summary>
        /// Throw stuff at my delegates, watch em squirm
        /// </summary>
        public void RunTests()
        {
            int idata = 1;
            double ddata = 5.1;
            char cdata = 'A';
            string sdata = "Method ";
            foreach (Func<int, double, char, string, string> myDel in _DList)
                Console.WriteLine(myDel(idata, ddata++, cdata++, sdata + idata++));
        }

        /// <summary>
        /// first delegate method, to be used as first in the chaining
        /// </summary>
        /// <param name="i"></param>
        /// <param name="d"></param>
        /// <param name="c"></param>
        /// <param name="s"></param>
        /// <returns></returns>
        public string DelMethod_1(int i, double d, char c, string s)
        {
            Console.WriteLine(CHAIN_DEL);
            Console.WriteLine(s);
            return s;
        }
        /// <summary>
        /// Another delegate method, will be the second/final in a del chain
        /// </summary>
        /// <param name="i"></param>
        /// <param name="d"></param>
        /// <param name="c"></param>
        /// <param name="s"></param>
        /// <returns></returns>
        public string DelMethod_2(int i, double d, char c, string s)
        {
            return s;
        }

        /// <summary>
        /// another del method, will be used in a single delegate. Forever alone approves
        /// </summary>
        /// <param name="i"></param>
        /// <param name="d"></param>
        /// <param name="c"></param>
        /// <param name="s"></param>
        /// <returns></returns>
        public string DelMethod_3(int i, double d, char c, string s)
        {
            Console.WriteLine(LONELY_DEL);
            return s;
        }
        /// <summary>
        /// another del method for a func. still pretty lonely, but cooler.
        /// </summary>
        /// <param name="i"></param>
        /// <param name="d"></param>
        /// <param name="c"></param>
        /// <param name="s"></param>
        /// <returns></returns>
        public string BecauseReasons(int i, double d, char c, string s)
        {
            Console.WriteLine(BORING_FUNC);
            return s;
        }
    }//end class TestDelegate

}

