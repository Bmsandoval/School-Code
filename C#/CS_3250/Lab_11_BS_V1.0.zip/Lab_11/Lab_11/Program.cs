﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_11
{
    /// <summary>
    /// program entrypoint
    /// </summary>
    class Program
    {
        /// <summary>
        /// run the data manager
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            DataManager data = new DataManager();
            Console.ReadLine();
        }
    }
}
