#include "Project_01.h"

const int ASIZE = 80;
const int DECIMAL = 2;
const int SINGLE_ADD_ONE = 25;
const int SINGLE_ADD_TWO = 85;
const int SINGLE_ADD_THREE = 181;
const int SINGLE_TAXABLE_ONE = 863;
const int SINGLE_TAXABLE_TWO = 2588;
const int SINGLE_TAXABLE_THREE = 4313;
const int JOINT_ADD_ONE = 40;
const int JOINT_ADD_TWO = 175;
const int JOINT_ADD_THREE = 390;
const int JOINT_TAXABLE_ONE = 1726;
const int JOINT_TAXABLE_TWO = 5176;
const int JOINT_TAXABLE_THREE = 8626;



const double TAX_RATE_ONE = 0.023;
const double TAX_RATE_TWO = 0.033;
const double TAX_RATE_THREE = 0.052;
const double TAX_RATE_FOUR = 0.075;


const string INVALID = "you have entered an invalid value...\n";
const string TAXABLE = "Please enter your taxable income: ";
const string FILEING = "Please enter \"s\" for single or \"m\" for joint filing: ";
const string TOTAL = "\nyour total taxes are $";
const string REPEAT_ONE = "\nwould you like to do another calculation?\n";
const string REPEAT_TWO = "Please enter \"y\" for Yes or \"n\" for No: ";


const char SINGLE = 'S';
const char JOINT = 'M';
const char ACCEPT = 'Y';
const char REJECT = 'N';


void main()
{
	prog();
}

void prog()
{
	char cinput[ASIZE+1];
	char stts = 'a';

	double taxes = 0.0;
	double income = 0.0;

	bool tax = true;
	bool status = true;
	bool restart = true;
	bool valid = true;

	while(restart)
	{
		
		tax = true;
		status = true;
		valid = true;
		stts = 'a';
		
		while(tax)
		{
			cout << TAXABLE;
			cin.getline(cinput,ASIZE);
			if(atof(cinput))
			{
				income = atof(cinput);
				if(income < 0)
					cout << INVALID;
				else
					tax = false;
			}
			else
				cout << INVALID;
		}
		
		while(status)
		{
			cout << FILEING;
			cin.getline(cinput,ASIZE);
			if(toupper(cinput[0]) != SINGLE || toupper(cinput[0]) != JOINT)
			{
				stts = toupper(cinput[0]);
				status = false;
			}
			else
				cout << INVALID;
		}
		
		if(stts = SINGLE)
		{
			if(income <= SINGLE_TAXABLE_ONE)
			{
				taxes = (((income - 0) * TAX_RATE_ONE) + 0);
			}
			else
			{
				if(income <= SINGLE_TAXABLE_TWO)
				{
					taxes = (((income - SINGLE_TAXABLE_ONE) * TAX_RATE_TWO) + SINGLE_ADD_ONE);
				}
				else
				{
					if(income <= SINGLE_TAXABLE_THREE)
					{
						taxes = (((income - SINGLE_TAXABLE_TWO) * TAX_RATE_THREE) + SINGLE_ADD_TWO);
					}
					else
					{
						taxes = (((income - SINGLE_TAXABLE_THREE) * TAX_RATE_FOUR) + SINGLE_ADD_THREE);
					}
				}
			}
		}
		else
		{
			if(income <= JOINT_TAXABLE_ONE)
			{
				taxes = (((income - 0) * TAX_RATE_ONE) + 0);
			}
			else 
			{
				if(income <= JOINT_TAXABLE_TWO)
				{
					taxes = (((income - JOINT_TAXABLE_ONE) * TAX_RATE_TWO) + SINGLE_ADD_ONE);
				}
				else
				{
					if(income <= JOINT_TAXABLE_THREE)
					{
						taxes = (((income - JOINT_TAXABLE_TWO) * TAX_RATE_THREE) + SINGLE_ADD_TWO);
					}
					else
					{
						taxes = (((income - JOINT_TAXABLE_THREE) * TAX_RATE_FOUR) + SINGLE_ADD_THREE);
					}
				}
			}
		}

		cout << TOTAL << fixed << setprecision(DECIMAL) << taxes << endl;
		cout << REPEAT_ONE;
		
		while(valid)
		{
			cout << REPEAT_TWO;
			cin.getline(cinput,ASIZE);
			if(toupper(cinput[0]) != ACCEPT || toupper(cinput[0]) != REJECT)
			{
				valid = false;
			}
			else
				cout << INVALID;
		}

		if(toupper(cinput[0]) == ACCEPT)
			restart = true;
		else
			restart = false;

	}

	system("PAUSE");
}