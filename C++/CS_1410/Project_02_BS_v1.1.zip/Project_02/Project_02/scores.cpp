#include "scores.h"

const int ASIZE = 80;
const int HALF = 2;
const int FAIL = 161;
const int MAX = 400;
const int CHECK = 20;
const int LETTER_OPTIONS = 12;

const string NONE = "0";

const string LETTERS[] = {"F", "D-", "D", "D+", "C-", "C", "C+", "B-", "B", "B+", "A-", "A"};
const string MEDIAN = "Median: ";
const string POINT = "\nPoint count: ";
const string GRADE = "\nGrade: ";
const string FIRST_MID_ERROR = "error, please try again.\nPlease enter the first Midterm exam score: ";
const string SECOND_MID_ERROR = "error, please try again.\nPlease enter the second Midterm exam score: ";
const string FINAL_EXAM_ERROR = "error, please try again.\nPlease enter the Final Exam score: ";
const string HOMEWORK_ERROR = "error, please try again.\nPlease enter a Homework score: ";
const string MIDTERM_ONE = "Please enter the first Midterm exam score: ";
const string MIDTERM_TWO = "Please enter the second Midterm exam score: ";
const string FINAL = "Please enter the Final exam score: ";
const string HOMEWORK = "Please enter a Homework score: ";



// All user input should be tested to be sure that it is a valid integer value, you MUST NOT allow invalid input.

void main()
{
	Scores();

}

void Scores()
{
	int examTotal = 0;
	int median = 0;
	int total = 0;
	string letterGrade = "";

	// Call a function to get and store exam scores. Return int examTotal.
	examTotal = Exam();

	// Call a function to get and store homework scores. Return int median.
	median = Homework();

	total = examTotal + median;
	// 11. The program then calls a function that you have written to calculate and return the letter grade.
	letterGrade = Grade(total);

	// 12. Finally, display the median homework score, the total point count, and the letter grade.
	cout << MEDIAN << median << POINT << total << GRADE << letterGrade << endl;
	system("PAUSE");
}

int Exam()
{
	int state = 0;
	int score = 0;
	int temp = 0;
	int examOne = 0;
	int examTwo = 0;
	int final = 0;
	string input = "";
	char cinput[ASIZE+1];
	// 2. It should ask the user to enter in the score for the first Midterm exam.
	cout << MIDTERM_ONE;
	// 3. This value is read in and saved.
	while(true)
	{
		cin.getline(cinput, ASIZE);
		//getline(cin, input);
		state = cin.rdstate();
		if(state != 0) // this will test for the error codes incase someone hit's ^Z or another ctrl code.
		{
			cin.clear();
			if(cin.rdbuf() -> in_avail() > 0)
 				getline(cin, input);
 			cout << FIRST_MID_ERROR;
			continue;
		}
		if(cinput == "")
		{
 			cout << FIRST_MID_ERROR;
			continue;
		}
		if(cinput == NONE)
			examOne = 0;
			break;
		if(temp = atoi(cinput))
		{
				if(temp < 0)
			{
				cout << FIRST_MID_ERROR;
				continue;
			}
			examOne = temp;
			break;
		}
		cout << FIRST_MID_ERROR;
		continue;

	}
	// 4. It should ask the user to enter in the score for the second Midterm exam.
	cout << MIDTERM_TWO;
	// 5. This value is read in and saved.

	while(true)
	{
		cin.getline(cinput, ASIZE);
		//getline(cin, input);
		state = cin.rdstate();
		if(state != 0) // this will test for the error codes incase someone hit's ^Z or another ctrl code.
		{
			cin.clear();
			if(cin.rdbuf() -> in_avail() > 0)
 				getline(cin, input);
 			cout << SECOND_MID_ERROR;
			continue;
		}
		if(cinput == "")
		{
 			cout << SECOND_MID_ERROR;
			continue;
		}
		if(cinput == NONE)
			examTwo = 0;
			break;
		if(temp = atoi(cinput))
		{
				if(temp < 0)
			{
				cout << SECOND_MID_ERROR;
				continue;
			}
			examTwo = temp;
			break;
		}
		cout << SECOND_MID_ERROR;
		continue;

	}

	// 6. It should ask the user to enter in the score for the Final exam.
	cout << FINAL;
	// 7. This value is read in and saved.
	while(true)
	{
		cin.getline(cinput, ASIZE);
		//getline(cin, input);
		state = cin.rdstate();
		if(state != 0) // this will test for the error codes incase someone hit's ^Z or another ctrl code.
		{
			cin.clear();
			if(cin.rdbuf() -> in_avail() > 0)
 				getline(cin, input);
 			cout << FINAL_EXAM_ERROR;
			continue;
		}
		if(cinput == "")
		{
 			cout << FINAL_EXAM_ERROR;
			continue;
		}
		if(cinput == NONE)
			final = 0;
			break;
		if(temp = atoi(cinput))
		{
				if(temp < 0)
			{
				cout << FINAL_EXAM_ERROR;
				continue;
			}
			final = temp;
			break;
		}
		cout << FINAL_EXAM_ERROR;
		continue;

	}
	score = examOne + examTwo + final;
	return score;
}

int Homework()
{
	vector<int> scores;
	int state = 0;
	int score = 0;
	int temp = 0;
	int examOne = 0;
	int examTwo = 0;
	int final = 0;
	string input = "";
	char cinput[ASIZE+1];
	bool done = false;
	int median = 0;

	while(done == false)
	{

	// 8. The program then asks the user to enter in the scores for the homework assignments, these are also integer values. Any number of scores can be entered in. When done, the user signals completion by pressing Ctrl-z (the Ctrl key and the letter z) followed by the Enter key. This generates an end of file (input) signal.
	cout << HOMEWORK;
		while(true)
		{
			cin.getline(cinput, ASIZE);
			//getline(cin, input);
			state = cin.rdstate();
			if(state != 0) // this will test for the error codes incase someone hit's ^Z or another ctrl code.
			{
				cin.clear();
				if(cin.rdbuf() -> in_avail() > 0)
 					getline(cin, input);
				done = true;
 				break;
			}
			if(cinput == "")
			{
 				cout << HOMEWORK_ERROR;
				continue;
			}
			if(cinput == NONE)
			{
			scores.push_back(0);
			break;
			}
			if(temp = atoi(cinput))
			{
				if(temp < 0)
				{
					cout << HOMEWORK_ERROR;
					continue;
				}
				scores.push_back(temp);
				break;
			}
			cout << HOMEWORK_ERROR;
			continue;
		}
	}
	// 10. Once all of the data has been entered, the program calls a function that you have written to find the median homework score.
	median = Median(scores);
	return median;
}

int Median(vector<int> & iv)
{
	int size = 0;
	double median = 0.0;
	sort(iv.begin(), iv.end());
	size = iv.size();
	if(0 == size % HALF)
		median = ((iv[(size / HALF)] + iv[((size / HALF) + 1)]) / HALF);
	else 
		median = iv[((size / HALF) + 1)];
	return (int)median;

}

string Grade(int score)
{
	string grade = "z";
	if(score <= FAIL)
	{
		grade = LETTERS[0];
		return grade;
	}
	if(score >= MAX)
		grade = LETTERS[LETTER_OPTIONS];
	else
		grade = LETTERS[((score - FAIL) / CHECK)];
	return grade;
}