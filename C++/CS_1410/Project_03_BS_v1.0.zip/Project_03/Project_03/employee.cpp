#include "employee.h"

const string EMP_ONE_NAME = "Harry Potter";
const string EMP_TWO_NAME = "Hermione Granger";
const string EMP_ONE_ADDRESS = "Platform 9 3/4";
const string EMP_TWO_ADDRESS = "Hogwarts";
const string EMP_ONE_PHONE = "(679) 714-3228";
const string EMP_TWO_PHONE = "(193) 852-7329";
const string TITLE = "---------------------------- I'm a hufflepuff! ----------------------------\n\n\n";
const string BANK = "---------------------------- Bank of Griffindor ---------------------------\n\n";
const string PAY = "Pay to the order of";
const string DOTS = "........................";
const string HOURS = "Hours Worked: ";
const string WAGE = "Hourly Wage: ";

const int EMP_ONE_NUMBER = 334;
const int EMP_TWO_NUMBER = 725;

const double EMP_ONE_HOURS = 45.0;
const double EMP_TWO_HOURS = 30.0;
const double EMP_ONE_WAGE = 10.0;
const double EMP_TWO_WAGE = 12.50;
const double FEDERAL_TAX = 0.20;
const double STATE_TAX = 0.075;
const double MAX = 40.0;


void main(void)
{
	Wages();
	system("PAUSE");
}

void Wages()
{
	{
	// 3. Store both of these objects in a Vector object.
	vector<Employee*> eVector;

	// 1. Create an Employee object for an employee whose hourly wage is $10.00, and who has worked 45 hours. Use your imagination to come up with your employee's name and other employee information.
	eVector.push_back(new Employee(EMP_ONE_NUMBER, EMP_ONE_NAME, EMP_ONE_ADDRESS, EMP_ONE_PHONE, EMP_ONE_WAGE, EMP_ONE_HOURS));
	
	// 2. Create a second employee object for an employee whose hourly wage is $12.50 and who has worked 30 hours.
	eVector.push_back(new Employee(EMP_TWO_NUMBER, EMP_TWO_NAME, EMP_TWO_ADDRESS, EMP_TWO_PHONE, EMP_TWO_WAGE, EMP_TWO_HOURS));

	// 4. Call your PrintCheck( ) function, passing the first Employee object as the argument
	PrintCheck(eVector[0]);

	// 5. Skip a few lines of output and do a system("PAUSE") to wait for the user to hit Enter to continue.
	system("PAUSE");

	// 6. Clear the Console by doing a system("CLS") and call PrintCheck again, passing the second Employee object as the argument.
	system("CLS");

	// 4. Call your PrintCheck( ) function, passing the first Employee object as the argument.
	PrintCheck(eVector[1]);
	system("PAUSE");
	}
}

void PrintCheck(Employee *e)
{
	cout << TITLE;
	cout << PAY << e-> GetName() << DOTS << e->CalcPay() << endl << endl << endl;
	cout << BANK;
	cout << HOURS << e-> GetHours() << endl;
	cout << WAGE << e-> GetWage() << endl << endl << endl << endl;
	return;
}

double Employee::CalcPay()
{
	double finalPay = 0.0;
	double hrs = 0.0;
	double wge = 0.0;
	double gross = 0.0;

	hrs = GetHours();
	wge = GetWage();

	if(hrs <= MAX)
	{
		gross = hrs * wge;
		return (gross - ((gross * FEDERAL_TAX) + (gross * STATE_TAX)));
	}
	else
	{
		gross = (MAX * wge) + ((hrs - MAX) * wge);
		return (gross - ((gross * FEDERAL_TAX) + (gross * STATE_TAX)));
	}
}




Employee::Employee(int num, string nm, string ad, string ph, double wg, double hr)
{
	_employeeNumber = num;
	_name = nm;
	_streetAddress = ad;
	_phoneNumber = ph;
	_hourlyWage = wg;
	_hoursWorked = hr;
}

Employee::~Employee(void)
{

}

void Employee::SetNumber(int num)
{
	_employeeNumber = num;
	return;
}

int Employee::GetNumber(void)
{
	return _employeeNumber;
}

void Employee::SetName(string nm)
{
	_name = nm;
	return;
}

string Employee::GetName(void)
{
	return _name;
}

void Employee::SetAddress(string ad)
{
	_streetAddress = ad;
	return;
}

string Employee::GetAddress(void)
{
	return _streetAddress;
}

void Employee::SetPhone(string ph)
{
	_phoneNumber = ph;
	return;
}

string Employee::GetPhone(void)
{
	return _phoneNumber;
}

void Employee::SetWage(double wg)
{
	_hourlyWage = wg;
	return;
}

double Employee::GetWage(void)
{
	return _hourlyWage;
}

void Employee::SetHours(double hr)
{
	_hoursWorked = hr;
	return;
}

double Employee::GetHours(void)
{
	return _hoursWorked;
}

