///Course: CS 1410 Section 002
///Author: Bryan Sandoval
///Date: 10/3/2013
///Project: Project_04
///-----------------------------------------------------------
///I declare that the following source code was written
///solely by me, or provided by the instructor.�
///I understand that copying any source
///code, in whole or in part, constitutes cheating, and
///that I will receive a zero in this assignment if I am
///found in violation of this policy.
///------------------------------------------------------------

#include <iostream>
#include <string>
#include <iomanip>
#include <cctype>
#include <vector>
#include <algorithm>
#include <fstream>

using namespace std;

class Employee
{
	private:
		int _employeeNumber;
		string _name;
		string _streetAddress;
		string _phoneNumber;
		double _hourlyWage;
		double _hoursWorked;

	protected:

	public:
		// default constructor
		Employee();

		// -------------------------------------------------------------------
		// purpose: Initialize the employee class.
		// parameters: _employeeNumber, _name, _streetAddress, _phoneNumber, _hourlyWage, _hoursWorked
		// -------------------------------------------------------------------
		Employee(int, string, string, string, double, double);

		//destructor
		~Employee(void);

		// Sets _employeeNumber
		void SetNumber(int);
		// sets _name
		void SetName(string);
		// sets _streetAddress
		void SetAddress(string);
		// sets _phoneNumber
		void SetPhone(string);
		// sets _hourlyWage
		void SetWage(double);
		// sets _hoursWorked
		void SetHours(double);

		// gets _employee Number
		int GetNumber(void);
		// gets _name
		string GetName(void);
		//gets _streetAddress
		string GetAddress(void);
		// gets _phoneNumber
		string GetPhone(void);
		// gets _hourlyWage
		double GetWage(void);
		// gets _hoursWorked
		double GetHours(void);

		// -------------------------------------------------------------------
		// name: CalcPay
		// purpose: Retrieve _hourlyWage and _hoursWorked, multiply the two, subtract taxes, and return total wages.
		// parameters: None
		// return values: Double value containing the wages
		// -------------------------------------------------------------------
		double CalcPay(void);

		// -------------------------------------------------------------------
		// name: ReadData
		// purpose: Read data from a file
		// parameters: an ifstream& object
		// return values: None
		// -------------------------------------------------------------------
		void ReadData(ifstream&);

		// -------------------------------------------------------------------
		// name: WriteData
		// purpose: Write employee information to a file
		// parameters: An ofstream& object
		// return values: None
		// -------------------------------------------------------------------
		void WriteData(ofstream&);
};
// -------------------------------------------------------------------
// name: Emp
// purpose: To run the program
// parameters: None
// return values: None
// -------------------------------------------------------------------
void Emp(void);

// -------------------------------------------------------------------
// name: Menu
// purpose: Run the menu
// parameters: None
// return values: returns 1 if writing, 2 if printing
// -------------------------------------------------------------------
int Menu(void);

// -------------------------------------------------------------------
// name: PrintCheck()
// purpose: Print a check from the object that is passed in.
// parameters: an employee object
// return values: None
// -------------------------------------------------------------------
void PrintCheck(Employee&);