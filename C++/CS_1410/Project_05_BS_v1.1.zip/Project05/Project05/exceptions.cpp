#include "exceptions.h"

const string MENU_OPTIONS = "Please choose one of the following options:\n<1> - Create a data file\n<2> - Read data from a file and print paychecks\nPlease enter <1> to creat a file or <2> to print checks: ";
const string ERROR = "Error, please try again";
const string TITLE = "---------------------------- I'm a hufflepuff! ----------------------------\n\n\n";
const string BANK = "---------------------------- Bank of Griffindor ---------------------------\n\n";
const string PAY = "Pay to the order of";
const string DOTS = "........................";
const string HOURS = "Hours Worked: ";
const string WAGE = "Hourly Wage: ";
const string FILENAME = "Employee_information.txt";
const string EMP_ONE_NAME = "Joe Brown";
const string EMP_TWO_NAME = "Sam Jones";
const string EMP_THREE_NAME = "Mary Smith";
const string EMP_ONE_ADDRESS = "123 Main St.";
const string EMP_TWO_ADDRESS = "45 East State";
const string EMP_THREE_ADDRESS = "12 High Street";
const string EMP_ONE_PHONE = "123-6788";
const string EMP_TWO_PHONE = "661-9000";
const string EMP_THREE_PHONE = "401-8900";
const string RQST_NAME = "Please enter a file name for the employee information: ";
const string STATE_STORE = "Employee information has been stored in ";
const string UNKNOWN_ERROR = "An unknown error has occured\n";
const string OPEN_FAIL = "Failed to open the file\n";
const string BAD_NAME = "would you like to try another file name?\nPlease enter [Y] or [N]: ";
const string READ_FAILED = "Failure while trying to read the file\nPlease check the file contents and try again.\n";

const char YES = 'Y';
const char NO = 'N';

const int ASIZE = 80;
const int EMP_ONE_NUMBER = 37;
const int EMP_TWO_NUMBER = 21;
const int EMP_THREE_NUMBER = 15;
const int FIRST_OPT = 1;
const int SECOND_OPT = 2;

const double EMP_ONE_HOURS = 45.0;
const double EMP_TWO_HOURS = 30.0;
const double EMP_THREE_HOURS = 40.0;
const double EMP_ONE_WAGE = 10.00;
const double EMP_TWO_WAGE = 12.00;
const double EMP_THREE_WAGE = 15.00;
const double FEDERAL_TAX = 0.20;
const double STATE_TAX = 0.075;
const double MAX = 40.0;

void main()
{
	Emp();
	system("PAUSE");
}

void Emp()
{
	do
	{
		string fileName = "";
		int input = 0;
		if(Menu() == 1)
		{
		//3. Create the following three employee objects as shown:
			{
				ofstream storeEmp;

				Employee joe(EMP_ONE_NUMBER, EMP_ONE_NAME, EMP_ONE_ADDRESS, EMP_ONE_PHONE, EMP_ONE_HOURS, EMP_ONE_WAGE);

				Employee sam(EMP_TWO_NUMBER, EMP_TWO_NAME, EMP_TWO_ADDRESS, EMP_TWO_PHONE, EMP_TWO_HOURS, EMP_TWO_WAGE);

				Employee mary(EMP_THREE_NUMBER, EMP_THREE_NAME, EMP_THREE_ADDRESS, EMP_THREE_PHONE, EMP_THREE_HOURS, EMP_THREE_WAGE);
		// Ask user for a file name:
				try
				{
				fileName = Location();
		//a. Create an ofstream object and open a file. Choose any name for the file that you want. Pass just the file name as the parameter (no path) so that your program assumes the file to be in the same folder as your executable file.
				storeEmp.open(fileName);
				if(storeEmp.fail())
					throw(ApplicationError(OPEN_FAIL));
		//4. Send messages to each of the three Employee objects to write themselves out to the file.
				joe.WriteData(storeEmp);
				sam.WriteData(storeEmp);
				mary.WriteData(storeEmp);
		//5. Close the file.
				storeEmp.close();
				}
				catch(ApplicationError& e)
				{
					storeEmp.close();
					cout << e.What();
					if(Repeat() == true)
						continue;
					else
						break;
				}
				catch(...)
				{
					storeEmp.close();
					cout << UNKNOWN_ERROR;
				}
			}
		//6. Print an message that the file creation is complete.
			cout << STATE_STORE << fileName << endl;
		//7. Exit.
		}
		else
		{
		//8. If the user selects the second option, your program should
		//9. Create three new Employee objects, using the default Employee constructor.

			{
				Employee joe;
				Employee sam;
				Employee mary;
		//10. Open the file that you just saved.
				ifstream retrieveEmp;
				try
				{
					fileName = Location();
					retrieveEmp.open(fileName);
					if(retrieveEmp.fail())
						throw(ApplicationError(OPEN_FAIL));
				}
				catch(ApplicationError& e)
				{
					retrieveEmp.close();
					cout << e.What();
					if(Repeat() == true)
						continue;
					else
						break;
				}
				catch(...)
				{
					retrieveEmp.close();
					cout << UNKNOWN_ERROR;
				}
		//11. Have each object read itself in from the file.
				try
				{
				joe.ReadData(retrieveEmp);
				sam.ReadData(retrieveEmp);
				mary.ReadData(retrieveEmp);
				}
				catch(ApplicationError& e)
				{
					retrieveEmp.close();
					cout << e.What();
					break;
				}
				catch(...)
				{
					retrieveEmp.close();
					cout << UNKNOWN_ERROR;
					break;
				}

		//12. Call the PrintCheck( ) function for each of the three new objects, just as you did in the previous project.
				PrintCheck(joe);
				system("PAUSE");
				system("CLS");

				PrintCheck(sam);
				system("PAUSE");
				system("CLS");

				PrintCheck(mary);
				system("PAUSE");
				system("CLS");

				retrieveEmp.close();
			}

		}
		//13. Exit.
	}while(true);
}

bool Repeat()
{

		int userInpt = 0;
	string input = "";
	char cinput[ASIZE+1];
	int state = 0;
	int temp = 0;

	do
	{
		cout << BAD_NAME;
				cin.getline(cinput, ASIZE);
		//getline(cin, input);
		state = cin.rdstate();
		if(state != 0) // this will test for the error codes incase someone hit's ^Z or another ctrl code.
		{
			cin.clear();
			if(cin.rdbuf() -> in_avail() > 0)
 				getline(cin, input);
			cout << ERROR;
			system("PAUSE");
			system("CLS");
			continue;
		}
		if(cinput == "")
		{
			cout << ERROR;
			system("PAUSE");
			system("CLS");
			continue;
		}
		if(toupper(cinput[0]) == YES)
		{
			system("CLS");
			return true;
		}
		else if(toupper(cinput[0]) == NO)
			return false;
		else
		{
			cout << ERROR;
			continue;
		}
	}while(true);
}

int Menu()
{
//1. Presents the user with a menu of three choices: 1. Create a data file, 2. Read data from a file and print checks and 3) Exit program.
	int userInpt = 0;
	string input = "";
	char cinput[ASIZE+1];
	int state = 0;
	int temp = 0;

	do
	{
		cout << MENU_OPTIONS;
				cin.getline(cinput, ASIZE);
		//getline(cin, input);
		state = cin.rdstate();
		if(state != 0) // this will test for the error codes incase someone hit's ^Z or another ctrl code.
		{
			cin.clear();
			if(cin.rdbuf() -> in_avail() > 0)
 				getline(cin, input);
			cout << ERROR;
			system("PAUSE");
			system("CLS");
			continue;
		}
		if(cinput == "")
		{
			cout << ERROR;
			system("PAUSE");
			system("CLS");
			continue;
		}
		if(atoi(cinput) == FIRST_OPT)
			return FIRST_OPT;

		else if(atoi(cinput) == SECOND_OPT)
			return SECOND_OPT;
		else
		{
			cout << ERROR;
			system("PAUSE");
			system("CLS");
			continue;
		}
	}while(true);

}

void PrintCheck(Employee& e)
{
	cout << TITLE;
	cout << PAY << e.GetName() << DOTS << e.CalcPay() << endl << endl << endl;
	cout << BANK;
	cout << HOURS << e.GetHours() << endl;
	cout << WAGE << e.GetWage() << endl << endl << endl << endl;
	return;
}

string Location()
{
	int userInpt = 0;
	string input = "";
	char cinput[ASIZE+1];
	int state = 0;
	int temp = 0;

	do
	{
		cout << RQST_NAME;
				cin.getline(cinput, ASIZE);
		//getline(cin, input);
		state = cin.rdstate();
		if(state != 0) // this will test for the error codes incase someone hit's ^Z or another ctrl code.
		{
			cin.clear();
			if(cin.rdbuf() -> in_avail() > 0)
 				getline(cin, input);
			cout << ERROR;
			system("PAUSE");
			system("CLS");
			continue;
		}
		if(cinput == "")
		{
			cout << ERROR;
			system("PAUSE");
			system("CLS");
			continue;
		}
		else
			return cinput;
	}while(true);
}



Employee::Employee()
{
	_phoneNumber = "0";
	_employeeNumber = 0;
	_name = "0";
	_streetAddress = "0";
	_hourlyWage = 0.0;
	_hoursWorked = 0.0;
}
Employee::Employee(int num, string name, string address, string phone, double wage, double hours)
{
	_phoneNumber = phone;
	_employeeNumber = num;
	_name = name;
	_streetAddress = address;
	_hourlyWage = wage;
	_hoursWorked = hours;
}
Employee::~Employee(void)
{

}
void Employee::SetNumber(int num)
{
	_employeeNumber = num;
}
int Employee::GetNumber(void)
{
	return _employeeNumber;
}
void Employee::SetName(string name)
{
	_name = name;
}
string Employee::GetName(void)
{
	return _name;
}
void Employee::SetAddress(string address)
{
	_streetAddress = address;
}
string Employee::GetAddress(void)
{
	return _streetAddress;
}
void Employee::SetPhone(string phone)
{
	_phoneNumber = phone;
}
string Employee::GetPhone(void)
{
	return _phoneNumber;
}
void Employee::SetWage(double wage)
{
	_hourlyWage = wage;
}
double Employee::GetWage(void)
{
	return _hourlyWage;
}
void Employee::SetHours(double hours)
{
	_hoursWorked = hours;
}
double Employee::GetHours(void)
{
	return _hoursWorked;
}
double Employee::CalcPay()
{
	double finalPay = 0.0;
	double hrs = 0.0;
	double wge = 0.0;
	double gross = 0.0;

	hrs = GetHours();
	wge = GetWage();

	if(hrs <= MAX)
	{
		gross = hrs * wge;
		return (gross - ((gross * FEDERAL_TAX) + (gross * STATE_TAX)));
	}
	else
	{
		gross = (MAX * wge) + ((hrs - MAX) * wge);
		return (gross - ((gross * FEDERAL_TAX) + (gross * STATE_TAX)));
	}
}

void Employee::ReadData(ifstream& read)
{
	char cArray[ASIZE];

	read.getline(cArray,ASIZE);
	_employeeNumber = atoi(cArray);
	if(read.fail())
		throw(ApplicationError(READ_FAILED));

	read.getline(cArray,ASIZE);
	_name = cArray;
	if(read.fail())
		throw(ApplicationError(READ_FAILED));

	read.getline(cArray,ASIZE);
	_streetAddress = cArray;
	if(read.fail())
		throw(ApplicationError(READ_FAILED));

	read.getline(cArray,ASIZE);
	_phoneNumber = cArray;
	if(read.fail())
		throw(ApplicationError(READ_FAILED));

	read.getline(cArray,ASIZE);
	_hourlyWage = atof(cArray);
	if(read.fail())
		throw(ApplicationError(READ_FAILED));
	
	read.getline(cArray,ASIZE);
	_hoursWorked = atof(cArray);
	if(read.fail())
		throw(ApplicationError(READ_FAILED));
}
void Employee::WriteData(ofstream& write)
{
	write << _phoneNumber << endl;
	write << _name << endl;
	write << _streetAddress << endl;
	write << _phoneNumber << endl;
	write << _hourlyWage << endl;
	write << _hoursWorked << endl;
}


ApplicationError::ApplicationError(string e)
{
	_error = e;
}
ApplicationError::~ApplicationError()
{

}
string ApplicationError::What()
{
	return _error;
}