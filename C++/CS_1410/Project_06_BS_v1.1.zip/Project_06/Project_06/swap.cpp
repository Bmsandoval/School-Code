#include "swap.h"

const int ASIZE = 30;
const char EXIT_INPUT = '0';
const string INTRO = "\tEverything's shiny, nothing to worry about\n\tjust input a string to be reversed!\n";
const string RQST_STRING = "Please enter a sentence: ";
const string CTRL_KEY = "\tError: A Ctrl key was pressed...\n";
const string NO_INPUT = "\tError: Nothing was typed into the console...\n";
const int CSIZE = 500;

void main()
{
	Swap();
	system("PAUSE");
}

void Swap()
{
	string input = "";

	char cinput[ASIZE+1];
	char uInput[CSIZE];

	int state = 0;
	int i = 0;
	int tmp = 0;

	double temp = 0.0;

	char* pArray[ASIZE];
	char* ePtr = &uInput[0];
	char* tPtr = 0;

	cout << INTRO;
	do // BEGIN DO-WHILE LOOP
	{ 

		// Request input from the user
		cout << RQST_STRING;
		cin.getline(cinput, ASIZE);
		state = cin.rdstate();
		// Test input for error codes
		if(state != 0) 
		{
			cin.clear();
			if(cin.rdbuf() -> in_avail() > 0)
				getline(cin, input);
			cout << CTRL_KEY;
			system("PAUSE");
			system("CLS");
			continue;
		}
		// Test for empty string
		if(cinput[0] == NULL)
		{
			cout << NO_INPUT;
			system("PAUSE");
			system("CLS");
			continue;
		}
		// If user inputs '0', break out of loop
		if(cinput[0] == EXIT_INPUT)
			break;
		tPtr = &cinput[0];
		// store location of the end pointer in a pointer array
		pArray[i++] = ePtr;
		// Concantenate input to cstring
		while(*tPtr != NULL)
		{
			*ePtr++ = *tPtr++;
		}
		*ePtr++ = NULL;

	}while(true); // END DO-WHILE LOOP

	// BEGIN WHILE LOOP
	while(i-- != 0)
	{
	// start from the end of the array and work back
		tPtr = pArray[i];
		while(*tPtr != NULL)
		{
			cout << *tPtr++;
		}
		cout << endl;
	}
}