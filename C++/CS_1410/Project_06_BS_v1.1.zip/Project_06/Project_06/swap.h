///Course: CS 1410 Section 002
///Author: Bryan Sandoval
///Date: 11/7/2013
///Project: Project_06
///-----------------------------------------------------------
///I declare that the following source code was written
///solely by me, or provided by the instructor.�
///I understand that copying any source
///code, in whole or in part, constitutes cheating, and
///that I will receive a zero in this assignment if I am
///found in violation of this policy.
///------------------------------------------------------------

#include <iostream>
#include <string>

using namespace std;


// ----------------------------------------------------------------------------
// Purpose: To convert an int parameter > 0 to a double, pass a double > 500.0
// Parameters: int parameter >0, and double > 500.0
// Returns: double which is the sum of the two parameters
// ----------------------------------------------------------------------------
void Swap();