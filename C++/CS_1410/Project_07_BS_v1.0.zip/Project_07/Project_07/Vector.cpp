#include "Vector.h";

const int VAL1 = 21;
const int VAL2 = 31;
const int VAL3 = 41;
const int MAX = 12;
const int DEFAULT_VAL = 2;

int main( )
{
	// Create a default vector (cap = 2)
	MyVector sam;
	
	// push some data into sam
	cout << "\nPushing three values into sam";
	sam.Push_Back(VAL1);
	sam.Push_Back(VAL2);
	sam.Push_Back(VAL3);

	cout << "\nThe values in sam are: ";

	// test for out of bounds condition here
	for (int i = 0; i < sam.GetSize( ) + 1; i++)
	{
		try
		{
		    cout << sam.ValueAt(i) << " ";
		}
		catch(int badIndex)
		{
			cout << "\nOut of bounds at index " << badIndex << endl;
		}
	}
	cout << "\n--------------\n";

	// clear sam and display its size and capacity
	sam.Clear( );
	cout << "\nsam has been cleared.";
	cout << "\nSam's size is now " << sam.GetSize( );
	cout << "\nSam's capacity is now " << sam.GetCapacity( ) << endl;	
	cout << "---------------\n";

	// Push 12 values into the vector - it should grow
	cout << "\nPush 12 values into sam.";
	for (int i = 0; i < MAX; i++)
	       sam.Push_Back(i);

	cout << "\nSam's size is now " << sam.GetSize( );
	cout << "\nSam's capcacity is now " << sam.GetCapacity( ) << endl;
	cout << "---------------\n";

	cout << "\nTest to see if contents are correct...";
	// display the values in the vector
	for (int i = 0; i < sam.GetSize( ); i++)
	{
	     cout << sam.ValueAt(i) << " ";
	}
	cout << "\n--------------\n";

	cout << "\n\nTest Complete...";

	cout << endl;
	system("PAUSE");
	return 0;
}



MyVector::MyVector()
{
	_capacity = DEFAULT_VAL;
	_size = 0;
	_iArray = new int[DEFAULT_VAL];
}
MyVector::MyVector(int cap)
{
	_capacity = cap;
	_size = 0;
	_iArray = new int[cap];
}
MyVector::~MyVector()
{
	delete [] _iArray;
}
int MyVector::GetCapacity()
{
	return _capacity;
}
int MyVector::GetSize()
{
	return _size;
}
void MyVector::SetCapacity(int cap)
{
	int* tempArray = _iArray;
	_iArray = new int[cap];
	for(int i = 0; i < _size; i++)
	{
		_iArray[i] = tempArray[i];
	}
	delete [] tempArray;
	_capacity = cap;
}
void MyVector::Clear()
{
	_size = 0;
	_capacity = DEFAULT_VAL;
	int* tempArray = _iArray;
	_iArray = new int[_capacity];
	delete [] tempArray;
}
void MyVector::Push_Back(int val)
{
	if(_size == _capacity)
	{
		if(_capacity == 0)
			SetCapacity(DEFAULT_VAL);
		else
			SetCapacity(DEFAULT_VAL * _capacity);
	}
	_iArray[_size] = val;
	_size++;
}
int MyVector::ValueAt(int loc)
{
	if(loc >= _size)
		throw loc;
	return _iArray[loc];
}