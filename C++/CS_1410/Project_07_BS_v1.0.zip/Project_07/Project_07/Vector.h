///Course: CS 1410 Section 002
///Author: Bryan Sandoval
///Date: 11/8/2013
///Project: Lab07
///-----------------------------------------------------------
///I declare that the following source code was written
///solely by me, or provided by the instructor.�
///I understand that copying any source
///code, in whole or in part, constitutes cheating, and
///that I will receive a zero in this assignment if I am
///found in violation of this policy.
///------------------------------------------------------------

#include <iostream>
#include <string>

using namespace std;


// ----------------------------------------------------------------------------
// Purpose: To hold and manipulate employee data members
// ----------------------------------------------------------------------------
class MyVector
{
	private:
		int _capacity;
		int _size;
		int* _iArray;
	protected:

	public:
// ----------------------------------------------------------------------------
// Purpose: construct an array on the heap with default capacity (2)
// Parameters: none
// Returns: none
// ----------------------------------------------------------------------------
		MyVector();

// ----------------------------------------------------------------------------
// Purpose: construct an array on the heap with default capacity (n)
// Parameters: desired array capacity (n)
// Returns: none
// ----------------------------------------------------------------------------
		MyVector(int); 

// ----------------------------------------------------------------------------
// Purpose: destruct the array
// Parameters: none
// Returns: none
// ----------------------------------------------------------------------------
		~MyVector();

// ----------------------------------------------------------------------------
// Purpose: returns the current array capacity
// Parameters: none
// Returns: current array capacity
// ----------------------------------------------------------------------------
		int GetCapacity();

// ----------------------------------------------------------------------------
// Purpose: returns the current size of the array
// Parameters: none
// Returns: current size of the array
// ----------------------------------------------------------------------------
		int GetSize();

// ----------------------------------------------------------------------------
// Purpose: Make a new array with a set capacity
// Parameters: desired size of new array
// Returns: none
// ----------------------------------------------------------------------------
		void SetCapacity(int);

// ----------------------------------------------------------------------------
// Purpose: delete the array and recreate it with size 0, capacity 2
// Parameters: none
// Returns: none
// ----------------------------------------------------------------------------
		void Clear();

// ----------------------------------------------------------------------------
// Purpose: add a new int value to the end of the array, extend the array if too small
// Parameters: value to add to the end of the array
// Returns: none
// ----------------------------------------------------------------------------
		void Push_Back(int);

// ----------------------------------------------------------------------------
// Purpose: return value at a specified location
// Parameters: desired location to return.
// Returns: value at location
// ----------------------------------------------------------------------------
		int ValueAt(int);
};