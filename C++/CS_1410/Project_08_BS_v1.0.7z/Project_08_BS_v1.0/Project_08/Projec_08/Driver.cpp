#include"Employee.h"

const int EXIT = 3;
const int READ = 2;
const int WRITE = 1;
void main()
{
	Menu();
	system("PAUSE");
}

void Menu()
{
	string fileName="employee.txt";
	ifstream dataIn;
	ofstream dataOut;
	string input="";



	
	do
	{
		cout<<"\n\n\nPlease choose from the following options\n"<<endl;
		cout<<"(1)...Create a Data file\n"<<"(2)...Read Data from a file and print a Paycheck\n"<<"(3)...Exit\n"<<endl;
		do
		{
			cout<<"Please enter choice: ";
			getline(cin,input);
			int intValue= atoi(input.c_str());
			if( intValue != WRITE && intValue != READ && intValue != EXIT)
			{
				cout<<"\nThat is an incorrect entry, Please try again"<<endl;
				cin.clear();
			
			}
	
			else if(intValue == WRITE)
			{
				cout<<"\nEnter a filename (in the same folder as your executable) ie: ("<<fileName<<") : "<<endl;
				getline(cin,input);
				fileName=input;
				dataOut.open(input);
				vector<Employee*> employee(4);
				employee[0] = new Hourly("Harry Potter", "Privet Drive", "201-9090", 1, 40, 12.00);
				employee[1] = new Hourly("Ronald Weasly", "The Borough", "892-2000", 3, 40, 10.00);
				employee[2] = new Salary("Albus Dumbledore", "Hogwarts", "803-1230", 2, 1200);
				employee[3] = new Salary("Rotten Hagrid", "Hogwarts", "910-8765", 4, 1000);
				for (int i = 0; i < employee.size(); i++)
				{
					employee[i]->WriteData(dataOut);
					delete employee[i];
					employee[i] = NULL;
				}
				dataOut.close();
				system("PAUSE");
				break;
			}

			else if(intValue==READ)
			{



					try
					{
						system("CLS");
						cout<<"\nEnter a file name (in the same folder as your executable) ie: ("<<fileName<<") : "<<endl;
						getline(cin,input);
						ifstream dataIn(input);
						if(dataIn.rdstate()!=0)
						{
							throw exception("\nFailed to open File.  Please try again\n\n");
							break;
						}
						if(dataIn.fail())
						{
							throw exception("\nFailed to open File.  Please try again\n\n");
							break;
						}
						if(dataIn.bad())
						{
							throw exception("\nBad File. Please try again\n\n");
							break;
						}
						if(dataIn.eof())
						{
							throw exception("\nEnd of File error encountered. Please try again\n\n");
							break;
						}
						if(dataIn.good())
						{
							vector<Employee*> employee(4);
							employee[0] = new Hourly();
							employee[1] = new Hourly();
							employee[2] = new Salary();
							employee[3] = new Salary();
							for (int i = 0; i < employee.size(); i++)
							{
								employee[i]->ReadData(dataIn);
								delete employee[i];
								employee[i] = NULL;
							}
							dataIn.open(input);
							break;
						}
						
					}
					catch(exception exp)
					{
						cout<< exp.what()<<endl;
						continue;
					}
					catch(...)
					{
						throw exception("\nYour entry was..well..I am at a loss for words. Please try again\n\n");
							cin.clear();
							continue;
					}
					
				break;
			}
			else if(intValue==EXIT)
			{
				cout<<"\n\nGoodbye...\n\n"<<endl;
				return;
			}
		}while(true);
	}while(true);	
	
}