#include"Employee.h"

const double HRS=40;
const double STATETAX=.075;
const double FEDTAX=.20;
const double OVERTIME=1.5;
const int PRECISION=2;


// ************************************************************************
// ******************************* Employee *******************************
// ************************************************************************
Employee::Employee(string n, string a, string phone, int number)
{
	name = n;
	address = a;
	employeePhone = phone;
	employeeNumber = number;
}
Employee::Employee()
{

}
Employee::~Employee()
{

}
int Employee::GNumber()
{
	return employeeNumber;

}
string Employee::GPhone()
{
	return employeePhone;

}
string Employee::GName()
{
	return name;

}
string  Employee::GAddress()
{
	return address;

}

double Employee::CalcPay()
{
	return 0.;
}
void Employee::WriteData(ofstream& outFile)
{
	outFile << name << endl << address << endl << employeePhone<< endl << employeeNumber << endl;
	outFile.close();
}
void Employee::ReadData(ifstream& inFile)
{
	inFile >>  name >> address >> employeePhone >>employeeNumber;
}



// ************************************************************************
// ******************************** Hourly ********************************
// ************************************************************************
Hourly::Hourly(string name, string address, string phone, int number, double hWork,double hWage) : Employee(name, address, phone, number)
{
	//employeePhone = phone;
	//employeeNumber = number;
	hrsWorked=hWork;
	hrlyWage=hWage;
}
Hourly::Hourly() : Employee()
{

}
Hourly::~Hourly()
{

}
double Hourly::GHourlyWage()
{
	return hrlyWage; 
}
double Hourly::GHoursWorked()
{
	return hrsWorked;
}
double Hourly::CalcPay()
{
	double netPay=0;
	if(hrsWorked>HRS)
	{
		double overtimeHrs=(hrsWorked-HRS) * OVERTIME;
		double totHours=overtimeHrs+HRS;
		double grossPay=totHours*hrlyWage;
		double stateTax= grossPay*STATETAX;
		double fedTax=grossPay*FEDTAX;
		netPay=grossPay-stateTax-fedTax;
		return netPay;
		

	}
	else 
	{
		double totHours=hrsWorked;
		double grossPay=totHours*hrlyWage;
		double stateTax= grossPay*STATETAX;
		double fedTax=grossPay*FEDTAX;
		netPay=grossPay-stateTax-fedTax;
		return netPay;
	}


}
void Hourly::WriteData(ofstream& outFile)
{
	outFile << name << endl << address << endl << employeePhone<< endl << employeeNumber << endl << hrsWorked<< endl << hrlyWage << endl;
}
void Hourly::ReadData(ifstream& inFile)
{
	char temp[81];
	getline(inFile,name);
	getline(inFile,address);
	getline(inFile,employeePhone);
	inFile.getline(temp,81);
	employeeNumber = atoi(temp);
	inFile.getline(temp,81);
	hrsWorked = atoi(temp);
	inFile.getline(temp,81);
	hrlyWage = atof(temp);
	PrintCheck();
}
void Hourly::PrintCheck()
{
	cout<<"\n*******************************************************************************"<<endl;
	cout<<"\n\n\n  ____________________________S & P Productions____________________________\n\n\n"<<endl;
	cout<<"  Pay to the order of "<< name <<"......................$"<<fixed<<setprecision(PRECISION)<<CalcPay()<<endl;
	cout<<"\n\n  Bank of American Grove"<<endl;
	cout<<"  ___________________________\n"<<endl;
	cout<<"\n  Total hours worked: "<<hrsWorked<<endl;
	cout<<"\n  Hourly Wage: "<<fixed<<setprecision(PRECISION)<<hrlyWage<<endl;
	cout<<"\n*******************************************************************************\n\n\n"<<endl;
	system("PAUSE");
	system("CLS");
}


// ************************************************************************
// ******************************** Salary ********************************
// ************************************************************************
Salary::Salary(string name, string address, string phone, int number, double wS) : Employee(name, address, phone, number)
{
	weeklySalary=wS;
}
Salary::Salary() : Employee()
{

}
Salary::~Salary()
{

}
double Salary::CalcPay()
{
	double netPay=0;
	double grossPay=weeklySalary;
	double stateTax= grossPay*STATETAX;
	double fedTax=grossPay*FEDTAX;
	netPay=grossPay-stateTax-fedTax;
	return netPay;
}
void Salary::WriteData(ofstream& outFile)
{
	outFile << name << endl << address << endl << employeePhone<< endl << employeeNumber << endl << weeklySalary << endl;
}
void Salary::ReadData(ifstream& inFile)
{
	char temp[81];
	getline(inFile,name);
	getline(inFile,address);
	getline(inFile,employeePhone);
	inFile.getline(temp,81);
	employeeNumber = atoi(temp);
	inFile.getline(temp,81);
	weeklySalary = atof(temp);
	PrintCheck();
}
void Salary::PrintCheck()
{
	cout<<"\n*******************************************************************************" << endl;
	cout<<"\n\n\n  ____________________________S & P Productions____________________________\n\n\n"<<endl;
	cout<<"  Pay to the order of " << name << "......................$" << fixed << setprecision(PRECISION) << CalcPay() << endl;
	cout<<"\n\n  Bank of American Grove"<<endl;
	cout<<"  ___________________________\n"<<endl;
	cout<<"\n  Hourly Wage: "<<fixed<<setprecision(PRECISION)<<weeklySalary<<endl;
	cout<<"\n*******************************************************************************\n\n\n"<<endl;
	system("PAUSE");
	system("CLS");

}



// ************************************************************************
// ****************************** Exceptions ******************************
// ************************************************************************
IOExceptions::IOExceptions(void)
{

}
IOExceptions::~IOExceptions(void)
{

}