///Course: CS 1410 Section 002
///Name: Bryan Sandoval
///Instructor: Professor Fairclough
///File: Project 08
///Contents: Project 08 Programming Assignment
///in collaboration with, matt, mike, brian
///-----------------------------------------------------------
///I declare that the following source code was written
///in collaboration by/with the above people, or provided by the instructor. 
///I understand that copying any source
///code, in whole or in part, constitutes cheating, and
///that I will receive a zero in this assignment if I am
///found in violation of this policy.
///------------------------------------------------------------

#include<iostream>
#include<string.h>
#include<vector>
#include<iomanip>
#include<string>
#include<fstream>
using namespace std;

void Menu();


// ----------------------------------------------------------------------------
// Purpose: To hold and manipulate employee data members
// ----------------------------------------------------------------------------
class Employee
{
protected:
	int employeeNumber;
	string employeePhone;
	string name;
	string address;
public:
	Employee(string n, string a, string phone, int number);
	Employee();
	~Employee();
virtual	int GNumber();
virtual	string GPhone();
virtual	string GName();
virtual string GAddress();
virtual double CalcPay();
virtual void  ReadData(ifstream&);
virtual void WriteData(ofstream&);
};

// ----------------------------------------------------------------------------
// Purpose: To hold and manipulate Hourly data members
// ----------------------------------------------------------------------------
class Hourly:public Employee
{
private:
	double hrsWorked;
	double hrlyWage;

public:
	// string Name, string Address, string Phone#, int Emp#, double Hours, double Wage
	Hourly(string, string, string, int, double, double);//parameterized constructor
	Hourly();
	~Hourly();
	double CalcPay();
	// Get hourly wage
	double GHourlyWage();
	// Get hours worked
	double GHoursWorked();
virtual	void ReadData(ifstream&);
virtual	void WriteData(ofstream&);
virtual	void PrintCheck();
};

// ----------------------------------------------------------------------------
// Purpose: To hold and manipulate Salary data members
// ----------------------------------------------------------------------------
class Salary:public Employee
{

private:
	double weeklySalary;

public:
	// string Name, string Address, string Phone#, int Emp#, double Salary
	Salary(string, string, string, int, double);//parameterized constructor
	Salary();
	~Salary();

		double CalcPay();
virtual	void ReadData(ifstream&);
virtual	void WriteData(ofstream&);
virtual	void PrintCheck();
};

// ----------------------------------------------------------------------------
// Purpose: To hold and return an exception
// ----------------------------------------------------------------------------
class IOExceptions
{
private:

public:
	IOExceptions(void);//default constructor
	~IOExceptions(void);//default destructor
};