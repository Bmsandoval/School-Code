#include "proj_09.h"

void main()
{
	{
		Menu();
	}
	system("PAUSE");
}

void Menu()
{
	while(true)
	{
		int answer = GetInput();
		if (answer == CHOICE_1)
			MakeFile();
		else if (answer == CHOICE_2)
			ReadFile();
		else if (answer == 0)
			break;
	}
	return;
}

int GetInput()
{
	char answer[CHAR_SIZE];
	int state = cin.rdstate();
	int tempInt = 0;
	cout << "This program has two options: " << endl;
	cout << "1 - Create a data field, or" << endl << "2 - Read data from a file and print paychecks.";
	while(true)
	{
		cout << "\nPlease enter (1) to create a file, (2) to print checks, or (0) to leave: ";
		fgets (answer, CHAR_SIZE, stdin);
		if(state!=0)
		{
			cout << "Invalid input, please press enter to see the next employee." << state << endl;
			system("PAUSE");
			cin.clear();
		}
		else if (*answer == '2' || *answer == '1')
		{
			tempInt = atoi(answer);
			break;
		}
		else if (*answer == '0')
			tempInt = atoi(answer);
			break;
	}
	return tempInt;
}

void MakeFile()
{
	Employee* payroll[SIZE];
	payroll[0] = new HourlyEmp(1, "Harry Potter", "Privet Drive", "201-9090", 40.0, 12.00);
	payroll[1] = new SalaryEmp(2, "Albert Dumbledore", "Hogwarts", "803-1230", 1200.00);
	payroll[2] = new HourlyEmp(3, "Rogue Weasley", "The Burrow", "892-2000", 40.0, 10.00);
	payroll[3] = new SalaryEmp(4, "Rotten Hagrid", "Hogwarts", "910-8765", 1000.00);
	ofstream employeeFile; //create ofstream and open file
	do
	{
		employeeFile.open (FILENAME.c_str()); //pass file name as parameter, no path
		for(int i=0;i<SIZE;i++)
		{
			payroll[i]->WriteData(employeeFile); //write each of the 4 employees to the file
		}
		employeeFile.close();
		cout << "File write complete." << endl;
		for(int i=0;i<SIZE;i++)
		{
			delete payroll[i];
			payroll[i] = NULL;
		}
		cout << "Memory cleared." << endl;
		break;
	}while(true);
}
void ReadFile()
{
	ifstream employeeFileRead(FILENAME.c_str());
	int filestate = cin.rdstate();
	int count = 0;
	Employee* ePtr;
	Employee* payroll[SIZE];
	string type;
	do{
		try //try to open the file
		{ 
			//employeeFileRead.open(FILENAME.c_str());
			filestate = employeeFileRead.rdstate();
			if(filestate!=0) {throw (new exception("File failed to open!"));}
			while(employeeFileRead >> type)
			{
				if(type == "salary")
				{
					ePtr = new SalaryEmp();
				}
				else if(type == "hourly")
				{
					ePtr = new HourlyEmp();
				}
				else
				{
					cout << "\nData is incorrect, program terminating...";
					system("PAUSE");
					exit(1);
				}
				ePtr->ReadData(employeeFileRead);
				payroll[count++] = ePtr;
			}
			break;
		}
		catch(exception exp)
		{
			cout << exp.what() << endl;
			system("PAUSE");
		}
		catch(...)
		{
			cout << "Unkown error." << endl;
			system("PAUSE");
		}
}while(true);
	system("CLS");
	for(int i=0;i<SIZE;i++)
	{
		PrintCheck(payroll[i]);
		system("CLS");
	}
}

Employee::Employee(){}
string Employee::GetName()
{
	return _name;
}
void Employee::ReadData(ifstream& e)
{
	string inputStr;
	getline(e, inputStr);
	getline(e, inputStr);
	_employeeNumber = atoi(inputStr.c_str());
	getline(e, _name);
	getline(e, _address);
	getline(e, _phoneNumber);	
}
void Employee::WriteData(ofstream& e)
{
	e << _employeeNumber << endl;
	e << _name << endl;
	e << _address << endl;
	e << _phoneNumber << endl;
}
HourlyEmp::HourlyEmp(){}
HourlyEmp::HourlyEmp(int num, string name, string address, string phone, double hours, double wage)
{
	_employeeNumber = num;
	_name = name;
	_address = address;
	_phoneNumber = phone;
	_weeklyHours = hours;
	_hourlyWage = wage;
}
string HourlyEmp::GetName()
{
	return _name;
}
double HourlyEmp::GetHours()
{
	return _weeklyHours;
}
double HourlyEmp::GetWage()
{
	return _hourlyWage;
}
double HourlyEmp::CalcPay()
{
	int remainder = 0;
	double salary = 0;
	int OT = 40;
	double timeandahalf = 1.5;
	double STATE = .075;
	double FED = .20;
	double baseSalary = 0;
	if (_weeklyHours > OT) // overtime
	{
		remainder = _weeklyHours - OT; // gather overtime hours
		_weeklyHours = OT; 
		remainder = remainder * (_hourlyWage * timeandahalf); // calc overtime
		salary = _weeklyHours * _hourlyWage;
		salary = salary + remainder;
		baseSalary = salary;
		salary = salary - (baseSalary * FED); // calc federal deductions
		salary = salary - (baseSalary * STATE); // calc state deductions
		cout.setf(ios::fixed);
		cout.setf(ios::showpoint);
		cout.precision(PRECISION);
		return salary;
	}
	else
	{
		salary = _weeklyHours * _hourlyWage; // calc salary
		baseSalary = _weeklyHours * _hourlyWage;
		salary = salary - (baseSalary * STATE); // calc state deductions
		salary = salary - (baseSalary * FED); // calc federal deductions
		cout.setf(ios::fixed);
		cout.setf(ios::showpoint);
		cout.precision(PRECISION);
		return salary;
	}
}
void HourlyEmp::ReadData(ifstream& e)
{
	string inputStr;
	Employee::ReadData(e);	
	getline(e, inputStr);
	_weeklyHours = atof(inputStr.c_str());
	getline(e, inputStr);
	_hourlyWage = atof(inputStr.c_str());
}
void HourlyEmp::WriteData(ofstream& e)
{
	e << "hourly\n";
	Employee::WriteData(e);
	e << _weeklyHours << endl;
	e << _hourlyWage << endl;
}
SalaryEmp::SalaryEmp(){}
SalaryEmp::SalaryEmp(int num, string name, string address, string phone, double salary)
{
	_employeeNumber = num;
	_name = name;
	_address = address;
	_phoneNumber = phone;
	_weeklySalary = salary;
}
string SalaryEmp::GetName()
{
	return _name;
}
double SalaryEmp::GetSalary()
{
	return _weeklySalary;
}
double SalaryEmp::CalcPay()
{
	double deductions = 0;
	double temp = 0;
	deductions = _weeklySalary * STATE;
	deductions += _weeklySalary * FED;
	deductions += _weeklySalary * BEN;
	temp = _weeklySalary - deductions;
	return temp;
}
void SalaryEmp::ReadData(ifstream& e)
{
	string inputStr;

	Employee::ReadData(e);
	getline(e, inputStr);
	_weeklySalary = atof(inputStr.c_str());

}
void SalaryEmp::WriteData(ofstream& e)
{
	e << "salary\n";
	Employee::WriteData(e);
	e << _weeklySalary << endl;
}
void PrintCheck(Employee* a)
{
	
	string answer = "empty";
	cout << "---------------------------FluffleShuff Electronics-----------------------------" << endl; //output formatting
	cout << "Pay to the order of " << a->GetName() << "...................................";
	if (typeid(*a) == typeid(SalaryEmp))
	{
		SalaryEmp* aPtr = dynamic_cast<SalaryEmp*>(a);
		cout << "$" << aPtr->CalcPay() << endl;
		cout << "United Bank of Programmers" << endl;
		cout << "________________________________________________________________________________" << endl;
		cout << "Weekly salary: " << aPtr->GetSalary() << endl;
	}
	else if(typeid(*a) == typeid(HourlyEmp))
	{
		HourlyEmp* aPtr = dynamic_cast<HourlyEmp*>(a);
		cout << "$" << aPtr->CalcPay() << endl;
		cout << "United Bank of Programmers" << endl;
		cout << "________________________________________________________________________________" << endl;
		cout << "Hours worked: " << aPtr->GetHours() << endl;
		cout << "Hourly wage: " << aPtr->GetWage() << endl;
	}
	while(true){
	cout << "Press enter to see the next employee.... ";
	getline(cin, answer);
	int state = cin.rdstate();
	if(state!=0)
	{
	cout << "Invalid input, please press enter to see the next employee.... " << state << endl;
	system("PAUSE");
	cin.clear();
	if(cin.rdbuf()->in_avail()>0)
		{
		getline(cin, answer);
		continue;
		}
	}
	else if (answer == "")
	{
		getline(cin, answer);
		break;
	}
	}
	return;
}
