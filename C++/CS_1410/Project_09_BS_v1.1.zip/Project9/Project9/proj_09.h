///Course: CS 1410 Section 002
///Name: Bryan Sandoval
///Instructor: Professor Fairclough
///File: Project 08
///Contents: Project 08 Programming Assignment
///in collaboration with: Scott, Matt, Mike, Liam
///-----------------------------------------------------------
///I declare that the following source code was written
///solely by me, or provided by the instructor. 
///I understand that copying any source
///code, in whole or in part, constitutes cheating, and
///that I will receive a zero in this assignment if I am
///found in violation of this policy.
///------------------------------------------------------------


#include <iostream>
#include <string>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <typeinfo>
using namespace std;

//constants 
const int CHAR_SIZE = 256;
const int CHOICE_1 = 1;
const int CHOICE_2 = 2;
const int OT = 40;
const double TIMEANDAHALF = 1.5;
const double STATE = .075;
const double FED = .20;
const double BEN = .0524;
const string FILENAME = "Employees.txt";
const int PRECISION = 2;
const int SIZE = 4;

void main();

//test harness function
void Menu();

//GetInput
//Purpose: Asks the user for input, gathers the input
//Parameters: none
//Returns: an integer used as an answer
int GetInput();

//MakeFile
//Purpose: Creates a text file specified by the user
//Parameters: none
//Returns: void
void MakeFile();

//ReadFile
//Purpose: Reads data from a file specified by the user, and stores in Employee objects
//Parameters: none
//Returns: void
void ReadFile();

//Employee class
//
class Employee
{
protected:
	int _employeeNumber;
	string _name;
	string _address;
	string _phoneNumber;
public:
	//Default constructor
	Employee();

	virtual string GetName();

	//CalcPay
	//Purpose: Calculates an employee's pay
	//Parameters: none
	//Returns: double
	virtual double CalcPay() = 0;

	//ReadData
	//Purpose: read's data from a file
	//Parameters: ifstream object reference
	//Returns: void
	virtual void ReadData(ifstream&);

	//WriteData
	//Purpose: writes data to a file
	//Parameters: ofstream object reference
	//Returns: void
	virtual void WriteData(ofstream&);
};

class HourlyEmp : public Employee
{
private:
	double _weeklyHours;
	double _hourlyWage;
public:
	//default constructor
	HourlyEmp();

	//parameterized constructor
	HourlyEmp(int, string, string, string, double, double);

	string GetName();

	double GetWage();

	double GetHours();

	//CalcPay
	//Purpose: Calculates an employee's pay
	//Parameters: none
	//Returns: double
	double CalcPay();

	//ReadData
	//Purpose: read's data from a file
	//Parameters: ifstream object reference
	//Returns: void
	void ReadData(ifstream&);

	//WriteData
	//Purpose: writes data to a file
	//Parameters: ofstream object reference
	//Returns: void
	void WriteData(ofstream&);
};

class SalaryEmp : public Employee
{
private:
	double _weeklySalary;
public:
	//default constructor
	SalaryEmp();

	//parameterized constructor
	SalaryEmp(int, string, string, string, double);

	string GetName();

	double GetSalary();

	//CalcPay
	//Purpose: Calculates an employee's pay
	//Parameters: none
	//Returns: double
	double CalcPay();

	//ReadData
	//Purpose: read's data from a file
	//Parameters: ifstream object reference
	//Returns: void
	void ReadData(ifstream&);

	//WriteData
	//Purpose: writes data to a file
	//Parameters: ofstream object reference
	//Returns: void
	void WriteData(ofstream&);
};
void PrintCheck(Employee*);
