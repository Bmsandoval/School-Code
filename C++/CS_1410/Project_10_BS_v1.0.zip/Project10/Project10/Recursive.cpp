#include "Recursive.h"

const int ASIZE = 80;
const string NONE = "0";
const string ERROR = "Come on Dennis, you know better...\nTry better next time...\n";
const string RQST_STR = "Please input a string: ";
const string OUTER = "Please enter main string: ";
const string INNER = "Please enter the test string: ";
const string FOUND = "the string was found at index ";
const string NOT_FOUND = "The string was not found";


void main()
{
	Menu();
	system("PAUSE");
}

void Menu()
{
	string s1 = "";
	string s2 = "";
	s1 = Rqst(OUTER);
	s2 = Rqst(INNER);
	int temp = index_of(s1, s2);
	if(temp >= 0)
		cout << FOUND << temp << endl;
	else
		cout << NOT_FOUND << endl;
}

string Rqst(string output)
{
	string input = "";
	char cinput[ASIZE+1];
	double temp = 0.0;
	int state = 0;

	do
	{
		cout << output;
		cin.getline(cinput, ASIZE);
		state = cin.rdstate();
		if(state != 0) // this will test for the error codes incase someone hit's ^Z or another ctrl code.
		{
			cin.clear();
			if(cin.rdbuf() -> in_avail() > 0)
				getline(cin, input);
			cout << ERROR;
			system("PAUSE");
			system("CLS");
			continue;
		}
		if(cinput == "")
		{
			cout << ERROR;
			system("PAUSE");
			system("CLS");
			continue;
		}
		return cinput;
	}while (true);
}

int index_of(string t, string s)
{
	return recursive (t, s);
}

int recursive(string s1, string s2)
{
	if(s1[0] == NULL)
		return -1;
	if(s1[0] != s2[0])
	{
		int temp = recursive(s1.substr(1), s2);
		if(temp >= 0)
			return (1 + temp);
		else
			return -1;
	}
	else
		for(int i = 0; i < s2.length(); i++)
		{
			if(s1[i] == s2[i])
				continue;
			else
				return 1 + recursive(s1, s2.substr(1));
		}
	return 0;
}