///Course: CS 1410 Section 002
///This was a collaborative effort by:
///Name: Bryan Sandoval, Matt LeBaron, Scott Purcell, Michael Leary
///Instructor: Professor Fairclough
///File: Project 10
///-----------------------------------------------------------
///I declare that the following source code was written
///solely by me, or provided by the instructor. 
///I understand that copying any source
///code, in whole or in part, constitutes cheating, and
///that I will receive a zero in this assignment if I am
///found in violation of this policy.
///------------------------------------------------------------

#include<string>
#include<iostream>

using namespace std;
void Menu();
int index_of(string s, string t);
int recursive(string s1, string s2);
string Rqst(string);