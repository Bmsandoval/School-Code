#include "Project11.h"

const int PRE = 2;
const string ANSWER = "The answer is:   ";
const string I = "i";
const string COMPARE = "COMPARE:   ";
const string MINUS = "MINUS:   ";
const string ADD = "ADD:   ";
const string DIVIDE = "DIVIDE:   ";
const string EQUAL = "EQUALS:   ";
const string TIMES = "MULTIPLY:   ";
void main()
{
   Menu();
}
void Menu( )
{
	cout.setf(ios::fixed);
	cout.precision(PRE);
	// Create complex numbers to do arithmentic with
	ComplexNumber cm1(1, 2);
	ComplexNumber cm2(1, -2);

	// test addition operator
	ComplexNumber cm3 = cm1 + cm2;
	cout << cm3 << endl;

	// test subtraction operator
	ComplexNumber cm4 = cm1 - cm2;
	cout << cm4 << endl;

	// test multiplication operator
	ComplexNumber cm5 = cm1 * cm2;
	cout << cm5 << endl;

	// test division operator
	ComplexNumber cm6 = cm1 / cm2;
	cout << cm6<< endl;

	// test assignment operator
	cm6 = cm5;
	cout << cm6 << endl;

	// test comparison operator
	if (cm1 == cm2) 
		cout << "\nThey are equal.\n\n";
	else
		cout << "\nThey are not equal.\n\n";

	ComplexNumber cm8(1, 2);
	if (cm1 == cm8) 
		cout << "\nThey are equal.\n";
	else
		cout << "\nThey are not equal.\n";
	cout << endl;
	system ("PAUSE");
}
ComplexNumber::ComplexNumber(){}
ComplexNumber::ComplexNumber(double a, double bi)
{
	_real = a;
	_imaginary = bi;
}
ComplexNumber::~ComplexNumber()
{
	_real = 0;
	_imaginary = 0;
}
ostream& operator<< (ostream& out, ComplexNumber x)
{ 
	if (x._real != 0.0 && x._imaginary != 0.0) //neither are zero
	{
		out << ANSWER << x._real << x._imaginary << I << endl << endl; // plus? minus? i?
		return out;
	}
	else if (x._real == 0.0 && x._imaginary == 0.0) // both are zero
	{
		out << ANSWER << 0 << endl << endl;
		return out;
	}
	else if (x._real == 0.0 && x._imaginary != 0.0) // imaginary is zero
	{
		out << ANSWER << x._imaginary << I << endl << endl;
		return out;
	}
	else if (x._real != 0.0 && x._imaginary == 0.0) // real is zero
	{
		out << ANSWER << x._real << endl << endl;
		return out;
	}
}
bool ComplexNumber::operator== (ComplexNumber x)
{
	cout << COMPARE;
	bool true_false = true;
	if (_real != x._real && _imaginary != x._imaginary)
		return true_false = false;
	else if (_imaginary != x._imaginary || _real != x._real)
		return true_false = false;
	else return true_false;
}
ComplexNumber ComplexNumber::operator= (ComplexNumber x)
{
	cout << EQUAL;
	double newA = _real = x._real;
	double newBi = _imaginary = x._imaginary;
	ComplexNumber CN (newA, newBi);
	ComplexNumber newCN (newA, newBi);
	return newCN;
}
ComplexNumber ComplexNumber::operator/ (ComplexNumber x)
{
	cout << DIVIDE;
	double newA = _real / x._real;
	double newBi = _imaginary / x._imaginary;
	ComplexNumber CN (newA, newBi);
	ComplexNumber newCN (newA, newBi);
	return newCN;
}
ComplexNumber ComplexNumber::operator* (ComplexNumber x)
{
	cout << TIMES;
	double newA = _real * x._real;
	double newBi = _imaginary * x._imaginary;
	ComplexNumber CN (newA, newBi);
	ComplexNumber newCN (newA, newBi);
	return newCN;
}
ComplexNumber ComplexNumber::operator- (ComplexNumber x)
{
	cout << MINUS;
	double newA = _real - x._real;
	double newBi = _imaginary - x._imaginary;
	ComplexNumber newCN (newA, newBi);
	return newCN;
}
ComplexNumber ComplexNumber::operator+ (ComplexNumber x)
{
	cout << ADD;
	double newA = _real + x._real;
	double newBi = _imaginary + x._imaginary;
	ComplexNumber newCN (newA, newBi);
	return newCN;
}