// Author: Bryan Sandoval
// In Collaboration With: Matt, Scott, Liam, Joshua
// Assignment: Project 11
// Instructor: Dennis Fairclough
// Class: CS 1410 Section: 002
// Date Written: 12/11/2013
// Description: overload operators and output complex number

// I declare that the following source code was written solely by me.
// I understand that copying any source code, in whole or in part,
// constitutes cheating, and that I will recieve a zero on this project
// if I am found in violation of this policy.
//---------------------------------------------------------------------

#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

void Menu();

class ComplexNumber
{
private:
	double _real;
	double _imaginary;
public:
	ComplexNumber();			
	ComplexNumber(double, double);					// Parameterized constructor
	~ComplexNumber();
	ComplexNumber operator+ (ComplexNumber);
	ComplexNumber operator- (ComplexNumber);
	ComplexNumber operator* (ComplexNumber);
	ComplexNumber operator/ (ComplexNumber);
	ComplexNumber operator= (ComplexNumber);
	bool operator== (ComplexNumber);
	friend ostream& operator<< (ostream&, ComplexNumber);
};