#include "vector.h"
 
void main()
{
        {
                Menu();
        }
        system("PAUSE");
}
 
void printV(MyVector);
 
void Menu()
{
        cout << "\nCreating a vector Sam of size 4.";
        MyVector sam( 4 );
 
        cout << "\nPush 12 values into the vector.";
        for (int i = 0; i < 12; i++)
                sam.push_back(i);
 
        cout << "\nHere is sam: ";
        cout << sam;
        cout << "\n---------------\n";
 
                cout << "\nCreating a vector Joe of size 4.";
        MyVector joe( 4 );
        cout << "\nPush 6 values into the vector.";
        for (int i = 0; i < 6; i++)
                joe.push_back(i * 3);
 
        cout << "\nHere is joe: ";
        cout << joe;
        cout << "\n---------------\n";
       
        cout << "\nTest the overloaded assignment operator \"joe = sam\": ";
        joe = sam;
 
        cout << "\nHere is sam: ";
        cout << sam;
        cout << "\n---------------\n";
 
        cout << "\nHere is joe: ";
        cout << joe;
        cout << "\n---------------\n";
 
        // pass a copy of sam by value
        printV(sam);
       
 
        cout << endl;
        system("PAUSE");
        return;
}
 
void printV(MyVector v)
{
        cout << "\n--------------------\n";
        cout << "Printing a copy of a vector\n";
        cout << v;
}
MyVector::MyVector()
{
        _capacity = CAP;
        _size = 0;
        _aPtr = new int[_capacity];
}
MyVector::MyVector(int n)
{
        _capacity = n;
        _size = 0;
        _aPtr = new int[_capacity];    
}
MyVector::MyVector(const MyVector& a)
{
        cout << "Copy constructor: " << endl;
        _capacity = a._capacity;
        _size = a._size;
        _aPtr = new int[_capacity];
        for(int i=0;i<a._size;i++)
                _aPtr[i] = a._aPtr[i];
        _bPtr = new int[_capacity];
        for(int i=0;i<a._size;i++)
                _bPtr[i] = a._bPtr[i];
}
MyVector& MyVector::operator=(const MyVector& a)
{
        _capacity = a._capacity;
        _size = a._size;
        _aPtr = new int[_capacity];
        for(int i=0;i<a._size;i++)
                _aPtr[i] = a._aPtr[i];
        _bPtr = new int[_capacity];
        for(int i=0;i<a._size;i++)
                _bPtr[i] = a._bPtr[i];
        return *this;
}
int MyVector::Size()
{
        return _size;
}
int MyVector::Capacity()
{
        return _capacity;
}
void MyVector::Clear()
{
        _size = 0;
        _capacity = CAP;
}
void MyVector::push_back(int a)
{
        if (_size+1 > _capacity)
        {
                _capacity = _size*MULT;
                _bPtr = new int[_capacity];
                for(int i=0;i<_size;i++)
                {
                        _bPtr[i]=_aPtr[i];
                }
                delete[] _aPtr;
                _aPtr = _bPtr;
        }
        _aPtr[_size] = a;
        _size++;
}
MyVector::~MyVector()
{
        if (_aPtr != NULL)
        {
                delete[] _aPtr;
                _aPtr = NULL;
        }
}
int MyVector::ValueAt(int a)
{
        if(a < _size)
        {
                return _aPtr[a];
        }
        throw a;
}
ostream& operator<<(ostream& os, const MyVector& vec)
{
        os << "\nCapacity: " << vec._capacity << endl << "Size: " << vec._size << endl << "Values: " << endl;
                for (int i =0;i<vec._size;i++)
                        os << vec._aPtr[i] << endl;
        return os;
}