// PROLOGUE
//
// CS 1410
// Bryan Sandoval
// In collaboration with: Liam
// CS 1410 -- 002
// --------------------------
///-----------------------------------------------------------
///I declare that the following source code was written
///solely by me, or provided by the instructor. 
///I understand that copying any source
///code, in whole or in part, constitutes cheating, and
///that I will receive a zero in this assignment if I am
///found in violation of this policy.
///------------------------------------------------------------
 
#include <iostream>
#include <string>
#include <iomanip>
using namespace std;
 
void main();
const int CAP = 2;
const int MULT = 2;
 
//test harness function
void Menu();
 
//MyVector
//Purpose: Dynamically allocates memory to an array of integers
//Data members: an integer for the size of an array, and an integer for its capacity
class MyVector
{
private:
        int _size;
        int _capacity;
        int* _aPtr;
        int* _bPtr; //temp pointer
public:
        //Default constructor
        //Purpose: initializes _capacity to 2, _size to 0, creates pointer to array
        MyVector();
 
        //Parameterized constructor
        //Purpose: initializes _capacity to n, _size to 0, creates pointer to array
        //Parameters: one int
        MyVector(int);
 
        //copy constructor
        MyVector(const MyVector&);
 
        //Destructor
        ~MyVector();
 
        //overloaded assignment operator
        MyVector& operator=(const MyVector&);
 
        //Size
        //Purpose: returns the current size of an array
        //Parameters: none
        //Returns: an int
        int Size();
 
        //Capacity
        //Purpose: returns the current capacity of an array
        //Parameters: none
        //Returns: an int
        int Capacity();
 
        //Clear
        //Purpose: initializes data members to default, deletes a MyVector array
        //Parameters: none
        //Returns: void
        void Clear();
 
        //PushBack
        //Purpose: adds an element to the end of the MyVector array
        //Parameters: an integer to add
        //Returns: void
        void push_back(int);
 
        //ValueAt
        //Purpose: returns a value inside a MyVector array
        //Parameters: an integer
        //Returns: an int that is an element of MyVector array
        int ValueAt(int);
 
        friend ostream& operator<<(ostream&, const MyVector&);
};
 
 
void printV(MyVector);