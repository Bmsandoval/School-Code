#include "Node.h"

void main()
{
	ProjTestGrocery();
	ProjTestSupplies();
}







// ----------------------------------------------------------------
// Node Class
// ----------------------------------------------------------------
	Node::Node()
	{
		_nextNode = NULL;
		_prevNode = NULL;
		_number = 0;
	}
	Node::Node(unsigned int num)
	{
		_nextNode = NULL;
		_prevNode = NULL;
		_number = num;

	}
	Node::~Node()
	{
		delete _nextNode;
		_nextNode = NULL;
		_prevNode = NULL;
	}
	unsigned int Node::GetNum()
	{
		return _number;
	}
	Node* Node::GetNext()
	{
		return _nextNode;
	}
	Node* Node::GetPrev()
	{
		return _prevNode;
	}
	void Node::SetNext(Node* next)
	{
		_nextNode = next;
	}
	void Node::SetPrev(Node* prev)
	{
		_prevNode = prev;
	}
	void Node::SetNum(unsigned int num)
	{
		_number = num;
	}
	string Node::GetName() { return ""; }

// ----------------------------------------------------------------
// Llist Class
// ----------------------------------------------------------------

	Llist::Llist()
	{
		_headNode = NULL;
		_endNode = NULL;
		_nodeCount = 0;
	}
	Llist::Llist(Node* head, Node* end, unsigned int cnt)
	{
		_headNode = head;
		_endNode = end;
		_nodeCount = cnt;
	}
	Llist::~Llist()
	{
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		delete _headNode;
		_headNode = NULL;
		_endNode = NULL;
	}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	Llist::Llist(Llist& first)
	{
		_headNode = NULL;
		_endNode = NULL;
		_nodeCount = first.GetCount();
		
		Node* _temp = first.GetFirst();
		while(_temp != NULL)
		{
			if(typeid(*_temp) == typeid(Grocery))
			{
				this->Push_End(new Grocery((Grocery*)(_temp)));
			} else if(typeid(*_temp) == typeid(Supplies))
			{
				this->Push_End(new Supplies((Supplies*)(_temp)));
			}
			_temp = _temp->GetNext();
		}

		/*
	   if (first._nodeCount == 0)
	   {
		  _nodeCount = 0;
		  _headNode = NULL;
		  _endNode = NULL;
	   }
	   else
	   {
		  int numNode = first._nodeCount;
		  Node* next = _headNode;
		  Node* prev = next;
		  while (next != NULL)
		  {
			 prev = next;
			 next = next->GetNext();
			 delete prev;
		  }
		  _headNode = NULL;
		  _endNode = NULL;
		  _nodeCount = first._nodeCount;

		  next = first._headNode;
		  Node* copy = new Node(next->getQuantityNumber(), next->getQuantityName(),
			 next->getDescription());
		  _headNode = copy;
		  prev = copy;
		  for (int i = 1; i < _nodeCount; i++)
		  {
			 next = next->GetNext();
			 Push_End(new Node(next->getQuantityNumber(), next->getQuantityName(),
				next->getDescription()));
		  }
	   }
	   */
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	Node* Llist::GetFirst()
	{
		return _headNode;
	}
	Node* Llist::GetLast()
	{
		return _endNode;
	}
	unsigned int Llist::GetCount()
	{
		return _nodeCount;
	}
	void Llist::SetHead(Node* head)
	{
		_headNode = head;
	}
	void Llist::SetEnd(Node* end)
	{
		_endNode = end;
	}
	void Llist::SetCount(unsigned int cnt)
	{
		_nodeCount = cnt;
	}
	void Llist::Push_Front (Node* add)
	{
		if(_headNode==NULL)
		{
			_headNode= add;
			_endNode= add;
			_nodeCount++;

		}
		else
		{
			Node* oldHead=_headNode;
			_headNode=add;
			add-> SetNext(oldHead);
			oldHead->SetPrev(add);
			_nodeCount++;	
		}	
	}

	Node* Llist::Pop_Front()
	{
		if( _headNode== NULL)// case 1 if the list is empty
		{ 
			return NULL;
		}
		else if (_headNode == _endNode) // case 2 if there is only one item in list
		{
			Node* temp = _headNode;
			_headNode = NULL;
			_endNode = NULL;
			_nodeCount = 0;
			return temp;
		}
		else
		{
			Node* oldHead=_headNode; // sets our temp node = to the first node 
			_headNode= oldHead->GetNext(); // then it sets the head = to the second node in the list
			oldHead->SetNext(NULL); // then it unlinks oldhead/temp by setting its next to null so it nolonger points anywere
			_headNode->SetPrev(NULL); // sets the second node  previous in the list (NOW first) to null;
			_nodeCount--;
			return oldHead; // returns the node 
		}
	}
	void Llist::Push_End(Node* addend)
	{
		if(_endNode== NULL)
		{
			_headNode=addend;
			_endNode=addend;
			_nodeCount++;
		}
		else
		{
		Node* oldEnd= _endNode;
		_endNode=addend;
		addend->SetPrev(oldEnd);
		oldEnd->SetNext(addend);
		_nodeCount++;
		}
	}
	Node* Llist::Pop_End()
	{
		if( _headNode== NULL)// case 1 if the list is empty
		{ 
			return NULL;
		}
		else if (_headNode == _endNode) // case 2 if there is only one item in list
		{
			Node* temp = _headNode;
			_headNode = NULL;
			_endNode = NULL;
			_nodeCount = 0;
			return temp;
		}
		else
		{
		Node* tempNode = _endNode;
		_endNode = tempNode->GetPrev();
		_endNode->SetNext(NULL);
		tempNode->SetPrev(NULL);
		return tempNode;
		}
		
	}
//	string Llist::ToString()
//	{
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//		return "Llist ToString";
//	}
	Node* Llist::FindNode(unsigned int var)
	{
		Node* _tempNode = _headNode;
		do
		{
			if (_tempNode == NULL)
			{
				cout << "Unable to find node: " << var << endl;
				return NULL;
			}
			else if(_tempNode->GetNum() == var)
			{
				//cout << "Found Node: " << var << endl;
				return _tempNode;
			}
			else _tempNode = _tempNode -> GetNext();
		}while(true);
		_tempNode = NULL;
	}
	void Llist::AddNode(Node* nPtr, unsigned int var)
	{
		Node* tempPtr = FindNode(var);
		if (tempPtr==NULL)
			cout << "could not find requested node";
		else if(tempPtr->GetPrev() == NULL)
		{
			tempPtr->SetPrev(nPtr);
			_headNode = nPtr;
			nPtr->SetPrev(NULL);
			nPtr->SetNext(tempPtr);
		}
		else
		{
			tempPtr->GetPrev()->SetNext(nPtr);
			nPtr->SetPrev(tempPtr->GetPrev());
			tempPtr->SetPrev(nPtr);
			nPtr->SetNext(tempPtr);
		}
	}
	Node* Llist::RemoveNode(unsigned int id)
	{
		Node* tempNode = FindNode(id);
		if(tempNode != NULL)
		{
			if(tempNode->GetPrev() == NULL && tempNode->GetNext() == NULL)
			{
				_headNode == NULL;
				_endNode == NULL;
				tempNode->SetNext(NULL);
				tempNode->SetPrev(NULL);
				_nodeCount = 0;
			}
			else
			{
			(tempNode->GetPrev())->SetNext(tempNode->GetNext());
			(tempNode->GetNext())->SetPrev(tempNode->GetPrev());
			tempNode->SetNext(NULL);
			tempNode->SetPrev(NULL);
			return tempNode;
			}
		}
		else
		{
			cout << "returning null value";
			return NULL;
		}

	}
	void Llist::ClearList()
	{
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		delete _headNode;
		_headNode = NULL;
		_endNode = NULL;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	}
	Llist& Llist::operator=(Llist& rho)
	{
		if (this == &rho)
			return *this;

		this->ClearList();
		_headNode = NULL;
		_endNode = NULL;
		_nodeCount = rho.GetCount();
		
		Node* _temp = rho.GetFirst();
		while(_temp != NULL)
		{
			if(typeid(*_temp) == typeid(Grocery))
			{
				this->Push_End(new Grocery((Grocery*)(_temp)));
			} else if(typeid(*_temp) == typeid(Supplies))
			{
				this->Push_End(new Supplies((Supplies*)(_temp)));
			}
			_temp = _temp->GetNext();
		}
		return *this;
	}



// ----------------------------------------------------------------
// Grocery Class
// ----------------------------------------------------------------
	Grocery::Grocery() : Node()
	{
		_itemName = "";
		_itemUnitMeasure = "";
		_numberUnits = 0;
	}
	Grocery::Grocery(unsigned int units, string unitNum, string name, unsigned int num) : Node(num)
	{
		_itemName = name;
		_itemUnitMeasure = unitNum;
		_numberUnits = units;
	}
	Grocery::~Grocery()
	{
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	}
	Grocery::Grocery(Grocery* first)
		: Node(first->GetNum())
	{
		_itemName = first->GetName();
		_itemUnitMeasure = first->GetMeasure();
		_numberUnits = first->GetUnits();
	}
	string Grocery::GetName()
	{
		return _itemName;
	}
	string Grocery::GetMeasure()
	{
		return _itemUnitMeasure;
	}
	unsigned int Grocery::GetUnits()
	{
		return _numberUnits;
	}
	void Grocery::SetName(string name)
	{
		_itemName = name;
	}
	void Grocery::SetMeasure(string measure)
	{
		_itemUnitMeasure = measure;
	}
	void Grocery::SetUnits(unsigned int units)
	{
		_numberUnits = units;
	}
	string Grocery::ToString()
	{
		string temp = "";
		temp += to_string(_numberUnits) + " " + _itemUnitMeasure + " " + _itemName;
		return temp;
	}


// ----------------------------------------------------------------
// Supplies Class
// ----------------------------------------------------------------
	Supplies::Supplies()
	{
		_reorderQuantity = 0;
		_itemName = "";
		_itemUnitMeasure = "";
		_quantity = 0;
	}
	Supplies::Supplies(unsigned int quantity, string measure, string name, unsigned int reorder, unsigned int num) : Node(num)
	{
		_reorderQuantity = reorder;
		_itemName = name;
		_itemUnitMeasure = measure;
		_quantity = quantity;
	}
	Supplies::~Supplies()
	{
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	}
	Supplies::Supplies(Supplies* first)
		: Node(first->GetNum())
	{
		_itemName = first->GetName();
		_itemUnitMeasure = first->GetMeasure();
		_quantity = first->GetQuantity();
		_reorderQuantity = first->GetReorder();
	}
	int Supplies::GetReorder()
	{
		return _reorderQuantity;
	}
	string Supplies::GetName()
	{
		return _itemName;
	}
	string Supplies::GetMeasure()
	{
		return _itemUnitMeasure;
	}
	unsigned int Supplies::GetQuantity()
	{
		return _quantity;
	}
	void Supplies::SetReorder(int reorder)
	{
		_reorderQuantity = reorder;
	}
	void Supplies::SetName(string name)
	{
		_itemName = name;
	}
	void Supplies::SetMeasure(string measure)
	{
		_itemUnitMeasure = measure;
	}
	void Supplies::SetQuantity(unsigned int quantity)
	{
		_quantity = quantity;
	}
	string Supplies::ToString()
	{
		string temp = "";
		temp += to_string(_quantity) + " " + _itemUnitMeasure + " " + _itemName;
		return temp;
	}

// *********************************************************************************************************************************** //
// *********************************************************************************************************************************** //
// *********************************************************** DRIVER CODE *********************************************************** //
// *********************************************************************************************************************************** //
// *********************************************************************************************************************************** //



void ProjTestGrocery( )
{
	//===============================================
	// 			PART ONE
	//===============================================
	cout << "\nPart I: Push_Front and Pop_Front\n";
	cout << "\n----------------------------------\n";
	Llist groceries;

	// test Push_Front function
	groceries.Push_Front (new Grocery( 1, "gallon", "milk", 1) );
	groceries.Push_Front (new Grocery(2, "loaves", "bread", 2) );
	groceries.Push_Front (new Grocery(1, "dozen", "eggs", 3 ) );
	groceries.Push_Front (new Grocery(1,  "package", "bacon", 4) );
	groceries.AddNode(new Supplies(10, "box","pencils", 1, 5), 3);
	Node* _tempNode = groceries.RemoveNode(2);
	cout << "Removed Node -> " << _tempNode->ToString() << endl;
	PrintNode(_tempNode);
	delete _tempNode;
	cout << "\nThe original nodes in the List:\n";
	PrintList(groceries);
	cout << "\n----------------------------------\n";

	// test Push_Front function
	cout << "\nAdding to the front of the List:\n";
	cout << "\n----------------------------------\n";
	groceries.Push_Front (new Grocery(2, "lbs", "hamburger", 5) );
	groceries.Push_Front (new Grocery(1, "dozen", "hamburger buns", 6) );

	PrintList(groceries);
	cout << "\n----------------------------------\n";

	// test pop-front
	cout << "\nRemoving the first node from the list.\n";
	cout << "\n----------------------------------\n";
	Node* item = groceries.Pop_Front( );
	cout << "\nPopped " << item->GetName( ) << " from the list.\n\n";
	PrintList(groceries);
	if (item != NULL)
		delete item;

	 //====================================================
	 //    	PART TWO: Uncomment this block to test part two
	 //====================================================
	
	cout << "\n----------------------------------\n";
	cout << "\nPart Two: Push_End and Pop_End";
	
	//test Push_End
	groceries.Push_End (new Grocery(2, "cans", "orange juice", 10) );
	groceries.Push_End (new Grocery(1, "lb", "swiss cheese", 11) );

	cout << "\nAdding two nodes at the end\n";
	cout << "\n----------------------------------\n";
	PrintList(groceries);

	//test Pop_End
	cout << "\n----------------------------------\n";
	cout << "\nRemove last node from the list\n";
	cout << "\n----------------------------------\n";
	item = groceries.Pop_End( );
	cout << "\nPopped " << item->GetName( ) << " from the list.\n\n";

	PrintList(groceries);
	if (item != NULL)
		delete item;
	 //============================================
	 //   			End of part two
	 //============================================
	
	// //=======================================================
	// //   	PART THREE: uncomment this block to test part three
	// //=======================================================
	//
	////create a second list to test assignment
	cout << "\n\n--------------extra credit------------------\n";
	cout << "\n\n overloaded assignment operator\n";
	cout << "The hardware list ...\n";
	cout << "\n-------------------------------------------\n";
	Llist hardware;
	hardware.Push_End(new Grocery(2, "lbs", "nails", 7) );
	hardware.Push_End( new Grocery(3, "gals", "white paint", 8) );
	hardware.Push_End(new Grocery(1, "piece", "plywood", 9) );
	PrintList(hardware);
	hardware = groceries;
	cout << "\n-------------------------------------------\n";
	cout << "\nafter assignment";
	cout << "\n-------------------------------------------\n";
	PrintList(hardware);

	cout << "\n-------------------------------------------\n";
	cout << "\nTest the copy constructor\n";
	cout << "\n-------------------------------------------\n";
	PrintList(hardware);

	//// ==============================================
	//// 			End of part 3
	//// ==============================================
	
	cout << "\n-------------------------------------------\n";
	cout << "\nEnd of Test";
	cout << "\n-------------------------------------------\n";
	groceries.ClearList();
	hardware.ClearList();
	system("PAUSE");
}
////***************************************************************************************************************************************************************************************
////***************************************************************************************************************************************************************************************
////***************************************************************************************************************************************************************************************
void ProjTestSupplies()
{
	//===============================================
	// 			PART ONE
	//===============================================
	cout << "\nPart I: Push_Front and Pop_Front\n";
	cout << "\n----------------------------------\n";
	Llist supply;

	// test Push_Front function
	supply.Push_Front (new Supplies( 1, "box", "pencils", 1, 1) );
	supply.Push_Front (new Supplies(2, "package", "rubber bands", 1, 2) );
	supply.Push_Front (new Supplies(1, "dozen", "pens", 1, 3 ) );
	supply.Push_Front (new Supplies(1,  "package", "stickers", 1, 4) );

	cout << "\nThe original nodes in the List:\n";
	PrintList(supply);
	cout << "\n----------------------------------\n";

	// test Push_Front function
	cout << "\nAdding to the front of the List:\n";
	cout << "\n----------------------------------\n";
	supply.Push_Front (new Supplies(2, "lbs", "paper clips", 1, 5) );
	supply.Push_Front (new Supplies(1, "dozen", "wall pins", 1, 6) );

	PrintList(supply);
	cout << "\n----------------------------------\n";

	// test pop-front
	cout << "\nRemoving the first node from the list.\n";
	cout << "\n----------------------------------\n";
	Node* item = supply.Pop_Front( );
	cout << "\nPopped " << item->GetName() << " from the list.\n\n";
	PrintList(supply);
	if (item != NULL)
		delete item;

	 //====================================================
	 //    PART TWO: Uncomment this block to test part two
	 //====================================================
	
	cout << "\n----------------------------------\n";
	cout << "\nPart Two: Push_End and Pop_End";
	
	//test Push_End
	supply.Push_End (new Supplies(2, "can", "spray glue", 1, 10) );
	supply.Push_End (new Supplies(1, "lb", "parrot clips", 1, 11) );

	cout << "\nAdding two nodes at the end\n";
	cout << "\n----------------------------------\n";
	PrintList(supply);

	//test Pop_End
	cout << "\n----------------------------------\n";
	cout << "\nRemove last node from the list\n";
	cout << "\n----------------------------------\n";
	item = supply.Pop_End( );
	cout << "\nPopped " << item->GetName( ) << " from the list.\n\n";

	PrintList(supply);
	if (item != NULL)
		delete item;
	 //============================================
	 //   			End of part two
	 //============================================
	
	 //=======================================================
	 //   	PART THREE: uncomment this block to test part three
	 //=======================================================
	
	//create a second list to test assignment
	cout << "\n\n--------------extra credit------------------\n";
	cout << "\n\n overloaded assignment operator\n";
	cout << "The hardware list ...\n";
	cout << "\n-------------------------------------------\n";
	Llist hardware;
	hardware.Push_End(new Supplies(2, "lbs", "plastic pins", 1, 7) );
	hardware.Push_End(new Supplies(3, "gals", "paper glue", 1, 8) );
	hardware.Push_End(new Supplies(1, "piece", "plywood", 1, 9) );
	PrintList(hardware);
	hardware = supply;
	cout << "\n-------------------------------------------\n";
	cout << "\nafter assignment";
	cout << "\n-------------------------------------------\n";
	PrintList(hardware);

	cout << "\n-------------------------------------------\n";
	cout << "\nTest the copy constructor\n";
	cout << "\n-------------------------------------------\n";
	PrintList(hardware);

	//// ==============================================
	//// 			End of part 3
	//// ==============================================
	
	cout << "\n-------------------------------------------\n";
	cout << "\nEnd of Test";
	cout << "\n-------------------------------------------\n";
	supply.ClearList();
	hardware.ClearList();
	system("PAUSE");
	//return 0;
}
void PrintList(Llist& lst)
{
	Node* curPtr = lst.GetFirst();
	Node* nextPtr = NULL;

	while(curPtr != NULL)
	{
		nextPtr = curPtr->GetNext();                
		cout << curPtr->ToString() << endl;                  
		curPtr = nextPtr;        
	}
}
void PrintNode(Node* nPtr)
{
	cout << nPtr->ToString() << endl;
}

//void PrintNode(Llist,int)
//{
//
//}