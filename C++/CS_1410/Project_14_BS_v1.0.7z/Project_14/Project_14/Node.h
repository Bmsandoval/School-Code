///Course: CS 1410 Section 002
///Author: Bryan Sandoval
///In collaboration with: Matt, Scott, Joshua, Liam and others
///Date: 12/17/13
///Project: Project 14
///-----------------------------------------------------------
///I declare that the following source code was written
///solely by me, or provided by the instructor.�
///I understand that copying any source
///code, in whole or in part, constitutes cheating, and
///that I will receive a zero in this assignment if I am
///found in violation of this policy.
///------------------------------------------------------------


#include <string>
#include <iostream>
#include <sstream>
#include <typeinfo.h>
using namespace std;

class Node
{
private:
	Node* _nextNode;
	Node* _prevNode;
	unsigned int _number;
public:
	Node();
	Node(unsigned int);
	~Node();
	virtual string ToString() = 0;
	virtual string GetName();
	unsigned int GetNum();
	Node* GetNext();
	Node* GetPrev();
	void SetNext(Node*);
	void SetPrev(Node*);
	void SetNum(unsigned int);
	// Overloaded Operators


};
class Llist
{
private:
	Node* _headNode;
	Node* _endNode;
	unsigned int _nodeCount;
	Node* _tempNode;
public:
	Llist();
	Llist(Node*, Node*, unsigned int);
	~Llist();
	Llist(Llist&);
	Node* GetFirst();
	Node* GetLast();
	unsigned int GetCount();
	void SetHead(Node*);
	void SetEnd(Node*);
	void SetCount(unsigned int);
	void Push_Front(Node*);
	void Push_End(Node*);
	Node* Pop_Front();
	Node* Pop_End();
	//string ToString();
	Node* FindNode(unsigned int);
	void AddNode(Node*, unsigned int);
	Node* RemoveNode(unsigned int);
	void ClearList();
	Llist& operator=( Llist&);
};

class Grocery: public Node
{
private:
	string _itemName;
	string _itemUnitMeasure;
	unsigned int _numberUnits;
public:
	Grocery();
	Grocery(unsigned int, string, string, unsigned int);
	~Grocery();
	Grocery(Grocery*);
	string GetName();
	string GetMeasure();
	unsigned int GetUnits();
	void SetName(string);
	void SetMeasure(string);
	void SetUnits(unsigned int);
	virtual string ToString();
};

class Supplies: public Node
{
private:
	int _reorderQuantity;
	string _itemName;
	string _itemUnitMeasure;
	unsigned int _quantity;
public:
	Supplies();
	Supplies(unsigned int, string, string, unsigned int, unsigned int);
	~Supplies();
	Supplies(Supplies*);
	int GetReorder();
	string GetName();
	string GetMeasure();
	unsigned int GetQuantity();
	void SetReorder(int);
	void SetName(string);
	void SetMeasure(string);
	void SetQuantity(unsigned int);
	virtual string ToString();
};

// the PrintList function
// Purpose: Prints out the contents for each Node in the List
// Parameter: A list object, by value
// Returns: none
void PrintList(Llist&); 

// the PrintNode function
// Purpose: Prints out the contents for the 1st Node in the List
// Parameter: A list object, passed by value to test the copy constructor
//                   int is the _number of the node to print.
// Returns: none
//void PrintNode(Llist,int);

// the PrintNode function
// Purpose: Prints out the contents of Node in the passed by address
// Parameter: A Node object, by address
// Returns: none
void PrintNode(Node*);

void ProjTestGrocery();
void ProjTestSupplies();